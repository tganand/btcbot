import { describe, expect, it } from "vitest";
import { deriveRoundTrips, reconcilePaperAccount, stopPrice } from "./math.js";
import { applyLastTrade, applyPriceChange, isLastTradePriceEvent, MessageDeduper } from "./marketFeed.js";
import type { PaperAccount } from "./types.js";
describe("paper math", () => {
  it("uses per-asset best prices instead of changed mirror levels", () => {
    const up = { bids: new Map([["0.54", 100]]), asks: new Map([["0.55", 100]]) };
    const down = { bids: new Map([["0.45", 100]]), asks: new Map([["0.46", 100]]) };
    const upQuote = applyPriceChange(up, { asset_id: "up", price: "0.43", side: "BUY", size: "20", best_bid: "0.54", best_ask: "0.55" });
    const downQuote = applyPriceChange(down, { asset_id: "down", price: "0.57", side: "SELL", size: "20", best_bid: "0.45", best_ask: "0.46" });
    expect(upQuote).toMatchObject({ bid: 0.54, ask: 0.55, bidSize: 100, askSize: 100 });
    expect(downQuote).toMatchObject({ bid: 0.45, ask: 0.46, bidSize: 100, askSize: 100 });
  });
  it("does not promote a changed 0.99 sell level to best ask", () => {
    const levels = { bids: new Map([["0.57", 100]]), asks: new Map([["0.58", 100]]) };
    const quote = applyPriceChange(levels, { asset_id: "up", price: "0.99", side: "SELL", size: "92203", best_bid: "0.57", best_ask: "0.58" });
    expect(quote.ask).toBe(0.58);
    expect(quote.askSize).toBe(100);
  });
  it("does not treat last trade price as a quote", () => {
    const levels = { bids: new Map([["0.54", 100]]), asks: new Map([["0.55", 100]]) };
    expect(isLastTradePriceEvent({ event_type: "last_trade_price", price: "0.99", side: "SELL" })).toBe(true);
    const book = applyLastTrade({ bid: 0.54, ask: 0.55, bidSize: 10, askSize: 10, lastUpdateTs: 1 }, 0.99);
    expect(book).toMatchObject({ bid: 0.54, ask: 0.55, lastTrade: 0.99 });
  });
  it("deduplicates an identical message once", () => {
    const deduper = new MessageDeduper();
    expect(deduper.seen('{"id":1}')).toBe(false);
    expect(deduper.seen('{"id":1}')).toBe(true);
  });
  it("calculates exact stop price", () => expect(stopPrice({ entryPrice: 0.91, shares: 10 / 0.91 } as never, 3)).toBeCloseTo(0.637));
  it("reconciles corrupted state", () => {
    const a: PaperAccount = { startingBalance: 100, cashBalance: 0, totalRealizedPnl: 99, openPosition: null, ledger: [{ id: "1", timestamp: 1, windowId: "w", side: "BUY", outcome: "UP", price: 0.91, shares: 10 / 0.91, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" }], version: 0, reconciliationStatus: "MISMATCH", reconciliationDiff: 0 };
    reconcilePaperAccount(a); expect(a.cashBalance).toBe(90); expect(a.reconciliationStatus).toBe("MISMATCH");
  });
  it("derives completed trades", () => expect(deriveRoundTrips([{ id: "b", timestamp: 1, windowId: "w", side: "BUY", outcome: "UP", price: .9, shares: 10, usd: 9, fee: 0, slippage: 0, reason: "ENTRY" }, { id: "s", timestamp: 2, windowId: "w", side: "SELL", outcome: "UP", price: 1, shares: 10, usd: 10, fee: 0, slippage: 0, reason: "TAKE_PROFIT" }]).length).toBe(1));
});
