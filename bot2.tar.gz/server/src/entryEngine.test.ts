import { describe, expect, it } from "vitest";
import { EntryEngine } from "./entryEngine.js";
import { config } from "./config.js";
import { PaperExecutor } from "./paperExecutor.js";
import type { MarketSnapshot, PaperAccount } from "./types.js";

const account = (): PaperAccount => ({ startingBalance: 100, cashBalance: 100, totalRealizedPnl: 0, openPosition: null, ledger: [], version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0 });
const snapshot = (secondsRemaining: number): MarketSnapshot => ({
  windowId: "w",
  windowStart: 0,
  windowEnd: secondsRemaining,
  up: { bid: 0.95, ask: 0.958, bidSize: 10, askSize: 20, lastUpdateTs: 1000 },
  down: { bid: 0.04, ask: 0.05, bidSize: 20, askSize: 20, lastUpdateTs: 1000 },
  feedHealth: "LIVE",
  consistent: true,
  feedMessage: "Live prices flowing"
});

describe("entry visibility and decisions", () => {
  it("buys after a held trigger with time and liquidity", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, 0);
    engine.tick(snapshot(113), 0);
    engine.tick(snapshot(113), 1000);
    expect(paper.ledger).toHaveLength(1);
    expect(paper.ledger[0]?.outcome).toBe("UP");
  });
  it("blocks an otherwise eligible entry when too late", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, 0);
    engine.tick(snapshot(80), 0);
    engine.tick(snapshot(80), 1000);
    expect(paper.ledger).toHaveLength(0);
    expect(engine.getStatuses().UP.decision).toBe("TOO_LATE");
  });
});
