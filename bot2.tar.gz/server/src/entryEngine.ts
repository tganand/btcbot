import { PaperExecutor } from "./paperExecutor.js";
import type { EngineConfig } from "./config.js";
import type { EntryDecision, EntryStatus, MarketSnapshot, Outcome, PaperAccount } from "./types.js";

interface SideState {
  aboveSince: number | null;
  lastLoggedSecond: number;
}

export class EntryEngine {
  private readonly state: Record<Outcome, SideState> = {
    UP: { aboveSince: null, lastLoggedSecond: -1 },
    DOWN: { aboveSince: null, lastLoggedSecond: -1 }
  };
  private readonly statuses: Record<Outcome, EntryStatus>;
  private readonly warmupUntil: number;
  private enteredWindow = "";
  public constructor(
    private readonly config: EngineConfig,
    private readonly account: PaperAccount,
    private readonly executor: PaperExecutor,
    private readonly onAccountChange: () => void,
    private readonly startedAt = Date.now()
  ) {
    this.warmupUntil = startedAt + 1000;
    this.statuses = {
      UP: this.emptyStatus(),
      DOWN: this.emptyStatus()
    };
  }
  private emptyStatus(): EntryStatus {
    return { ask: 0, trigger: this.config.entryTrigger, msHeldAboveTrigger: 0, secondsRemaining: 0, feedHealth: "DISCONNECTED", consistent: false, positionOpen: false, askSize: 0, decision: "FEED_STALE" };
  }
  public getStatuses(): Record<Outcome, EntryStatus> {
    return { UP: { ...this.statuses.UP }, DOWN: { ...this.statuses.DOWN } };
  }
  public tick(snapshot: MarketSnapshot, now = Date.now()): void {
    if (snapshot.windowId !== this.enteredWindow) {
      this.enteredWindow = snapshot.windowId;
      this.state.UP.aboveSince = null;
      this.state.DOWN.aboveSince = null;
      this.state.UP.lastLoggedSecond = -1;
      this.state.DOWN.lastLoggedSecond = -1;
    }
    for (const outcome of ["UP", "DOWN"] as const) {
      const book = outcome === "UP" ? snapshot.up : snapshot.down;
      const secondsRemaining = Math.max(0, snapshot.windowEnd - now / 1000);
      if (book.ask >= this.config.entryTrigger) this.state[outcome].aboveSince ??= now;
      else this.state[outcome].aboveSince = null;
      const held = this.state[outcome].aboveSince === null ? 0 : now - this.state[outcome].aboveSince;
      const status = this.statuses[outcome] = {
        ask: book.ask,
        trigger: this.config.entryTrigger,
        msHeldAboveTrigger: held,
        secondsRemaining,
        feedHealth: snapshot.feedHealth,
        consistent: snapshot.consistent,
        positionOpen: this.account.openPosition !== null,
        askSize: book.askSize,
        decision: this.decide(snapshot, outcome, book.ask, book.askSize, held, secondsRemaining, now)
      };
      const second = Math.floor(now / 1000);
      if (second !== this.state[outcome].lastLoggedSecond) {
        this.state[outcome].lastLoggedSecond = second;
        console.log(`[entry] ${outcome} ask=${book.ask.toFixed(4)} trigger=${this.config.entryTrigger.toFixed(4)} heldMs=${held} secondsRemaining=${secondsRemaining.toFixed(1)} feed=${snapshot.feedHealth} consistent=${snapshot.consistent} positionOpen=${this.account.openPosition !== null} askSize=${book.askSize} decision=${status.decision}`);
      }
      if (status.decision === "NONE" && this.enteredWindow === snapshot.windowId && this.account.openPosition === null) {
        const fill = this.executor.buy(this.account, snapshot.windowId, outcome, book.ask, now);
        if (fill) {
          this.account.openPosition = { outcome, windowId: snapshot.windowId, entryPrice: fill.price, shares: fill.shares, cost: fill.usd + fill.fee, openedAt: now };
          this.onAccountChange();
        }
      }
    }
  }
  private decide(snapshot: MarketSnapshot, outcome: Outcome, ask: number, askSize: number, held: number, secondsRemaining: number, now: number): EntryDecision {
    if (this.account.openPosition) return "POSITION_OPEN";
    if (now < this.warmupUntil) return "WARMUP";
    if (snapshot.feedHealth !== "LIVE") return "FEED_STALE";
    if (!snapshot.consistent) return "INCONSISTENT";
    if (ask < this.config.entryTrigger || ask <= 0) return "BELOW_TRIGGER";
    if (held < this.config.entryHoldMs) return "HOLD_TIMER";
    if (secondsRemaining < this.config.minSecondsRemaining) return "TOO_LATE";
    if (askSize < this.config.tradeSizeUsd / ask) return "INSUFFICIENT_LIQUIDITY";
    return "NONE";
  }
}
