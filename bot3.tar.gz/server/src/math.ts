import type { LedgerFill, MarketSnapshot, PaperAccount, PaperPosition, PortfolioMetrics } from "./types.js";

export const stopPrice = (position: PaperPosition, stopLossUsd: number): number =>
  Math.max(0, position.entryPrice - stopLossUsd / position.shares);

export const reconcilePaperAccount = (account: PaperAccount): PaperAccount => {
  let cash = account.startingBalance;
  for (const fill of account.ledger) {
    const signed = fill.side === "BUY" ? -fill.usd - fill.fee : fill.usd - fill.fee;
    cash += signed;
  }
  const realized = deriveRoundTrips(account.ledger).reduce((sum, trade) => sum + trade.pnl, 0);
  const diff = Math.max(Math.abs(cash - account.cashBalance), Math.abs(realized - account.totalRealizedPnl));
  account.cashBalance = cash;
  account.totalRealizedPnl = realized;
  account.reconciliationDiff = diff;
  account.reconciliationStatus = diff > 0.01 ? "MISMATCH" : "RECONCILED";
  account.version += 1;
  return account;
};

export const deriveRoundTrips = (ledger: LedgerFill[]) => {
  const result: Array<{ buy: LedgerFill; sell: LedgerFill; pnl: number; pnlPercent: number }> = [];
  const open = new Map<string, LedgerFill>();
  for (const fill of ledger) {
    const key = `${fill.windowId}:${fill.outcome}`;
    if (fill.side === "BUY") open.set(key, fill);
    else {
      const buy = open.get(key);
      if (buy) {
        const pnl = fill.usd - fill.fee - buy.usd - buy.fee;
        result.push({ buy, sell: fill, pnl, pnlPercent: buy.usd ? pnl / buy.usd : 0 });
        open.delete(key);
      }
    }
  }
  return result;
};

export const calculatePortfolioMetrics = (account: PaperAccount, snapshot: MarketSnapshot): PortfolioMetrics => {
  const completed = deriveRoundTrips(account.ledger);
  const position = account.openPosition;
  const mark = position ? (position.outcome === "UP" ? snapshot.up.bid : snapshot.down.bid) : 0;
  const unrealizedPnl = position ? mark * position.shares - position.cost : 0;
  let peak = account.startingBalance;
  let equity = account.startingBalance;
  let maxDrawdown = 0;
  for (const trade of completed) {
    equity += trade.pnl;
    peak = Math.max(peak, equity);
    maxDrawdown = Math.max(maxDrawdown, peak - equity);
  }
  equity = account.cashBalance + (position ? mark * position.shares : 0);
  const wins = completed.filter((trade) => trade.pnl > 0);
  const losses = completed.filter((trade) => trade.pnl < 0);
  const grossWins = wins.reduce((sum, trade) => sum + trade.pnl, 0);
  const grossLosses = Math.abs(losses.reduce((sum, trade) => sum + trade.pnl, 0));
  const exitReasons: Record<string, number> = {};
  for (const trade of completed) exitReasons[trade.sell.reason] = (exitReasons[trade.sell.reason] ?? 0) + 1;
  return {
    realizedPnl: account.totalRealizedPnl,
    unrealizedPnl,
    equity,
    cash: account.cashBalance,
    trades: completed.length,
    wins: wins.length,
    losses: losses.length,
    winRate: completed.length ? wins.length / completed.length : 0,
    avgWin: wins.length ? grossWins / wins.length : 0,
    avgLoss: losses.length ? -grossLosses / losses.length : 0,
    profitFactor: grossLosses ? grossWins / grossLosses : grossWins ? Infinity : 0,
    maxDrawdown,
    bestTrade: wins.length ? Math.max(...wins.map((trade) => trade.pnl)) : 0,
    worstTrade: losses.length ? Math.min(...losses.map((trade) => trade.pnl)) : 0,
    exitReasons
  };
};
