import { describe, expect, it } from "vitest";
import { EntryEngine } from "./entryEngine.js";
import { config } from "./config.js";
import { PaperExecutor } from "./paperExecutor.js";
import type { MarketSnapshot, PaperAccount } from "./types.js";

const account = (): PaperAccount => ({ startingBalance: 100, cashBalance: 100, totalRealizedPnl: 0, openPosition: null, ledger: [], version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0 });
const snapshot = (secondsRemaining: number): MarketSnapshot => ({
  windowId: "w",
  windowStart: 0,
  windowEnd: secondsRemaining,
  up: { bid: 0.95, ask: 0.958, bidSize: 10, askSize: 20, lastUpdateTs: 1000 },
  down: { bid: 0.04, ask: 0.05, bidSize: 20, askSize: 20, lastUpdateTs: 1000 },
  feedHealth: "LIVE",
  consistent: true,
  feedMessage: "Live prices flowing"
});

describe("entry visibility and decisions", () => {
  it("buys after a held trigger with time and liquidity", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(113), 0);
    engine.tick(snapshot(113), 1000);
    expect(paper.ledger).toHaveLength(1);
    expect(paper.ledger[0]?.outcome).toBe("UP");
  });
  it("blocks an otherwise eligible entry when too late", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(80), 0);
    engine.tick(snapshot(80), 1000);
    expect(paper.ledger).toHaveLength(0);
    expect(engine.getStatuses().UP.decision).toBe("TOO_LATE");
  });
  it("takes profit from bid without ask liquidity or reconciliation", () => {
    const paper = account();
    paper.cashBalance = 90;
    paper.reconciliationStatus = "MISMATCH";
    paper.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.windowId = "old";
    current.down = { bid: 0.99, ask: 1, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 1000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("TAKE_PROFIT");
  });
  it("settles an older position at resolved 1.00 or 0.00", async () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    engine.tick({ ...snapshot(100), windowId: "new" }, 1000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.price).toBe(1);
    const second = account();
    second.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const secondEngine = new EntryEngine(config, second, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    secondEngine.tick({ ...snapshot(100), windowId: "new" }, 1000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(second.openPosition).toBeNull();
    expect(second.ledger.at(-1)?.price).toBe(0);
  });
  it("recovers a stale startup position", async () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "DOWN", price: 0 }), 0);
    await engine.recoverStalePosition(1000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("SETTLEMENT");
  });
});
