import type { Outcome, Resolution } from "./types.js";

interface GammaMarket {
  outcomes?: string | string[];
  outcomePrices?: string | string[];
}
interface GammaEvent {
  markets?: GammaMarket[];
}

const parseList = (value: string | string[] | undefined): string[] => {
  if (Array.isArray(value)) return value;
  if (!value) return [];
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
};

export const lookupResolution = async (windowStart: number): Promise<Resolution | null> => {
  const slug = `btc-updown-15m-${windowStart}`;
  const response = await fetch(`https://gamma-api.polymarket.com/events?slug=${encodeURIComponent(slug)}`);
  if (!response.ok) throw new Error(`Gamma resolution HTTP ${response.status}`);
  const payload: unknown = await response.json();
  const market = Array.isArray(payload) ? (payload[0] as GammaEvent | undefined)?.markets?.[0] : undefined;
  if (!market) return null;
  const outcomes = parseList(market.outcomes);
  const prices = parseList(market.outcomePrices).map(Number);
  const resolvedIndex = prices.findIndex((price) => price === 0 || price === 1);
  if (resolvedIndex < 0) return null;
  const resolvedPrice = prices[resolvedIndex];
  if (resolvedPrice === undefined) return null;
  const label = outcomes[resolvedIndex]?.trim().toUpperCase();
  if (label !== "UP" && label !== "DOWN") return null;
  return { outcome: label, price: resolvedPrice };
};
