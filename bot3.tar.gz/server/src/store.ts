import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import type { PaperAccount } from "./types.js";
import { config } from "./config.js";
const statePath = join(process.cwd(), "data", "bot_state.json");
export const freshAccount = (): PaperAccount => ({ startingBalance: config.startingBalance, cashBalance: config.startingBalance, totalRealizedPnl: 0, openPosition: null, ledger: [], version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0 });
export const loadAccount = async (): Promise<PaperAccount> => {
  try { return JSON.parse(await readFile(statePath, "utf8")) as PaperAccount; } catch { return freshAccount(); }
};
export const saveAccount = async (account: PaperAccount): Promise<void> => {
  await mkdir(dirname(statePath), { recursive: true });
  const temp = `${statePath}.tmp`;
  await writeFile(temp, JSON.stringify(account, null, 2), "utf8");
  await rename(temp, statePath);
};
