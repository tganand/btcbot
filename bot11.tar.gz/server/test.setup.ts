import { mkdtempSync } from "node:fs";
import { readdirSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll } from "vitest";

process.env.DATA_DIR = mkdtempSync(join(tmpdir(), "polymarket-paper-terminal-test-"));

const realDataDir = join(process.cwd(), "data");
const snapshot = (path: string): string => {
  try {
    const stat = statSync(path);
    if (stat.isDirectory()) return `dir:${readdirSync(path).sort().join(",")}`;
    return `file:${stat.size}:${stat.mtimeMs}`;
  } catch {
    return "missing";
  }
};
const realStateBefore = snapshot(join(realDataDir, "bot_state.json"));
const realArchiveBefore = snapshot(join(realDataDir, "archive"));

afterAll(() => {
  if (snapshot(join(realDataDir, "bot_state.json")) !== realStateBefore || snapshot(join(realDataDir, "archive")) !== realArchiveBefore) {
    throw new Error("Tests wrote to the real data directory");
  }
});
