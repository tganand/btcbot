import { describe, expect, it } from "vitest";
import { join, resolve } from "node:path";
import { config } from "./config.js";
import { freshAccount, resetAccountState, saveAccount, statePath } from "./store.js";

describe("serialized persistence", () => {
  it("uses a temporary data directory and never the real data folder", () => {
    const realDataDir = resolve(process.cwd(), "data");
    expect(resolve(config.dataDir)).not.toBe(realDataDir);
    expect(resolve(statePath)).not.toBe(join(realDataDir, "bot_state.json"));
    expect(join(realDataDir, "bot_state.json")).not.toBe(statePath);
  });

  it("handles concurrent saves without rename races", async () => {
    await expect(Promise.all(Array.from({ length: 20 }, (_, index) => {
      const account = freshAccount();
      account.version = index;
      return saveAccount(account);
    }))).resolves.toHaveLength(20);
  });
  it("archives and refuses reset while a position is open", async () => {
    const account = freshAccount();
    await saveAccount(account);
    account.openPosition = { outcome: "UP", windowId: "w", entryPrice: 0.9, shares: 10, cost: 9, openedAt: Date.now() };
    await expect(resetAccountState(account)).rejects.toThrow("Close the open trade first");
    account.openPosition = null;
    await expect(resetAccountState(account)).resolves.toBe(account);
    expect(account.ledger).toHaveLength(0);
    expect(account.cashBalance).toBe(100);
  });
});
