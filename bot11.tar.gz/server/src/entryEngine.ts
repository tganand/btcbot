import { PaperExecutor } from "./paperExecutor.js";
import { deriveRoundTrips, stopPrice } from "./math.js";
import type { EngineConfig } from "./config.js";
import type { EntryDecision, EntryStatus, LedgerFill, MarketSnapshot, Outcome, PaperAccount, PaperPosition, PostExitTracking, Resolution } from "./types.js";

interface SideState { aboveSince: number | null; lastLoggedSecond: number; }
type ResolvePosition = (position: NonNullable<PaperAccount["openPosition"]>) => Promise<Resolution | null>;

export class EntryEngine {
  private readonly state: Record<Outcome, SideState> = { UP: { aboveSince: null, lastLoggedSecond: -1 }, DOWN: { aboveSince: null, lastLoggedSecond: -1 } };
  private readonly statuses: Record<Outcome, EntryStatus>;
  private readonly warmupUntil: number;
  private enteredWindow = "";
  private exitInFlight = false;
  private pendingSince = 0;
  private nextResolutionPollAt = 0;
  private lastExitLogSecond = -1;
  private postExitPollInFlight = false;
  public constructor(
    private readonly config: EngineConfig,
    private readonly account: PaperAccount,
    private readonly executor: PaperExecutor,
    private readonly onAccountChange: () => void,
    private readonly resolvePosition: ResolvePosition,
    private readonly startedAt = Date.now()
  ) {
    this.warmupUntil = startedAt + 1000;
    this.statuses = { UP: this.emptyStatus(), DOWN: this.emptyStatus() };
  }
  private emptyStatus(): EntryStatus {
    return { ask: 0, trigger: this.config.entryTrigger, msHeldAboveTrigger: 0, secondsRemaining: 0, feedHealth: "DISCONNECTED", consistent: false, positionOpen: false, askSize: 0, decision: "FEED_STALE" };
  }
  public getStatuses(): Record<Outcome, EntryStatus> { return { UP: { ...this.statuses.UP }, DOWN: { ...this.statuses.DOWN } }; }
  public isCircuitBreakerHalted(): boolean {
    const trades = deriveRoundTrips(this.account.ledger);
    return this.account.totalRealizedPnl <= -this.config.circuitBreakerLossLimit || (trades.length >= 3 && trades.slice(-3).every((trade) => trade.pnl < 0));
  }
  public async recoverStalePosition(now = Date.now()): Promise<void> {
    const position = this.account.openPosition;
    if (position) await this.settle(position, 0, now);
  }

  public tick(snapshot: MarketSnapshot, now = Date.now()): void {
    try {
      if (this.account.openPosition) {
        this.evaluateExit(snapshot, now);
        return;
      }
      void this.updatePostExitTracking(snapshot, now);
      if (snapshot.windowId !== this.enteredWindow) {
        this.enteredWindow = snapshot.windowId;
        this.state.UP.aboveSince = null;
        this.state.DOWN.aboveSince = null;
        this.state.UP.lastLoggedSecond = -1;
        this.state.DOWN.lastLoggedSecond = -1;
      }
      for (const outcome of ["UP", "DOWN"] as const) this.evaluateEntry(snapshot, outcome, now);
    } catch (error) {
      console.error(`[engine] tick error: ${error instanceof Error ? error.stack ?? error.message : String(error)}`);
    }
  }

  private evaluateExit(snapshot: MarketSnapshot, now: number): void {
    const position = this.account.openPosition;
    if (!position || this.exitInFlight) return;
    const book = position.outcome === "UP" ? snapshot.up : snapshot.down;
    const opposite = position.outcome === "UP" ? snapshot.down.bid : snapshot.up.bid;
    const secondsRemaining = snapshot.windowEnd - now / 1000;
    const sl = position.stopLossPrice ?? stopPrice(position, position.stopLossUsd ?? this.config.stopLossUsd);
    const tp = position.takeProfitPrice ?? this.config.takeProfit;
    let decision = "HOLD";
    const lastTradeAt = this.account.lastEntryExitByOutcome[position.outcome];
    if (lastTradeAt !== undefined && Math.floor(lastTradeAt / 1000) === Math.floor(now / 1000)) {
      decision = "HOLD";
    } else if (book.bid >= tp - 1e-9) decision = "TAKE_PROFIT";
    else if (position.windowId !== snapshot.windowId || secondsRemaining <= 0) decision = "WINDOW_END";
    else if (book.bid <= sl + 1e-4) decision = "STOP_LOSS";
    else if (opposite >= this.config.reversalPrice) decision = "REVERSAL";
    const second = Math.floor(now / 1000);
    if (second !== this.lastExitLogSecond) {
      this.lastExitLogSecond = second;
      const pnl = book.bid * position.shares - position.cost;
      console.log(`[exit] ${position.outcome} bid=${book.bid.toFixed(5)} tp=${tp.toFixed(5)} sl=${sl.toFixed(5)} unrealizedPnl=${pnl.toFixed(4)} secondsRemaining=${secondsRemaining.toFixed(1)} decision=${decision}`);
    }
    if (decision === "TAKE_PROFIT" || decision === "STOP_LOSS" || decision === "REVERSAL") {
      this.closeAtPrice(decision, book.bid, now, decision === "STOP_LOSS" ? sl : decision === "REVERSAL" ? this.config.reversalPrice : this.config.takeProfit);
    } else if (decision === "WINDOW_END") {
      void this.settle(position, book.bid, now);
    }
  }

  private closeAtPrice(reason: string, price: number, now: number, triggerPrice: number): void {
    const position = this.account.openPosition;
    if (!position) return;
    this.exitInFlight = true;
    try {
      const fill = this.executor.sell(this.account, position.windowId, position.outcome, position.shares, price, reason, now, triggerPrice);
      if (reason === "STOP_LOSS" || reason === "REVERSAL") this.startPostExitTracking(fill, position, now);
      this.account.openPosition = null;
      this.account.lastEntryExitByOutcome[position.outcome] = now;
      this.onAccountChange();
    } finally { this.exitInFlight = false; }
  }

  private startPostExitTracking(fill: LedgerFill, position: PaperPosition, now: number): void {
    const tracking: PostExitTracking = { outcome: position.outcome, bestBidAfterExit: 0, finalResult: "pending", verdict: "PENDING", windowStart: position.windowStart, updatedAt: now };
    fill.outcomeAfterExit = tracking;
    this.account.postExitTracking ??= {};
    this.account.postExitTracking[fill.id] = tracking;
  }

  private async updatePostExitTracking(snapshot: MarketSnapshot, now: number): Promise<void> {
    const trackingMap = this.account.postExitTracking;
    if (!trackingMap || this.postExitPollInFlight) return;
    const entries = Object.entries(trackingMap);
    if (!entries.length) return;
    for (const [fillId, tracking] of entries) {
      const sideBid = tracking.outcome === "UP" ? snapshot.up.bid : snapshot.down.bid;
      if (snapshot.windowId === this.findFill(fillId)?.windowId && sideBid > tracking.bestBidAfterExit) tracking.bestBidAfterExit = sideBid;
      const windowStart = tracking.windowStart ?? Math.floor(now / 1000 / 900) * 900;
      const ended = now >= (windowStart + 900) * 1000;
      if (tracking.finalResult !== "pending" || (!ended && snapshot.windowId === this.findFill(fillId)?.windowId)) continue;
      if (ended && now - tracking.updatedAt < 5000) continue;
      this.postExitPollInFlight = true;
      try {
        const resolution = await this.resolvePosition({ outcome: tracking.outcome, windowId: this.findFill(fillId)?.windowId ?? "", windowStart, entryPrice: 0, shares: 1, cost: 0, openedAt: now });
        if (resolution) {
          tracking.finalResult = resolution.outcome;
          tracking.verdict = resolution.outcome === tracking.outcome ? "WOULD_HAVE_WON" : "STOP_WAS_RIGHT";
          tracking.updatedAt = now;
          const fill = this.findFill(fillId);
          if (fill) fill.outcomeAfterExit = tracking;
          this.onAccountChange();
        } else if (ended) {
          tracking.updatedAt = now;
          this.onAccountChange();
        }
      } catch (error) {
        console.error(`[engine] post-exit tracking error: ${error instanceof Error ? error.message : String(error)}`);
      } finally {
        this.postExitPollInFlight = false;
      }
    }
  }

  private findFill(id: string): LedgerFill | undefined {
    return this.account.ledger.find((fill) => fill.id === id);
  }

  private async settle(position: NonNullable<PaperAccount["openPosition"]>, lastBid: number, now: number): Promise<void> {
    if (this.exitInFlight) return;
    if (now < this.nextResolutionPollAt) return;
    this.exitInFlight = true;
    this.nextResolutionPollAt = now + 5000;
    try {
      if (!this.pendingSince) this.pendingSince = now;
      const wasPending = position.resolutionStatus === "PENDING_RESOLUTION";
      position.resolutionStatus = "PENDING_RESOLUTION";
      if (!wasPending) this.onAccountChange();
      const windowStart = position.windowStart ?? Math.floor(position.openedAt / 1000 / 900) * 900;
      const estimatedAt = (windowStart + 900 + 600) * 1000;
      const resolution = await this.resolvePosition(position);
      if (resolution) {
        const settlementPrice = resolution.outcome === position.outcome ? 1 : 0;
        this.executor.settle(this.account, position.windowId, position.outcome, position.shares, settlementPrice, "SETTLEMENT", now);
        this.account.openPosition = null;
        this.pendingSince = 0;
        this.onAccountChange();
      } else if (now >= estimatedAt) {
        this.executor.sell(this.account, position.windowId, position.outcome, position.shares, lastBid, "SETTLEMENT_ESTIMATED", now);
        this.account.openPosition = null;
        this.pendingSince = 0;
        this.onAccountChange();
      }
    } catch (error) {
      console.error(`[engine] settlement error: ${error instanceof Error ? error.message : String(error)}`);
    } finally { this.exitInFlight = false; }
  }

  private evaluateEntry(snapshot: MarketSnapshot, outcome: Outcome, now: number): void {
    const book = outcome === "UP" ? snapshot.up : snapshot.down;
    const secondsRemaining = Math.max(0, snapshot.windowEnd - now / 1000);
    if (book.ask >= this.config.entryTrigger) this.state[outcome].aboveSince ??= now;
    else this.state[outcome].aboveSince = null;
    const held = this.state[outcome].aboveSince === null ? 0 : now - this.state[outcome].aboveSince;
    const decision = this.openPositionIfEligible(snapshot, outcome, book.ask, book.askSize, held, secondsRemaining, now);
    const status = this.statuses[outcome] = { ask: book.ask, trigger: this.config.entryTrigger, msHeldAboveTrigger: held, secondsRemaining, feedHealth: snapshot.feedHealth, consistent: snapshot.consistent, positionOpen: false, askSize: book.askSize, decision };
    const second = Math.floor(now / 1000);
    if (second !== this.state[outcome].lastLoggedSecond) {
      this.state[outcome].lastLoggedSecond = second;
      console.log(`[entry] ${outcome} ask=${book.ask.toFixed(4)} trigger=${this.config.entryTrigger.toFixed(4)} heldMs=${held} secondsRemaining=${secondsRemaining.toFixed(1)} feed=${snapshot.feedHealth} consistent=${snapshot.consistent} positionOpen=false askSize=${book.askSize} decision=${status.decision}`);
    }
  }
  private openPositionIfEligible(snapshot: MarketSnapshot, outcome: Outcome, ask: number, askSize: number, held: number, secondsRemaining: number, now: number): EntryDecision {
    if (this.account.openPosition) return "POSITION_OPEN";
    if (now < this.warmupUntil) return "WARMUP";
    if (snapshot.feedHealth !== "LIVE") return "FEED_STALE";
    if (ask < this.config.entryTrigger || ask <= 0) return "BELOW_TRIGGER";
    if (askSize < this.config.tradeSizeUsd / ask) return "INSUFFICIENT_LIQUIDITY";
    if (ask > this.config.maxEntryPrice) return "ABOVE_MAX_ENTRY";
    if (this.account.entriesThisWindow[snapshot.windowId]) return "ALREADY_TRADED_THIS_WINDOW";
    if (this.isCircuitBreakerHalted()) return "HALTED_BY_CIRCUIT_BREAKER";
    if (!snapshot.consistent) return "INCONSISTENT";
    if (held < this.config.entryHoldMs) return "HOLD_TIMER";
    if (secondsRemaining < this.config.minSecondsRemaining) return "TOO_LATE";
    const simulatedFill = ask * (1 + this.config.slippageBps / 10000);
    if (simulatedFill < 0.01 || simulatedFill > 0.99) return "PRICE_OUT_OF_RANGE";
    if (simulatedFill >= this.config.takeProfit - 0.02) return "NO_UPSIDE";
    const lastTradeAt = this.account.lastEntryExitByOutcome[outcome];
    if (lastTradeAt !== undefined && Math.floor(lastTradeAt / 1000) === Math.floor(now / 1000)) return "ALREADY_TRADED_THIS_WINDOW";
    const fill = this.executor.buy(this.account, snapshot.windowId, outcome, ask, now);
    if (!fill) return "PRICE_OUT_OF_RANGE";
    const cost = fill.usd + fill.fee;
    const settings = { triggerPrice: this.config.entryTrigger, takeProfitPrice: this.config.takeProfit, stopLossPrice: Math.max(0, fill.price - this.config.stopLossUsd / fill.shares), stopLossUsd: this.config.stopLossUsd, maxEntryPrice: this.config.maxEntryPrice };
    Object.assign(fill, settings);
    this.account.openPosition = { outcome, windowId: snapshot.windowId, windowStart: snapshot.windowStart, entryPrice: fill.price, shares: fill.shares, cost, openedAt: now, ...settings };
    this.account.entriesThisWindow[snapshot.windowId] = true;
    this.account.lastEntryExitByOutcome[outcome] = now;
    this.onAccountChange();
    return "NONE";
  }
}
