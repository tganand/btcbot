import type { LedgerFill, MarketSnapshot, PaperAccount, PaperPosition, PortfolioMetrics } from "./types.js";

export const feeForFill = (shares: number, price: number, feeRate = 0.07): number =>
  shares * feeRate * price * (1 - price);

export const stopPrice = (position: PaperPosition, stopLossUsd: number, feeRate = 0): number => {
  const cost = Number.isFinite(position.cost) ? position.cost : position.entryPrice * position.shares;
  const targetProceeds = Math.max(0, cost - stopLossUsd);
  let low = 0;
  let high = 1;
  for (let index = 0; index < 60; index += 1) {
    const price = (low + high) / 2;
    const proceeds = position.shares * price - feeForFill(position.shares, price, feeRate);
    if (proceeds < targetProceeds) low = price;
    else high = price;
  }
  return high;
};

export const reconcilePaperAccount = (account: PaperAccount): PaperAccount => {
  let cash = account.startingBalance;
  for (const fill of account.ledger) {
    const signed = fill.side === "BUY" ? -fill.usd - fill.fee : fill.usd - fill.fee;
    cash += signed;
  }
  const realized = deriveRoundTrips(account.ledger).reduce((sum, trade) => sum + trade.pnl, 0);
  const cashDiff = cash - account.cashBalance;
  const realizedDiff = realized - account.totalRealizedPnl;
  const diff = Math.max(Math.abs(cashDiff), Math.abs(realizedDiff));
  if (diff > 0.01) {
    console.error(`[reconcile] MISMATCH cash diff=${cashDiff.toFixed(4)} realizedPnl diff=${realizedDiff.toFixed(4)}; healing from ledger`);
  }
  account.cashBalance = Math.max(0, cash);
  account.totalRealizedPnl = realized;
  account.reconciliationDiff = diff;
  account.reconciliationStatus = "RECONCILED";
  account.version += 1;
  return account;
};

export const markToMarketEquity = (account: PaperAccount, snapshot: MarketSnapshot, feeRate = 0.07): number => {
  const position = account.openPosition;
  if (!position) return account.cashBalance;
  const bid = position.outcome === "UP" ? snapshot.up.bid : snapshot.down.bid;
  return account.cashBalance + Math.max(0, bid * position.shares);
};

export const recordEquityPoint = (account: PaperAccount, snapshot: MarketSnapshot, now: number, feeRate = 0.07): void => {
  const equity = markToMarketEquity(account, snapshot, feeRate);
  account.equityHistory ??= [{ timestamp: now, equity: account.startingBalance }];
  const last = account.equityHistory.at(-1);
  const open = Boolean(account.openPosition);
  if (last && open && now - last.timestamp < 5000) return;
  account.equityHistory.push({ timestamp: now, equity });
  account.equityHistory = account.equityHistory.slice(-2000);
};

export const deriveRoundTrips = (ledger: LedgerFill[]) => {
  const result: Array<{ buy: LedgerFill; sell: LedgerFill; pnl: number; pnlPercent: number }> = [];
  const open = new Map<string, Array<{ fill: LedgerFill; shares: number; usd: number; fee: number }>>();
  for (const fill of ledger) {
    const key = `${fill.windowId}:${fill.outcome}`;
    if (fill.side === "BUY") {
      const positions = open.get(key) ?? [];
      positions.push({ fill, shares: fill.shares, usd: fill.usd, fee: fill.fee });
      open.set(key, positions);
      continue;
    }
    let remainingSellShares = fill.shares;
    let remainingSellUsd = fill.usd;
    let remainingSellFee = fill.fee;
    const positions = open.get(key) ?? [];
    while (remainingSellShares > 1e-10 && positions.length) {
      const position = positions[0]!;
      const closedShares = Math.min(remainingSellShares, position.shares);
      const buyRatio = closedShares / position.shares;
      const sellRatio = closedShares / remainingSellShares;
      const buy: LedgerFill = {
        ...position.fill,
        shares: closedShares,
        usd: position.usd * buyRatio,
        fee: position.fee * buyRatio
      };
      const sell: LedgerFill = {
        ...fill,
        shares: closedShares,
        usd: remainingSellUsd * sellRatio,
        fee: remainingSellFee * sellRatio
      };
      const pnl = sell.usd - sell.fee - buy.usd - buy.fee;
      result.push({ buy, sell, pnl, pnlPercent: buy.usd ? pnl / buy.usd : 0 });
      position.shares -= closedShares;
      position.usd -= buy.usd;
      position.fee -= buy.fee;
      remainingSellShares -= closedShares;
      remainingSellUsd -= sell.usd;
      remainingSellFee -= sell.fee;
      if (position.shares <= 1e-10) positions.shift();
    }
    if (positions.length) {
      open.set(key, positions);
    } else {
      open.delete(key);
    }
  }
  return result;
};

export const calculatePortfolioMetrics = (account: PaperAccount, snapshot: MarketSnapshot, feeRate = 0.07): PortfolioMetrics => {
  const completed = deriveRoundTrips(account.ledger);
  const position = account.openPosition;
  const mark = position ? (position.outcome === "UP" ? snapshot.up.bid : snapshot.down.bid) : 0;
  const unrealizedPnl = position ? mark * position.shares - feeForFill(position.shares, mark, feeRate) - position.cost : 0;
  let peak = account.startingBalance;
  let equity = account.startingBalance;
  let maxDrawdown = 0;
  for (const trade of completed) {
    equity += trade.pnl;
    peak = Math.max(peak, equity);
    maxDrawdown = Math.max(maxDrawdown, peak - equity);
  }
  equity = account.cashBalance + (position ? mark * position.shares : 0);
  const wins = completed.filter((trade) => trade.pnl > 0);
  const losses = completed.filter((trade) => trade.pnl < 0);
  const grossWins = wins.reduce((sum, trade) => sum + trade.pnl, 0);
  const grossLosses = Math.abs(losses.reduce((sum, trade) => sum + trade.pnl, 0));
  const avgWin = wins.length ? grossWins / wins.length : 0;
  const avgLoss = losses.length ? grossLosses / losses.length : 0;
  const exitReasons: Record<string, number> = {};
  for (const trade of completed) exitReasons[trade.sell.reason] = (exitReasons[trade.sell.reason] ?? 0) + 1;
  const grossPnl = completed.reduce((sum, trade) => sum + trade.sell.usd - trade.buy.usd, 0);
  const totalFees = account.ledger.reduce((sum, fill) => sum + fill.fee, 0);
  const today = new Date().toISOString().slice(0, 10);
  const todayPnl = completed.filter((trade) => new Date(trade.sell.timestamp).toISOString().slice(0, 10) === today).reduce((sum, trade) => sum + trade.pnl, 0);
  return {
    realizedPnl: account.totalRealizedPnl,
    unrealizedPnl,
    equity,
    cash: account.cashBalance,
    trades: completed.length,
    wins: wins.length,
    losses: losses.length,
    winRate: completed.length ? wins.length / completed.length : 0,
    avgWin,
    avgLoss: -avgLoss,
    profitFactor: grossLosses ? grossWins / grossLosses : grossWins ? Infinity : 0,
    maxDrawdown,
    bestTrade: wins.length ? Math.max(...wins.map((trade) => trade.pnl)) : 0,
    worstTrade: losses.length ? Math.min(...losses.map((trade) => trade.pnl)) : 0,
    exitReasons,
    expectancy: completed.length ? completed.reduce((sum, trade) => sum + trade.pnl, 0) / completed.length : 0,
    grossPnl,
    totalFees,
    missedFills: account.missedFillCount ?? account.ledger.filter((fill) => fill.reason === "MISSED_FILL").length,
    todayPnl,
    breakEvenWinRate: avgWin + avgLoss ? avgLoss / (avgWin + avgLoss) : 0
  };
};

const csvCell = (value: string | number | boolean | undefined): string => {
  const text = value === undefined ? "" : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
};

export const buildTradesCsv = (ledger: LedgerFill[]): string => {
  const header = ["trade no", "window slug", "outcome", "entry time", "exit time", "seconds left at entry", "entry decision price", "entry fill", "exit decision price", "exit fill", "shares", "gross PnL", "fees", "net PnL", "exit reason", "delayMs", "empty book flag", "rules version"];
  const rows = deriveRoundTrips(ledger).map((trade, index) => {
    const gross = trade.sell.usd - trade.buy.usd;
    return [
      index + 1, trade.buy.windowSlug ?? trade.buy.windowId, trade.buy.outcome, new Date(trade.buy.timestamp).toISOString(),
      new Date(trade.sell.timestamp).toISOString(), trade.buy.secondsRemainingAtEntry,
      trade.buy.decisionPrice ?? trade.buy.price, trade.buy.fillPrice ?? trade.buy.price,
      trade.sell.decisionPrice ?? trade.sell.price, trade.sell.fillPrice ?? trade.sell.price,
      trade.buy.shares, gross, trade.buy.fee + trade.sell.fee, trade.pnl, trade.sell.reason,
      Number(trade.buy.delayMs ?? 0) + Number(trade.sell.delayMs ?? 0), trade.sell.emptyBook ?? false, trade.buy.rulesVersion
    ].map(csvCell).join(",");
  });
  return [header.map(csvCell).join(","), ...rows].join("\r\n");
};
