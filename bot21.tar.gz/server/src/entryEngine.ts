import { PaperExecutor, sharesForBudget } from "./paperExecutor.js";
import { deriveRoundTrips, feeForFill, stopPrice } from "./math.js";
import { defaultAccountRules, type EngineConfig } from "./config.js";
import type { TelegramTradeNotice } from "./telegram.js";
import type { AccountId, AccountRules, EntryDecision, EntryStatus, LedgerFill, MarketSnapshot, Outcome, PaperAccount, PaperPosition, PendingOrder, PostExitTracking, Resolution } from "./types.js";

interface SideState { aboveSince: number | null; lastLoggedSecond: number; lastLoggedDecision: string; }
type ResolvePosition = (position: NonNullable<PaperAccount["openPosition"]>) => Promise<Resolution | null>;
export interface EntryEnginePolicy {
  windowSeconds?: number;
  holdToResolution?: boolean;
  continuousEntryBand?: boolean;
  strictlyExceedsHold?: boolean;
}

export class EntryEngine {
  private readonly state: Record<Outcome, SideState> = { UP: { aboveSince: null, lastLoggedSecond: -1, lastLoggedDecision: "" }, DOWN: { aboveSince: null, lastLoggedSecond: -1, lastLoggedDecision: "" } };
  private readonly statuses: Record<Outcome, EntryStatus>;
  private readonly warmupUntil: number;
  private enteredWindow = "";
  private exitInFlight = false;
  private pendingSince = 0;
  private nextResolutionPollAt = 0;
  private lastExitLogSecond = -1;
  private postExitPollInFlight = false;
  private pendingOrder: PendingOrder | null = null;
  private readonly exitContext: NonNullable<LedgerFill["exitContext"]> = [];
  public constructor(
    private readonly config: EngineConfig,
    private readonly account: PaperAccount,
    private readonly executor: PaperExecutor,
    private readonly onAccountChange: () => void,
    private readonly resolvePosition: ResolvePosition,
    private readonly startedAt = Date.now(),
    private readonly accountId: AccountId = "mine",
    public rules: AccountRules = defaultAccountRules(accountId),
    private readonly random: () => number = Math.random,
    private readonly clock: () => number = Date.now,
    private readonly policy: EntryEnginePolicy = {},
    private readonly onTradeNotice?: (notice: Omit<TelegramTradeNotice, "market" | "mode">) => void
  ) {
    this.warmupUntil = startedAt + 1000;
    this.statuses = { UP: this.emptyStatus(), DOWN: this.emptyStatus() };
  }

  private recordExitContext(snapshot: MarketSnapshot, now: number): void {
    const secondsRemaining = Math.max(0, snapshot.windowEnd - now / 1000);
    this.exitContext.push({ timestamp: now, up: { ...snapshot.up }, down: { ...snapshot.down }, secondsRemaining });
    while (this.exitContext.length && now - this.exitContext[0]!.timestamp > 10000) this.exitContext.shift();
  }
  private emptyStatus(): EntryStatus {
    return { ask: 0, trigger: this.rules.entryMin, msHeldAboveTrigger: 0, secondsRemaining: 0, feedHealth: "DISCONNECTED", consistent: false, positionOpen: false, askSize: 0, decision: "FEED_STALE" };
  }
  public getStatuses(): Record<Outcome, EntryStatus> { return { UP: { ...this.statuses.UP }, DOWN: { ...this.statuses.DOWN } }; }
  public getPendingOrder(): PendingOrder | null { return this.pendingOrder ? { ...this.pendingOrder } : null; }
  public cancelPendingOrder(reason: string): void {
    if (!this.pendingOrder) return;
    console.info(`[${this.accountId}][engine] dropped pending ${this.pendingOrder.side} order: ${reason}`);
    this.pendingOrder = null;
  }
  public async recoverStalePosition(now = Date.now()): Promise<void> {
    const position = this.account.openPosition;
    if (!position) return;
    const windowStart = position.windowStart ?? Math.floor(position.openedAt / 1000 / 3600) * 3600;
    const windowEnd = position.windowEnd ?? windowStart + (this.policy.windowSeconds ?? 3600);
    if (now >= windowEnd * 1000) await this.settle(position, 0, now);
    else console.info(`[${this.accountId}][engine] recovered open ${position.outcome} position; continuing paper management`);
  }

  public tick(snapshot: MarketSnapshot, now = this.clock()): void {
    try {
      if (this.pendingOrder) {
        if (this.pendingOrder.side === "SELL" && this.account.openPosition) {
          this.recordExitContext(snapshot, now);
          const second = Math.floor(now / 1000);
          if (second !== this.lastExitLogSecond) {
            this.lastExitLogSecond = second;
            console.log(`[${this.accountId}][exit] ${this.pendingOrder.outcome} bid=${(this.pendingOrder.outcome === "UP" ? snapshot.up.bid : snapshot.down.bid).toFixed(5)} decision=PENDING_${this.pendingOrder.reason} secondsRemaining=${Math.max(0, snapshot.windowEnd - now / 1000).toFixed(1)}`);
          }
        }
        this.processPendingOrder(snapshot, now);
        return;
      }
      if (this.account.openPosition) {
        this.evaluateExit(snapshot, now);
        this.processDuePending(snapshot, now);
        return;
      }
      void this.updatePostExitTracking(snapshot, now);
      if (snapshot.windowId !== this.enteredWindow) {
        this.enteredWindow = snapshot.windowId;
        this.state.UP.aboveSince = null;
        this.state.DOWN.aboveSince = null;
        this.state.UP.lastLoggedSecond = -1;
        this.state.DOWN.lastLoggedSecond = -1;
        this.state.UP.lastLoggedDecision = "";
        this.state.DOWN.lastLoggedDecision = "";
      }
      for (const outcome of ["UP", "DOWN"] as const) {
        this.evaluateEntry(snapshot, outcome, now);
        if (this.pendingOrder) {
          this.processDuePending(snapshot, now);
          return;
        }
      }
    } catch (error) {
      console.error(`[${this.accountId}][engine] tick error: ${error instanceof Error ? error.stack ?? error.message : String(error)}`);
    }
  }

  private evaluateExit(snapshot: MarketSnapshot, now: number): void {
    const position = this.account.openPosition;
    if (!position || this.exitInFlight) return;
    const book = position.outcome === "UP" ? snapshot.up : snapshot.down;
    const opposite = position.outcome === "UP" ? snapshot.down.bid : snapshot.up.bid;
    const secondsRemaining = snapshot.windowEnd - now / 1000;
    this.recordExitContext(snapshot, now);
    const rules = position.rules ?? this.rules;
    const sl = position.stopLossPrice ?? (position.stopLossPriceOffset !== undefined ? Math.max(0, position.entryPrice - position.stopLossPriceOffset) : stopPrice(position, position.stopLossUsd ?? rules.stopLossUsd, this.config.feeRate));
    const tp = position.takeProfitPrice ?? rules.target;
    let decision = "HOLD";
    const lastTradeAt = this.account.lastEntryExitByOutcome[position.outcome];
    if (position.windowId !== snapshot.windowId || secondsRemaining <= 0) decision = "WINDOW_END";
    else if (book.bid <= 0 || book.bidSize <= 0 || !book.lastUpdateTs || now - book.lastUpdateTs > 3000) decision = "HOLD";
    else if (this.policy.holdToResolution) {
      if (book.bid >= tp - 1e-9) decision = "TAKE_PROFIT";
    } else if (lastTradeAt !== undefined && Math.floor(lastTradeAt / 1000) === Math.floor(now / 1000)) {
      decision = "HOLD";
    } else if (book.bid >= tp - 1e-9) decision = "TAKE_PROFIT";
    else if (book.bid <= sl + 1e-4) decision = "STOP_LOSS";
    else if (opposite >= rules.reversalPrice) decision = "REVERSAL";
    const second = Math.floor(now / 1000);
    if (second !== this.lastExitLogSecond) {
      this.lastExitLogSecond = second;
      const pnl = book.bid * position.shares - feeForFill(position.shares, book.bid, this.config.feeRate) - position.cost;
      console.log(`[${this.accountId}][exit] ${position.outcome} bid=${book.bid.toFixed(5)} tp=${tp.toFixed(5)} sl=${sl.toFixed(5)} unrealizedPnl=${pnl.toFixed(4)} secondsRemaining=${secondsRemaining.toFixed(1)} decision=${decision}`);
    }
    if (decision === "TAKE_PROFIT" || decision === "STOP_LOSS" || decision === "REVERSAL") {
      this.closeAtPrice(decision, book.bid, now, decision === "STOP_LOSS" ? sl : decision === "REVERSAL" ? rules.reversalPrice : tp);
    } else if (decision === "WINDOW_END") {
      void this.settle(position, book.bid, now, snapshot);
    }
  }

  private closeAtPrice(reason: string, price: number, now: number, triggerPrice: number, emptyBook = false): void {
    const position = this.account.openPosition;
    if (!position) return;
    this.exitInFlight = true;
    const delayMs = this.delay();
    this.pendingOrder = { side: "SELL", outcome: position.outcome, windowId: position.windowId, decisionPrice: price, decisionTime: now, fillAt: now + delayMs, fillDelayMs: delayMs, reason, triggerPrice, secondsRemaining: 0, emptyBook };
    this.exitInFlight = false;
    this.onAccountChange();
  }

  private delay(): number {
    const range = this.config.fillDelayMaxMs - this.config.fillDelayMinMs;
    return this.config.fillDelayMinMs + Math.max(0, Math.min(1, this.random())) * range;
  }

  private processDuePending(snapshot: MarketSnapshot, now: number): void {
    const pending = this.pendingOrder;
    if (pending && now >= pending.fillAt) this.processPendingOrder(snapshot, now);
  }

  private processPendingOrder(snapshot: MarketSnapshot, now: number): void {
    const order = this.pendingOrder;
    if (!order || now < order.fillAt) return;
    if (order.side === "BUY") {
      if (snapshot.windowId !== order.windowId) {
        this.pendingOrder = null;
        this.recordMissedFill();
        this.account.entryAttemptsThisWindow ??= {};
        this.account.entryAttemptsThisWindow[order.windowId] = (order.attempts ?? 0) + 1;
        console.log(`[${this.accountId}][entry] MISSED_FILL ${order.outcome} reason=WINDOW_ROLLOVER`);
        this.onAccountChange();
        this.onTradeNotice?.({ kind: "rejected", reason: "Window changed before the paper fill" });
        return;
      }
      const book = order.outcome === "UP" ? snapshot.up : snapshot.down;
      const fillPrice = book.ask * (1 + this.config.slippageBps / 10000);
      const fillGap = this.gapFor(snapshot, order.outcome);
      const requiredGap = this.requiredGap(secondsRemaining(snapshot, now), this.rules.minGapTable);
      const fillShares = sharesForBudget(fillPrice, this.rules.tradeSizeUsd, this.account.cashBalance, this.config.feeRate);
      const attempts = order.attempts ?? 0;
      const missed = (this.rules.enableGapFilter && (fillGap === null || fillGap < requiredGap)) || book.ask > this.rules.entryMax || fillPrice < 0.01 || fillPrice > 0.99 ||
        fillShares <= 0 || book.askSize < fillShares ||
        (this.rules.thinBookCheck && fillShares > book.askSize * 0.25);
      this.pendingOrder = null;
      if (missed) {
        this.recordMissedFill();
        this.account.entryAttemptsThisWindow ??= {};
        this.account.entryAttemptsThisWindow[order.windowId] = attempts + 1;
        console.log(`[${this.accountId}][entry] MISSED_FILL ${order.outcome} decisionPrice=${order.decisionPrice.toFixed(4)} fillAsk=${book.ask.toFixed(4)} askSize=${book.askSize.toFixed(4)} requiredShares=${fillShares.toFixed(4)} gap=${fillGap ?? "missing"} requiredGap=${requiredGap} attempts=${attempts + 1}`);
        this.onAccountChange();
        this.onTradeNotice?.({ kind: "rejected", reason: "Fill price, gap, or available ask size changed before fill" });
        return;
      }

      const fill = this.executor.buy(this.account, order.windowId, order.outcome, book.ask, now, this.rules.tradeSizeUsd);
      if (!fill) {
        this.recordMissedFill();
        this.account.entryAttemptsThisWindow ??= {};
        this.account.entryAttemptsThisWindow[order.windowId] = attempts + 1;
        this.onAccountChange();
        this.onTradeNotice?.({ kind: "rejected", reason: "Paper buy could not be funded or filled" });
        return;
      }
      fill.decisionPrice = order.decisionPrice;
      fill.delayMs = now - order.decisionTime;
      fill.secondsRemainingAtEntry = order.secondsRemaining;
      (fill as LedgerFill & { secondsLeftAtEntry?: number }).secondsLeftAtEntry = order.secondsRemaining;
      fill.rulesVersion = this.account.rulesVersion ?? 1;
      fill.windowSlug = snapshot.windowSlug ?? order.windowId;
      fill.priceToBeat = snapshot.priceToBeat ?? undefined;
      fill.btcAtEntry = snapshot.btcPrice ?? undefined;
      fill.gapAtEntry = this.gapFor(snapshot, order.outcome) ?? undefined;
      const cost = fill.usd + fill.fee;
      const stopLossPrice = this.policy.holdToResolution ? undefined : stopPrice({ entryPrice: fill.price, shares: fill.shares, cost, outcome: order.outcome, windowId: order.windowId, openedAt: now }, this.rules.stopLossUsd, this.config.feeRate);
      const settings = { triggerPrice: this.rules.entryMin, takeProfitPrice: this.rules.target, stopLossPrice, stopLossUsd: this.policy.holdToResolution ? undefined : this.rules.stopLossUsd, maxEntryPrice: this.rules.entryMax };
      Object.assign(fill, settings);
      this.account.openPosition = { outcome: order.outcome, windowId: order.windowId, windowSlug: snapshot.windowSlug ?? order.windowId, windowStart: snapshot.windowStart, windowEnd: snapshot.windowEnd, entryPrice: fill.price, shares: fill.shares, cost, openedAt: now, ...settings, rules: { ...this.rules }, rulesVersion: this.account.rulesVersion ?? 1, priceToBeat: snapshot.priceToBeat ?? undefined, btcAtEntry: snapshot.btcPrice ?? undefined, gapAtEntry: fill.gapAtEntry };
      this.account.entriesThisWindow[order.windowId] = true;
      this.account.lastEntryExitByOutcome[order.outcome] = now;
      this.onAccountChange();
      this.onTradeNotice?.({
        kind: "opened", side: order.outcome, price: fill.price, shares: fill.shares, usd: fill.usd,
        priceToBeat: snapshot.priceToBeat, btcPrice: snapshot.btcPrice, secondsLeft: order.secondsRemaining
      });
      return;
    }

    const position = this.account.openPosition;
    if (!position) { this.pendingOrder = null; return; }
    const book = order.outcome === "UP" ? snapshot.up : snapshot.down;
    if (snapshot.windowId !== position.windowId || snapshot.windowEnd <= now / 1000) {
      this.pendingOrder = null;
      void this.settle(position, book.bid, now, snapshot);
      return;
    }
    if (book.bid <= 0 || book.bidSize <= 0) {
      order.fillAt = now + 100;
      return;
    }
    this.pendingOrder = null;
    const fill = this.executor.sell(this.account, position.windowId, position.outcome, position.shares, book.bid, order.reason, now, order.triggerPrice, { decisionPrice: order.decisionPrice, delayMs: now - order.decisionTime, windowSlug: position.windowSlug });
    fill.emptyBook = order.emptyBook || book.bid <= 0 || book.bidSize <= 0;
    fill.rulesVersion = position.rulesVersion ?? this.account.rulesVersion ?? 1;
    fill.priceToBeat = position.priceToBeat;
    fill.btcAtEntry = position.btcAtEntry;
    fill.btcAtExit = snapshot.btcPrice ?? undefined;
    fill.gapAtExit = this.gapFor(snapshot, position.outcome) ?? undefined;
    if (order.reason === "STOP_LOSS" || order.reason === "REVERSAL") fill.exitContext = [...this.exitContext];
    if (order.reason === "STOP_LOSS" || order.reason === "REVERSAL") this.startPostExitTracking(fill, position, now);
    const closedCost = position.cost;
    this.account.openPosition = null;
    this.account.lastEntryExitByOutcome[position.outcome] = now;
    this.dailyPnlFor(now);
    this.onAccountChange();
    this.onTradeNotice?.({
      kind: "closed", side: position.outcome, price: fill.price, reason: this.displayExitReason(order.reason),
      pnl: fill.usd - fill.fee - closedCost,
      pnlPercent: closedCost > 0 ? (fill.usd - fill.fee - closedCost) / closedCost * 100 : 0,
      balance: this.account.cashBalance
    });
  }

  private displayExitReason(reason: string): string {
    if (reason === "TAKE_PROFIT") return "take-profit";
    if (reason === "STOP_LOSS") return "stop-loss";
    if (reason === "WINDOW_END" || reason === "SETTLEMENT" || reason === "SETTLEMENT_ESTIMATED") return "window end";
    return reason.toLowerCase().replace(/_/g, " ");
  }

  private notifySettlement(position: PaperPosition, fill: LedgerFill): void {
    const cost = position.cost;
    const pnl = fill.usd - fill.fee - cost;
    this.onTradeNotice?.({
      kind: "closed", side: position.outcome, price: fill.price, reason: "window end", pnl,
      pnlPercent: cost > 0 ? pnl / cost * 100 : 0, balance: this.account.cashBalance
    });
  }

  private recordMissedFill(): void {
    this.account.missedFillCount = (this.account.missedFillCount ?? 0) + 1;
    this.account.missedFillsByRulesVersion ??= {};
    const version = String(this.account.rulesVersion ?? 1);
    this.account.missedFillsByRulesVersion[version] = (this.account.missedFillsByRulesVersion[version] ?? 0) + 1;
  }

  private dailyPnlFor(now: number): number {
    const date = new Date(now).toISOString().slice(0, 10);
    const value = deriveRoundTrips(this.account.ledger)
      .filter((trade) => new Date(trade.sell.timestamp).toISOString().slice(0, 10) === date)
      .reduce((sum, trade) => sum + trade.pnl, 0);
    this.account.dailyPnl ??= {};
    if (this.account.dailyPnl[date] !== value) {
      this.account.dailyPnl[date] = value;
      this.onAccountChange();
    }
    return value;
  }

  private startPostExitTracking(fill: LedgerFill, position: PaperPosition, now: number): void {
    const tracking: PostExitTracking = { outcome: position.outcome, bestBidAfterExit: 0, finalResult: "pending", verdict: "PENDING", windowStart: position.windowStart, windowEnd: position.windowEnd, updatedAt: now };
    fill.outcomeAfterExit = tracking;
    this.account.postExitTracking ??= {};
    this.account.postExitTracking[fill.id] = tracking;
  }

  private async updatePostExitTracking(snapshot: MarketSnapshot, now: number): Promise<void> {
    const trackingMap = this.account.postExitTracking;
    if (!trackingMap || this.postExitPollInFlight) return;
    const entries = Object.entries(trackingMap);
    if (!entries.length) return;
    for (const [fillId, tracking] of entries) {
      const sideBid = tracking.outcome === "UP" ? snapshot.up.bid : snapshot.down.bid;
      if (snapshot.windowId === this.findFill(fillId)?.windowId && sideBid > tracking.bestBidAfterExit) tracking.bestBidAfterExit = sideBid;
        const windowStart = tracking.windowStart ?? Math.floor(now / 1000 / 3600) * 3600;
        const trackingEnd = tracking.windowEnd ?? windowStart + (this.policy.windowSeconds ?? 3600);
        const ended = now >= trackingEnd * 1000;
      if (tracking.finalResult !== "pending" || (!ended && snapshot.windowId === this.findFill(fillId)?.windowId)) continue;
      if (ended && now - tracking.updatedAt < 5000) continue;
      this.postExitPollInFlight = true;
      try {
        const resolution = await this.resolvePosition({ outcome: tracking.outcome, windowId: this.findFill(fillId)?.windowId ?? "", windowStart, entryPrice: 0, shares: 1, cost: 0, openedAt: now });
        if (resolution) {
          tracking.finalResult = resolution.outcome;
          tracking.verdict = resolution.outcome === tracking.outcome ? "WOULD_HAVE_WON" : "STOP_WAS_RIGHT";
          tracking.updatedAt = now;
          const fill = this.findFill(fillId);
          if (fill) fill.outcomeAfterExit = tracking;
          this.onAccountChange();
        } else if (ended) {
          tracking.updatedAt = now;
          this.onAccountChange();
        }
      } catch (error) {
        console.error(`[${this.accountId}][engine] post-exit tracking error: ${error instanceof Error ? error.message : String(error)}`);
      } finally {
        this.postExitPollInFlight = false;
      }
    }
  }

  private findFill(id: string): LedgerFill | undefined {
    return this.account.ledger.find((fill) => fill.id === id);
  }

  private async settle(position: NonNullable<PaperAccount["openPosition"]>, lastBid: number, now: number, snapshot?: MarketSnapshot): Promise<void> {
    if (this.exitInFlight) return;
    if (now < this.nextResolutionPollAt) return;
    this.exitInFlight = true;
    this.nextResolutionPollAt = now + 5000;
    try {
      if (!this.pendingSince) this.pendingSince = now;
      const wasPending = position.resolutionStatus === "PENDING_RESOLUTION";
      position.resolutionStatus = "PENDING_RESOLUTION";
      if (!wasPending) this.onAccountChange();
      const windowStart = position.windowStart ?? Math.floor(position.openedAt / 1000 / 3600) * 3600;
      const windowEnd = position.windowEnd ?? windowStart + (this.policy.windowSeconds ?? 3600);
      const estimatedAt = (windowEnd + 600) * 1000;
      const resolution = await this.resolvePosition(position);
      if (resolution) {
        const settlementPrice = resolution.outcome === position.outcome ? 1 : 0;
        const fill = this.executor.settle(this.account, position.windowId, position.outcome, position.shares, settlementPrice, "SETTLEMENT", now, position.windowSlug);
        fill.rulesVersion = position.rulesVersion ?? this.account.rulesVersion ?? 1;
        fill.priceToBeat = position.priceToBeat;
        fill.btcAtEntry = position.btcAtEntry;
        fill.btcAtExit = snapshot?.btcPrice ?? undefined;
        fill.gapAtExit = snapshot ? this.gapFor(snapshot, position.outcome) ?? undefined : undefined;
        this.account.openPosition = null;
        this.pendingSince = 0;
        this.dailyPnlFor(now);
        this.onAccountChange();
        this.notifySettlement(position, fill);
      } else if (now >= estimatedAt) {
        const fill = this.executor.sell(this.account, position.windowId, position.outcome, position.shares, lastBid, "SETTLEMENT_ESTIMATED", now, lastBid, { decisionPrice: lastBid, delayMs: 0, windowSlug: position.windowSlug });
        fill.rulesVersion = position.rulesVersion ?? this.account.rulesVersion ?? 1;
        fill.priceToBeat = position.priceToBeat;
        fill.btcAtEntry = position.btcAtEntry;
        fill.btcAtExit = snapshot?.btcPrice ?? undefined;
        fill.gapAtExit = snapshot ? this.gapFor(snapshot, position.outcome) ?? undefined : undefined;
        this.account.openPosition = null;
        this.pendingSince = 0;
        this.dailyPnlFor(now);
        this.onAccountChange();
        this.notifySettlement(position, fill);
      }
    } catch (error) {
      console.error(`[${this.accountId}][engine] settlement error: ${error instanceof Error ? error.message : String(error)}`);
    } finally { this.exitInFlight = false; }
  }

  private evaluateEntry(snapshot: MarketSnapshot, outcome: Outcome, now: number): void {
    const book = outcome === "UP" ? snapshot.up : snapshot.down;
    const secondsRemaining = Math.max(0, snapshot.windowEnd - now / 1000);
    const insideBand = book.ask >= this.rules.entryMin && book.ask <= this.rules.entryMax;
    if (this.policy.continuousEntryBand ? insideBand : book.ask >= this.rules.entryMin) this.state[outcome].aboveSince ??= now;
    else this.state[outcome].aboveSince = null;
    const held = this.state[outcome].aboveSince === null ? 0 : now - this.state[outcome].aboveSince;
    const decision = this.openPositionIfEligible(snapshot, outcome, book.ask, book.askSize, held, secondsRemaining, now);
    const status = this.statuses[outcome] = { ask: book.ask, trigger: this.rules.entryMin, msHeldAboveTrigger: held, secondsRemaining, feedHealth: snapshot.feedHealth, consistent: snapshot.consistent, positionOpen: false, askSize: book.askSize, decision };
    const second = Math.floor(now / 1000);
    if (decision !== this.state[outcome].lastLoggedDecision || second - this.state[outcome].lastLoggedSecond >= 10) {
      this.state[outcome].lastLoggedSecond = second;
      this.state[outcome].lastLoggedDecision = decision;
      console.log(`[${this.accountId}][entry] ${outcome} ask=${book.ask.toFixed(4)} trigger=${this.rules.entryMin.toFixed(4)} heldMs=${held} secondsRemaining=${secondsRemaining.toFixed(1)} feed=${snapshot.feedHealth} consistent=${snapshot.consistent} positionOpen=false askSize=${book.askSize} decision=${status.decision}`);
    }
  }
  private openPositionIfEligible(snapshot: MarketSnapshot, outcome: Outcome, ask: number, askSize: number, held: number, secondsRemaining: number, now: number): EntryDecision {
    if (this.account.openPosition) return "POSITION_OPEN";
    if (now < this.warmupUntil) return "WARMUP";
    if (snapshot.feedHealth !== "LIVE") return "FEED_STALE";
    if (ask < this.rules.entryMin || ask <= 0) return "BELOW_TRIGGER";
    if (askSize < this.rules.tradeSizeUsd / ask) return "INSUFFICIENT_LIQUIDITY";
    if (ask > this.rules.entryMax) return "ABOVE_MAX_ENTRY";
    if (this.rules.thinBookCheck && this.rules.tradeSizeUsd / ask > askSize * 0.25) return "THIN_BOOK";
    if (this.account.entriesThisWindow[snapshot.windowId]) return "ALREADY_TRADED_THIS_WINDOW";
    this.account.entryAttemptsThisWindow ??= {};
    if ((this.account.entryAttemptsThisWindow[snapshot.windowId] ?? 0) >= 3) return "MISSED_FILL_LIMIT";
    if (!snapshot.consistent) return "INCONSISTENT";
    if (this.policy.strictlyExceedsHold ? held <= this.rules.holdMs : held < this.rules.holdMs) return "HOLD_TIMER";
    if (secondsRemaining > this.rules.maxSecondsRemaining) return "TOO_EARLY";
    if (secondsRemaining < this.rules.minSecondsRemaining) return "TOO_LATE";
    if (this.rules.enableGapFilter) {
      const gap = this.gapFor(snapshot, outcome);
      if (gap === null) return "NO_BTC_DATA";
      if (gap < this.requiredGap(secondsRemaining, this.rules.minGapTable)) return "GAP_TOO_SMALL";
    }
    const simulatedFill = ask * (1 + this.config.slippageBps / 10000);
    if (simulatedFill < 0.01 || simulatedFill > 0.99) return "PRICE_OUT_OF_RANGE";
    if (simulatedFill >= this.rules.target - 0.02) return "NO_UPSIDE";
    const lastTradeAt = this.account.lastEntryExitByOutcome[outcome];
    if (lastTradeAt !== undefined && Math.floor(lastTradeAt / 1000) === Math.floor(now / 1000)) return "ALREADY_TRADED_THIS_WINDOW";
    const delayMs = this.delay();
    this.pendingOrder = { side: "BUY", outcome, windowId: snapshot.windowId, decisionPrice: ask, decisionTime: now, fillAt: now + delayMs, fillDelayMs: delayMs, shares: this.rules.tradeSizeUsd / simulatedFill, attempts: this.account.entryAttemptsThisWindow[snapshot.windowId] ?? 0, reason: "ENTRY", triggerPrice: this.rules.entryMin, secondsRemaining };
    this.onAccountChange();
    return "NONE";
  }

  private gapFor(snapshot: MarketSnapshot, outcome: Outcome): number | null {
    if (typeof snapshot.btcPrice !== "number" || !Number.isFinite(snapshot.btcPrice) || typeof snapshot.priceToBeat !== "number" || !Number.isFinite(snapshot.priceToBeat)) return null;
    return outcome === "UP" ? snapshot.btcPrice - snapshot.priceToBeat : snapshot.priceToBeat - snapshot.btcPrice;
  }
  private requiredGap(secondsLeft: number, table: AccountRules["minGapTable"]): number {
    return [...table].sort((a, b) => b.secondsLeft - a.secondsLeft).find((row) => secondsLeft >= row.secondsLeft)?.minGap ?? 0;
  }
}

const secondsRemaining = (snapshot: MarketSnapshot, now: number): number => Math.max(0, snapshot.windowEnd - now / 1000);
