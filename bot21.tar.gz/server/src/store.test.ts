import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { join, resolve } from "node:path";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";

let store: typeof import("./store.js");
let config: typeof import("./config.js");
let testDirectory = "";
const originalDataDir = process.env.DATA_DIR;

beforeAll(async () => {
  testDirectory = await mkdtemp(join(tmpdir(), "paper-store-test-"));
  await mkdir(testDirectory, { recursive: true });
  process.env.DATA_DIR = testDirectory;
  config = await import("./config.js");
  store = await import("./store.js");
});

afterAll(async () => {
  await rm(testDirectory, { recursive: true, force: true });
  if (originalDataDir === undefined) delete process.env.DATA_DIR;
  else process.env.DATA_DIR = originalDataDir;
});

describe("serialized persistence", () => {
  it("uses a temporary data directory and never the real data folder", () => {
    const realDataDir = resolve(process.cwd(), "data");
    expect(resolve(config.config.dataDir)).toBe(resolve(testDirectory));
    expect(resolve(config.config.dataDir)).not.toBe(realDataDir);
    expect(resolve(store.statePath)).not.toBe(join(realDataDir, "bot_state.json"));
  });
  it("handles concurrent saves without rename races", async () => {
    await expect(Promise.all(Array.from({ length: 20 }, (_, index) => {
      const account = store.freshAccount();
      account.version = index;
      return store.saveAccount(account);
    }))).resolves.toHaveLength(20);
  });
  it("migrates a legacy single account and preserves its ledger with safe defaults", async () => {
    const legacy = { startingBalance: 100, cashBalance: 90, totalRealizedPnl: 0, openPosition: null, ledger: [{ timestamp: 1000, windowId: "old-window", side: "BUY", outcome: "UP", price: 0.9, shares: 10, usd: 9, reason: "ENTRY" }] };
    await writeFile(store.statePath, JSON.stringify(legacy), "utf8");
    const loaded = await store.loadAccounts();
    expect(loaded.accounts.mine.ledger).toHaveLength(1);
    expect(loaded.accounts.mine.ledger[0]).toMatchObject({ fee: 0, slippage: 0, windowId: "old-window" });
    expect(loaded.accounts.fourHour.ledger).toHaveLength(0);
    await store.saveAccounts(loaded);
    expect(JSON.parse(await readFile(store.statePath, "utf8"))).not.toHaveProperty("accounts.claude");
  });
  it("creates independent hourly and 4-hour accounts with separate balances and ledgers", () => {
    const accounts = store.freshAccounts();
    accounts.accounts.mine.ledger.push({ id: "hourly", timestamp: 1, windowId: "h", side: "BUY", outcome: "UP", price: 0.94, shares: 1, usd: 0.94, fee: 0, slippage: 0, reason: "ENTRY" });
    expect(accounts.accounts.mine.startingBalance).toBe(100);
    expect(accounts.accounts.fourHour.startingBalance).toBe(200);
    expect(accounts.accounts.fourHour.ledger).toHaveLength(0);
    expect(accounts.accounts.fourHour.rules).toMatchObject({ entryMin: 0.91, entryMax: 0.93, holdMs: 300000, tradeSizeUsd: 150, target: 1, stopLossUsd: 0 });
  });
  it("keeps the mine ledger and drops a persisted claude account", async () => {
    const mine = store.freshAccount();
    mine.ledger.push({ id: "mine-fill", timestamp: 1000, windowId: "mine-window", side: "BUY", outcome: "UP", price: 0.94, shares: 1, usd: 0.94, fee: 0.01, slippage: 0, reason: "ENTRY" });
    await writeFile(store.statePath, JSON.stringify({ accounts: { mine, claude: store.freshAccount() } }), "utf8");
    const loaded = await store.loadAccounts();
    expect(loaded.accounts.mine.ledger).toHaveLength(1);
    await store.saveAccounts(loaded);
    expect(JSON.parse(await readFile(store.statePath, "utf8"))).not.toHaveProperty("accounts.claude");
  });
  it("upgrades old Mine defaults while preserving custom rules and the ledger", async () => {
    const mine = store.freshAccount();
    mine.rules = { entryMin: 0.91, entryMax: 0.95, holdMs: 400, target: 0.99, stopLossUsd: 1.5, reversalPrice: 0.35, tradeSizeUsd: 10, maxSecondsRemaining: 480, minSecondsRemaining: 90, oneTradePerWindow: true, enableGapFilter: true, minGapTable: [{ secondsLeft: 0, minGap: 0 }] };
    mine.ledger.push({ id: "legacy", timestamp: 1000, windowId: "old", side: "BUY", outcome: "UP", price: 0.91, shares: 1, usd: 0.91, fee: 0, slippage: 0, reason: "ENTRY" });
    await writeFile(store.statePath, JSON.stringify({ accounts: { mine, claude: store.freshAccount() } }), "utf8");
    const loaded = await store.loadAccounts();
    expect(loaded.accounts.mine.ledger).toHaveLength(1);
    expect(loaded.accounts.mine.rules).toMatchObject({ entryMin: 0.93, stopLossUsd: 10, tradeSizeUsd: 100, maxSecondsRemaining: 3600 });
    expect(loaded.accounts.mine.rulesVersion).toBe(2);
  });
  it("drops transient pending orders loaded from state", async () => {
    const logged = vi.spyOn(console, "info").mockImplementation(() => undefined);
    await writeFile(store.statePath, JSON.stringify({ accounts: { mine: { ...store.freshAccount(), pendingOrder: { side: "BUY", windowId: "w" } } } }), "utf8");
    const loaded = await store.loadAccounts();
    expect("pendingOrder" in loaded.accounts.mine).toBe(false);
    expect(logged).toHaveBeenCalledWith(expect.stringContaining("dropping non-persistent pending order"));
    logged.mockRestore();
  });
  it("archives and refuses reset while a position is open", async () => {
    const account = store.freshAccount();
    await store.saveAccount(account);
    account.openPosition = { outcome: "UP", windowId: "w", entryPrice: 0.9, shares: 10, cost: 9, openedAt: Date.now() };
    await expect(store.resetAccountState(account)).rejects.toThrow("Close the open trade first");
    account.openPosition = null;
    await expect(store.resetAccountState(account)).resolves.toBe(account);
    expect(account.ledger).toHaveLength(0);
    expect(account.cashBalance).toBe(100);
  });
});
