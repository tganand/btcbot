import { randomUUID } from "node:crypto";
import { appendFile, mkdir } from "node:fs/promises";
import { join } from "node:path";
import { deriveRoundTrips, feeForFill } from "./math.js";
import { LIVE_TRADING_CONFIG } from "./config.js";
import type { TelegramTradeNotice } from "./telegram.js";
import type { LedgerFill, MarketSnapshot, Outcome, PaperAccount, PaperPosition, Resolution } from "./types.js";

export interface LiveBookLevel { price: string; size: string; }
export interface LiveOrderBook {
  timestamp: string;
  bids: LiveBookLevel[];
  asks: LiveBookLevel[];
  min_order_size: string;
  tick_size: string;
  neg_risk: boolean;
}
export interface LiveTrade {
  id?: string;
  taker_order_id?: string;
  asset_id?: string;
  side?: string;
  size?: string;
  price?: string;
  fee_rate_bps?: string;
  fee?: string | number;
  match_time?: string;
  maker_orders?: Array<{ order_id?: string; side?: string; matched_amount?: string }>;
}
export interface LiveChainPosition {
  asset?: string;
  size?: string | number;
  avgPrice?: string | number;
  outcome?: string;
}
export interface LiveClobClient {
  getOrderBook(tokenId: string): Promise<LiveOrderBook>;
  getTickSize(tokenId: string): Promise<string>;
  getNegRisk(tokenId: string): Promise<boolean>;
  getBalanceAllowance(params: { asset_type: "COLLATERAL" }): Promise<{ balance: string }>;
  getFeeRateBps(tokenId: string): Promise<number>;
  createAndPostMarketOrder(order: { tokenID: string; amount: number; price: number; side: "BUY" | "SELL" }, options: { tickSize: string; negRisk: boolean }, orderType: "FAK"): Promise<unknown>;
  getOpenOrders(): Promise<Array<{ id?: string; asset_id?: string }>>;
  getTrades(params?: { asset_id?: string }): Promise<LiveTrade[]>;
  getPositions(): Promise<LiveChainPosition[]>;
  cancelOrders(orderIds: string[]): Promise<unknown>;
  cancelAll(): Promise<unknown>;
}

export interface LiveTradingStatus {
  enabled: boolean;
  connected: boolean;
  halted: boolean;
  alert: string | null;
  realBalance: number | null;
  positionOpen: boolean;
  stopPrice: number | null;
  minOrderSize: number | null;
  tickSize: string | null;
  lastAction: string;
  dailyPnl: number;
}

export interface LiveTradingOptions {
  client: LiveClobClient | null;
  account: PaperAccount;
  funderAddress: string;
  enabled: boolean;
  resolveWindow: (windowStart: number) => Promise<Resolution | null>;
  persist: () => Promise<void>;
  log?: (message: string) => void;
  auditDirectory?: string;
  now?: () => number;
  notifyTrade?: (notice: Omit<TelegramTradeNotice, "market" | "mode">) => void;
}

const utcDay = (timestamp: number): string => new Date(timestamp).toISOString().slice(0, 10);
const toNumber = (value: unknown): number | null => {
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : null;
};
const bookTimestampMs = (value: string): number => {
  const numeric = Number(value);
  if (Number.isFinite(numeric)) return numeric < 1e12 ? numeric * 1000 : numeric;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : 0;
};
const parseCollateralBalance = (value: string): number | null => {
  const parsed = toNumber(value);
  if (parsed === null || parsed < 0) return null;
  return parsed / 1_000_000;
};

const matchedTrades = (trades: LiveTrade[], orderId: string, side: "BUY" | "SELL"): LiveTrade[] =>
  trades.filter((trade) =>
    trade.taker_order_id === orderId
      ? trade.side?.toUpperCase() === side
      : trade.maker_orders?.some((maker) => maker.order_id === orderId && maker.side?.toUpperCase() === side)
  );

export class LiveTradingEngine {
  private readonly now: () => number;
  private readonly log: (message: string) => void;
  private readonly auditDirectory: string;
  private busy = false;
  private lastTickAt = 0;
  private nextRecoveryAt = 0;
  private recoveryRetryMs: number = LIVE_TRADING_CONFIG.RETRY_BASE_MS;
  private readonly heldSince: Record<Outcome, number | null> = { UP: null, DOWN: null };
  private lastStopReadAt = 0;
  private stopConfirmationCount = 0;
  private nextRetryAt = 0;
  private retryMs: number = LIVE_TRADING_CONFIG.RETRY_BASE_MS;
  private currentBookMeta: { minOrderSize: number | null; tickSize: string | null } = { minOrderSize: null, tickSize: null };
  private realBalance: number | null = null;
  private connected = false;
  private halted = false;
  private reconciled = false;
  private alert: string | null = null;
  private lastAction = "Waiting for market data";
  private lastFailureNoticeAt = Number.NEGATIVE_INFINITY;

  public constructor(private readonly options: LiveTradingOptions) {
    this.now = options.now ?? Date.now;
    this.log = options.log ?? console.info;
    this.auditDirectory = options.auditDirectory ?? join(process.cwd(), "data", "live-orders");
    this.halted = options.account.liveTradingHalted === true;
  }

  public getStatus(): LiveTradingStatus {
    const position = this.options.account.openPosition;
    const dailyPnl = this.options.account.dailyPnl?.[utcDay(this.now())] ?? 0;
    return {
      enabled: this.options.enabled,
      connected: this.connected,
      halted: this.halted,
      alert: this.alert,
      realBalance: this.realBalance,
      positionOpen: Boolean(position),
      stopPrice: position?.stopLossPrice ?? null,
      minOrderSize: this.currentBookMeta.minOrderSize,
      tickSize: this.currentBookMeta.tickSize,
      lastAction: this.lastAction,
      dailyPnl
    };
  }

  public reportStartupError(message: string): void {
    this.setError(message);
  }

  public async recover(snapshot: MarketSnapshot): Promise<void> {
    if (!this.options.enabled || !this.options.client || this.now() < this.nextRecoveryAt || !snapshot.windowId || !snapshot.tokenIds?.UP || !snapshot.tokenIds.DOWN) return;
    try {
      const [orders, positions] = await Promise.all([
        this.options.client.getOpenOrders(),
        this.options.client.getPositions()
      ]);
      this.connected = true;
      this.log(`[live] startup reconciliation: openOrders=${orders.length} positions=${positions.length}`);
      const relevantTokens = new Set(Object.values(snapshot.tokenIds ?? {}));
      if (this.options.account.openPosition?.tokenId) relevantTokens.add(this.options.account.openPosition.tokenId);
      const client = this.options.client;
      if (!client) return;
      const relevantOrders = orders.filter((order) => order.asset_id && relevantTokens.has(order.asset_id));
      if (relevantOrders.length) {
        await this.audit({ type: "startup-cancel", count: relevantOrders.length, outcome: "requested" });
        await client.cancelOrders(relevantOrders.flatMap((order) => order.id ? [order.id] : []));
        await this.audit({ type: "startup-cancel", count: relevantOrders.length, outcome: "completed" });
      }
      const savedPosition = this.options.account.openPosition;
      const marketPosition = savedPosition?.tokenId
        ? positions.find((position) => position.asset === savedPosition.tokenId && Number(position.size) > 0)
        : positions.find((position) => position.asset && relevantTokens.has(position.asset) && Number(position.size) > 0);
      if (savedPosition?.tokenId) {
        this.options.account.entriesThisWindow[savedPosition.windowId] = true;
        await this.recoverTrades(snapshot, savedPosition.tokenId, savedPosition.outcome, savedPosition.windowId, savedPosition.windowSlug, savedPosition.windowStart, savedPosition.windowEnd);
        if (marketPosition) {
          const shares = Number(marketPosition.size);
          const average = Number(marketPosition.avgPrice);
          if (shares > 0 && Number.isFinite(shares)) {
            const previousShares = savedPosition.shares;
            savedPosition.shares = shares;
            savedPosition.cost = previousShares > 0 ? savedPosition.cost * shares / previousShares : average * shares;
          }
          if (average > 0 && Number.isFinite(average)) savedPosition.entryPrice = average;
          this.lastAction = "Reconciled saved live position with Polymarket";
        } else {
          const buys = this.options.account.ledger.filter((fill) => fill.side === "BUY" && fill.windowId === savedPosition.windowId && fill.outcome === savedPosition.outcome);
          const sells = this.options.account.ledger.filter((fill) => fill.side === "SELL" && fill.windowId === savedPosition.windowId && fill.outcome === savedPosition.outcome);
          const remainingShares = buys.reduce((sum, fill) => sum + fill.shares, 0) - sells.reduce((sum, fill) => sum + fill.shares, 0);
          if (buys.length && remainingShares <= 1e-8) {
            this.options.account.openPosition = null;
            this.updateRealizedPnl();
            this.updateDailyPnl(this.now());
            this.lastAction = "Reconciled completed live sale from CLOB trades";
            this.notifyClosedPosition(savedPosition, "stop-loss");
          } else {
            if (remainingShares > 0 && remainingShares < savedPosition.shares) {
              savedPosition.cost *= remainingShares / savedPosition.shares;
              savedPosition.shares = remainingShares;
            }
            this.lastAction = "Resumed saved live position";
          }
        }
        this.clearRecoveredPendingOrder();
        await this.options.persist();
      } else if (marketPosition && marketPosition.asset) {
        const tokenId = marketPosition.asset;
        const outcome: Outcome = tokenId === snapshot.tokenIds?.DOWN ? "DOWN" : "UP";
        const shares = Number(marketPosition.size);
        const entryPrice = Number(marketPosition.avgPrice);
        if (Number.isFinite(shares) && shares > 0 && Number.isFinite(entryPrice) && entryPrice > 0 && snapshot.windowId) {
          const position: PaperPosition = {
            outcome, windowId: snapshot.windowId, windowSlug: snapshot.windowSlug,
            windowStart: snapshot.windowStart, windowEnd: snapshot.windowEnd,
            entryPrice, shares, cost: entryPrice * shares, openedAt: this.now(),
            stopLossUsd: LIVE_TRADING_CONFIG.STOP_LOSS_USD,
            stopLossPrice: entryPrice - LIVE_TRADING_CONFIG.STOP_LOSS_USD / shares,
            maxEntryPrice: LIVE_TRADING_CONFIG.ENTRY_MAX, live: true, tokenId
          };
          await this.recoverTrades(snapshot, tokenId, outcome, snapshot.windowId, snapshot.windowSlug, snapshot.windowStart, snapshot.windowEnd);
          this.options.account.openPosition = position;
          this.options.account.entriesThisWindow[snapshot.windowId] = true;
          this.clearRecoveredPendingOrder();
          await this.options.persist();
          this.lastAction = "Resumed live position from Polymarket";
        }
      }
      this.reconciled = true;
      this.alert = null;
      this.nextRecoveryAt = 0;
      this.recoveryRetryMs = LIVE_TRADING_CONFIG.RETRY_BASE_MS;
    } catch {
      this.connected = false;
      this.setError("Startup reconciliation failed; live entries are paused");
      this.nextRecoveryAt = this.now() + this.recoveryRetryMs;
      this.recoveryRetryMs = Math.min(this.recoveryRetryMs * 2, LIVE_TRADING_CONFIG.MAX_RETRY_MS);
      this.log("[live] startup reconciliation failed");
    }
  }

  private async recoverTrades(
    snapshot: MarketSnapshot,
    tokenId: string,
    outcome: Outcome,
    windowId: string,
    windowSlug: string | undefined,
    windowStart: number | undefined,
    windowEnd: number | undefined
  ): Promise<void> {
    const trades = await this.options.client!.getTrades({ asset_id: tokenId });
    const groups = new Map<string, { orderId: string; side: "BUY" | "SELL"; trades: LiveTrade[] }>();
    for (const trade of trades) {
      const side = trade.side?.toUpperCase();
      const orderId = trade.taker_order_id ?? trade.maker_orders?.find((maker) => maker.order_id)?.order_id ?? trade.id;
      if ((side !== "BUY" && side !== "SELL") || !orderId) continue;
      const key = `${side}:${orderId}`;
      const group = groups.get(key) ?? { orderId, side, trades: [] };
      group.trades.push(trade);
      groups.set(key, group);
    }
    for (const group of groups.values()) {
      if (this.options.account.ledger.some((fill) => fill.exchangeOrderId === group.orderId)) continue;
      const fill = this.aggregateFills(group.trades, null, group.side);
      if (!fill || fill.shares <= 0 || fill.usd <= 0) continue;
      const fee = fill.fee ?? await this.feeFromRate(tokenId, fill.shares, fill.usd / fill.shares);
      const matchedAt = group.trades.find((trade) => trade.match_time)?.match_time;
      const numericTimestamp = matchedAt ? Number(matchedAt) : NaN;
      const parsedTimestamp = matchedAt ? Date.parse(matchedAt) : NaN;
      const timestamp = Number.isFinite(parsedTimestamp) ? parsedTimestamp : Number.isFinite(numericTimestamp) ? (numericTimestamp < 1e12 ? numericTimestamp * 1000 : numericTimestamp) : this.now();
      const currentWindow = snapshot.windowId === windowId;
      const fillSnapshot = {
        ...snapshot,
        windowId,
        windowSlug,
        windowStart: windowStart ?? snapshot.windowStart,
        windowEnd: windowEnd ?? snapshot.windowEnd,
        priceToBeat: currentWindow ? snapshot.priceToBeat : null,
        btcPrice: currentWindow ? snapshot.btcPrice : null
      };
      const recovered = this.makeFill(group.side, outcome, fillSnapshot, tokenId, fill.shares, fill.usd, fee, "LIVE_RECOVERED", timestamp);
      recovered.exchangeOrderId = group.orderId;
      this.options.account.ledger.push(recovered);
      if (group.side === "BUY") this.options.account.entriesThisWindow[windowId] = true;
    }
    this.updateRealizedPnl();
    this.updateDailyPnl(this.now());
  }

  private clearRecoveredPendingOrder(): void {
    const pending = this.options.account.livePendingOrder;
    if (pending?.orderId && this.options.account.ledger.some((fill) => fill.exchangeOrderId === pending.orderId)) {
      this.options.account.livePendingOrder = undefined;
    }
  }

  public async killSwitch(): Promise<void> {
    this.halted = true;
    this.options.account.liveTradingHalted = true;
    this.alert = "LIVE TRADING HALTED";
    try { await this.options.persist(); }
    catch {
      this.setError("Kill switch active, but its state could not be saved");
      this.log("[live] kill-switch state save failed");
    }
    if (!this.options.client) return;
    try {
      await this.audit({ type: "kill-switch-cancel-all", outcome: "requested" });
      await this.options.client.cancelAll();
      await this.audit({ type: "kill-switch-cancel-all", outcome: "completed" });
      this.lastAction = "Kill switch active; all open orders cancelled";
    } catch {
      this.setError("Kill switch active; cancellation failed, retry required");
      this.log("[live] kill-switch cancellation failed");
    }
  }

  public async tick(snapshot: MarketSnapshot, now = this.now()): Promise<void> {
    if (!this.options.enabled || !this.options.client || this.busy) return;
    this.busy = true;
    try {
      if (!snapshot.windowId || !snapshot.tokenIds?.UP || !snapshot.tokenIds.DOWN) {
        this.lastAction = "Waiting for active 1H market";
        return;
      }
      if (now - this.lastTickAt < 900) return;
      this.lastTickAt = now;
      if (now < this.nextRetryAt) return;
      if (!this.reconciled) {
        await this.recover(snapshot);
        return;
      }
      if (this.options.account.livePendingOrder) {
        await this.reconcilePending(snapshot, now);
        return;
      }
      if (this.options.account.openPosition) {
        await this.managePosition(snapshot, now);
        return;
      }
      if (this.halted) return;
      await this.refreshRealBalance();
      const dailyPnl = this.options.account.dailyPnl?.[utcDay(now)] ?? 0;
      if (dailyPnl <= -LIVE_TRADING_CONFIG.MAX_DAILY_LOSS) {
        this.lastAction = "Daily loss limit reached";
        return;
      }
      if (snapshot.feedHealth !== "LIVE" || !snapshot.consistent) {
        this.lastAction = "Waiting for a fresh, consistent book";
        this.resetEntryTimers();
        return;
      }
      for (const outcome of ["UP", "DOWN"] as const) {
        const quote = outcome === "UP" ? snapshot.up : snapshot.down;
        const inside = quote.ask >= LIVE_TRADING_CONFIG.ENTRY_MIN && quote.ask <= LIVE_TRADING_CONFIG.ENTRY_MAX;
        if (!inside) {
          this.heldSince[outcome] = null;
          continue;
        }
        this.heldSince[outcome] ??= now;
        if (now - this.heldSince[outcome]! <= LIVE_TRADING_CONFIG.HOLD_SECONDS * 1000) {
          this.lastAction = `${outcome} holding entry band`;
          continue;
        }
        const decision = this.entryFilter(snapshot, outcome, now);
        if (decision) {
          this.lastAction = decision;
          this.notifyFailure(decision, now);
          continue;
        }
        await this.placeBuy(snapshot, outcome, now);
        break;
      }
    } catch {
      this.setError("Live trading API error; retrying with backoff");
      this.notifyFailure("Live API error; retrying", now);
      this.log("[live] tick failed; retry scheduled");
      this.scheduleRetry(now);
    } finally {
      this.busy = false;
    }
  }

  private entryFilter(snapshot: MarketSnapshot, outcome: Outcome, now: number): string | null {
    const account = this.options.account;
    const secondsRemaining = snapshot.windowEnd - now / 1000;
    if (account.entriesThisWindow[snapshot.windowId]) return "Already entered this window";
    if (secondsRemaining < 90 || secondsRemaining > 3600) return secondsRemaining > 3600 ? "Too early in the window" : "Too late in the window";
    if (this.realBalance === null || this.realBalance < LIVE_TRADING_CONFIG.STAKE_USD + LIVE_TRADING_CONFIG.FEE_BUFFER_USD) return "Insufficient real balance";
    const gap = typeof snapshot.btcPrice === "number" && typeof snapshot.priceToBeat === "number"
      ? outcome === "UP" ? snapshot.btcPrice - snapshot.priceToBeat : snapshot.priceToBeat - snapshot.btcPrice
      : null;
    if (account.rules?.enableGapFilter) {
      if (gap === null) return "Waiting for BTC / price-to-beat data";
      const requiredGap = [...(account.rules.minGapTable ?? [])].sort((a, b) => b.secondsLeft - a.secondsLeft).find((row) => secondsRemaining >= row.secondsLeft)?.minGap ?? 0;
      if (gap < requiredGap) return "Existing BTC gap filter";
    }
    return null;
  }

  private async placeBuy(snapshot: MarketSnapshot, outcome: Outcome, now: number): Promise<void> {
    const client = this.options.client!;
    const tokenId = snapshot.tokenIds![outcome];
    const book = await client.getOrderBook(tokenId);
    const tickSize = await client.getTickSize(tokenId);
    const bestAsk = book.asks.map((level) => Number(level.price)).filter((price) => Number.isFinite(price) && price > 0).sort((a, b) => a - b)[0];
    const meta = this.updateBookMeta(book, tickSize);
    if (!bestAsk || this.isStale(book, now)) {
      this.lastAction = "Waiting for a fresh ask";
      this.notifyFailure("No fresh ask available", now);
      return;
    }
    if (bestAsk > LIVE_TRADING_CONFIG.ENTRY_MAX) {
      this.lastAction = "Best ask above 0.95; buy skipped";
      this.notifyFailure("Best ask is above the $0.95 cap", now);
      return;
    }
    const balance = await client.getBalanceAllowance({ asset_type: "COLLATERAL" });
    this.realBalance = parseCollateralBalance(balance.balance);
    if (this.realBalance === null || this.realBalance < LIVE_TRADING_CONFIG.STAKE_USD + LIVE_TRADING_CONFIG.FEE_BUFFER_USD) {
      this.lastAction = "Insufficient real balance";
      this.notifyFailure("Insufficient real balance", now);
      return;
    }
    const priceCap = this.roundDownToTick(LIVE_TRADING_CONFIG.ENTRY_MAX, tickSize);
    if (priceCap < bestAsk) {
      this.lastAction = "Best ask cannot be crossed under the 0.95 price cap";
      this.notifyFailure("Best ask cannot be crossed below the $0.95 cap", now);
      return;
    }
    const feeRateBps = await client.getFeeRateBps(tokenId);
    if (!Number.isFinite(feeRateBps) || feeRateBps < 0) throw new Error("LIVE_FEE_RATE_UNAVAILABLE");
    const request = { tokenID: tokenId, amount: LIVE_TRADING_CONFIG.STAKE_USD, price: priceCap, side: "BUY" as const };
    await this.audit({ type: "market-order", side: "BUY", amount: request.amount, priceCap: request.price, orderType: "FAK", outcome, tokenId, tickSize: meta.tickSize, minOrderSize: meta.minOrderSize, result: "requested" });
    let response: unknown;
    try {
      response = await client.createAndPostMarketOrder(request, { tickSize, negRisk: await client.getNegRisk(tokenId) }, "FAK");
    } catch (error) {
      await this.audit({ type: "market-order", side: "BUY", outcome, tokenId, result: "request_failed" });
      this.options.account.livePendingOrder = { orderId: null, tokenId, side: "BUY", outcome, requestedAt: now, amount: request.amount, windowId: snapshot.windowId, windowSlug: snapshot.windowSlug, windowStart: snapshot.windowStart, windowEnd: snapshot.windowEnd };
      this.alert = "BUY FILL UNCONFIRMED";
      this.lastAction = this.alert;
      this.notifyFailure("BUY request failed; fill reconciliation is pending", now);
      await this.options.persist();
      throw error;
    }
    await this.audit({ type: "market-order", side: "BUY", outcome, tokenId, result: this.responseSummary(response) });
    const orderId = this.orderId(response);
    let trades: LiveTrade[] = [];
    try {
      if (orderId) trades = matchedTrades(await client.getTrades({ asset_id: tokenId }), orderId, "BUY");
    } catch (error) {
      this.options.account.livePendingOrder = { orderId, tokenId, side: "BUY", outcome, requestedAt: now, amount: request.amount, windowId: snapshot.windowId, windowSlug: snapshot.windowSlug, windowStart: snapshot.windowStart, windowEnd: snapshot.windowEnd };
      this.alert = "BUY FILL UNCONFIRMED";
      this.lastAction = "Buy submitted; trade data unavailable";
      this.notifyFailure("BUY submitted but CLOB fill data is unavailable", now);
      await this.options.persist();
      throw error;
    }
    const fill = this.aggregateFills(trades, response, "BUY");
    if (!fill || fill.shares <= 0 || fill.usd <= 0) {
      this.options.account.livePendingOrder = { orderId, tokenId, side: "BUY", outcome, requestedAt: now, amount: request.amount, windowId: snapshot.windowId, windowSlug: snapshot.windowSlug, windowStart: snapshot.windowStart, windowEnd: snapshot.windowEnd };
      this.lastAction = "Buy submitted; awaiting confirmed CLOB fills";
      this.alert = "BUY FILL UNCONFIRMED";
      this.notifyFailure("BUY submitted; awaiting confirmed CLOB fills", now);
      await this.options.persist();
      return;
    }
    const fee = fill.fee ?? feeForFill(fill.shares, fill.usd / fill.shares, feeRateBps / 10_000);
    const priceCapBreached = fill.usd / fill.shares > LIVE_TRADING_CONFIG.ENTRY_MAX + Number(tickSize);
    const ledgerFill = this.makeFill("BUY", outcome, snapshot, tokenId, fill.shares, fill.usd, fee, "LIVE_ENTRY", now, bestAsk);
    ledgerFill.exchangeOrderId = orderId ?? undefined;
    this.options.account.ledger.push(ledgerFill);
    const position: PaperPosition = {
      outcome, windowId: snapshot.windowId, windowSlug: snapshot.windowSlug, windowStart: snapshot.windowStart, windowEnd: snapshot.windowEnd,
      entryPrice: fill.usd / fill.shares, shares: fill.shares, cost: fill.usd + fee, openedAt: now,
      stopLossUsd: LIVE_TRADING_CONFIG.STOP_LOSS_USD,
      stopLossPrice: fill.usd / fill.shares - LIVE_TRADING_CONFIG.STOP_LOSS_USD / fill.shares,
      maxEntryPrice: LIVE_TRADING_CONFIG.ENTRY_MAX, live: true, tokenId,
      priceToBeat: snapshot.priceToBeat ?? undefined, btcAtEntry: snapshot.btcPrice ?? undefined
    };
    this.options.account.openPosition = position;
    this.options.account.entriesThisWindow[snapshot.windowId] = true;
    this.options.account.lastEntryExitByOutcome[outcome] = now;
    this.stopConfirmationCount = 0;
    this.nextRetryAt = 0;
    this.alert = priceCapBreached ? "BUY FILL EXCEEDED PRICE CAP · POSITION MANAGED FOR SAFETY" : null;
    this.retryMs = LIVE_TRADING_CONFIG.RETRY_BASE_MS;
    this.lastAction = priceCapBreached ? this.alert! : `BUY confirmed: ${fill.shares.toFixed(4)} ${outcome} shares`;
    await this.refreshBalanceAfterFill();
    await this.options.persist();
    this.options.notifyTrade?.({
      kind: "opened", side: outcome, price: fill.usd / fill.shares, shares: fill.shares, usd: fill.usd,
      priceToBeat: snapshot.priceToBeat, btcPrice: snapshot.btcPrice,
      secondsLeft: Math.max(0, snapshot.windowEnd - now / 1000)
    });
  }

  private async managePosition(snapshot: MarketSnapshot, now: number): Promise<void> {
    const client = this.options.client!;
    const position = this.options.account.openPosition!;
    const tokenId = position.tokenId ?? snapshot.tokenIds?.[position.outcome];
    if (!tokenId) {
      this.alert = "Waiting for position market token";
      this.lastAction = this.alert;
      return;
    }
    const windowEnded = position.windowEnd !== undefined && now >= position.windowEnd * 1000;
    if (windowEnded || position.windowId !== snapshot.windowId) {
      await this.resolveOpenPosition(position, snapshot, now);
      return;
    }
    if (now < this.nextRetryAt) return;
    const book = await client.getOrderBook(tokenId);
    const tickSize = await client.getTickSize(tokenId);
    this.updateBookMeta(book, tickSize);
    const bestBid = book.bids.map((level) => Number(level.price)).filter((price) => Number.isFinite(price) && price > 0).sort((a, b) => b - a)[0];
    const bestBidSize = bestBid === undefined ? 0 : Number(book.bids.find((level) => Number(level.price) === bestBid)?.size ?? 0);
    if (!bestBid || bestBidSize <= 0 || this.isStale(book, now)) {
      this.stopConfirmationCount = 0;
      this.alert = "Waiting: no bids";
      this.lastAction = "Waiting: no bids";
      return;
    }
    const stopPrice = position.stopLossPrice ?? position.entryPrice - LIVE_TRADING_CONFIG.STOP_LOSS_USD / position.shares;
    if (bestBid > stopPrice) {
      this.stopConfirmationCount = 0;
      this.lastStopReadAt = now;
      this.alert = null;
      this.lastAction = "Managing live position";
      return;
    }
    if (now - this.lastStopReadAt >= 1000) this.stopConfirmationCount += 1;
    this.lastStopReadAt = now;
    position.stopConfirmations = this.stopConfirmationCount;
    if (this.stopConfirmationCount < 2) {
      this.lastAction = "Stop threshold observed; confirming on next fresh book";
      await this.options.persist();
      return;
    }
    await this.sellRemaining(position, snapshot, tokenId, bestBid, now, tickSize, book.neg_risk);
  }

  private async sellRemaining(position: PaperPosition, snapshot: MarketSnapshot, tokenId: string, bestBid: number, now: number, tickSize: string, negRisk: boolean, immediateRetry = false): Promise<void> {
    let feeRateBps: number;
    try {
      feeRateBps = await this.options.client!.getFeeRateBps(tokenId);
      if (!Number.isFinite(feeRateBps) || feeRateBps < 0) throw new Error("LIVE_FEE_RATE_UNAVAILABLE");
    } catch {
      this.alert = "SELL FAILED, RETRYING";
      this.lastAction = this.alert;
      this.notifyFailure("Sell fee lookup failed; sale will retry", now);
      this.scheduleRetry(now, true);
      await this.options.persist();
      this.log("[live] sell fee lookup failed; retry scheduled");
      return;
    }
    const request = {
      tokenID: tokenId, amount: position.shares,
      price: Math.max(0.01, this.roundDownToTick(bestBid - LIVE_TRADING_CONFIG.STOP_SLIPPAGE, tickSize)),
      side: "SELL" as const
    };
    await this.audit({ type: "market-order", side: "SELL", amount: request.amount, priceFloor: request.price, bestBid, orderType: "FAK", outcome: position.outcome, tokenId, result: "requested" });
    let orderId: string | null = null;
    try {
      const response = await this.options.client!.createAndPostMarketOrder(request, { tickSize, negRisk }, "FAK");
      await this.audit({ type: "market-order", side: "SELL", outcome: position.outcome, tokenId, result: this.responseSummary(response) });
      orderId = this.orderId(response);
      const trades = orderId ? matchedTrades(await this.options.client!.getTrades({ asset_id: tokenId }), orderId, "SELL") : [];
      const fill = this.aggregateFills(trades, response, "SELL");
      if (!fill || fill.shares <= 0 || fill.usd <= 0) {
        this.options.account.livePendingOrder = { orderId, tokenId, side: "SELL", outcome: position.outcome, requestedAt: now, amount: request.amount, windowId: position.windowId, windowSlug: position.windowSlug, windowStart: position.windowStart, windowEnd: position.windowEnd };
        this.stopConfirmationCount = 2;
        this.alert = "SELL FAILED, RETRYING";
        this.lastAction = "Sell submitted; awaiting confirmed CLOB fills";
        await this.options.persist();
        return;
      }
      const fee = fill.fee ?? feeForFill(fill.shares, fill.usd / fill.shares, feeRateBps / 10_000);
      const filled = Math.min(position.shares, fill.shares);
      const fillRatio = filled / fill.shares;
      const sharesBeforeFill = position.shares;
      const allocatedCost = position.cost * (filled / sharesBeforeFill);
      const ledgerFill = this.makeFill("SELL", position.outcome, snapshot, tokenId, filled, fill.usd * fillRatio, fee * fillRatio, "LIVE_STOP_LOSS", now, bestBid);
      ledgerFill.exchangeOrderId = orderId ?? undefined;
      this.options.account.ledger.push(ledgerFill);
      position.shares = Math.max(0, position.shares - filled);
      position.cost = Math.max(0, position.cost - allocatedCost);
      this.retryMs = LIVE_TRADING_CONFIG.RETRY_BASE_MS;
      const positionClosed = position.shares <= 1e-8;
      if (positionClosed) {
        this.stopConfirmationCount = 0;
        this.options.account.openPosition = null;
        this.options.account.lastEntryExitByOutcome[position.outcome] = now;
        this.updateDailyPnl(now);
        this.alert = null;
        this.lastAction = "Live position sold";
      } else {
        this.stopConfirmationCount = 2;
        this.alert = "SELL FAILED, RETRYING";
        this.lastAction = "Partial sale confirmed; retrying remaining shares";
        this.scheduleRetry(now, true);
      }
      this.updateRealizedPnl();
      this.updateDailyPnl(now);
      await this.refreshBalanceAfterFill();
      await this.options.persist();
      if (positionClosed) this.notifyClosedPosition(position, "stop-loss");
      if (position.shares > 1e-8 && !immediateRetry) {
        const nextBook = await this.options.client!.getOrderBook(tokenId);
        const nextTickSize = await this.options.client!.getTickSize(tokenId);
        const nextBid = nextBook.bids.map((level) => Number(level.price)).filter((price) => Number.isFinite(price) && price > 0).sort((a, b) => b - a)[0];
        const nextBidSize = nextBid === undefined ? 0 : Number(nextBook.bids.find((level) => Number(level.price) === nextBid)?.size ?? 0);
        if (nextBid && nextBidSize > 0 && !this.isStale(nextBook, this.now())) {
          this.nextRetryAt = 0;
          await this.sellRemaining(position, snapshot, tokenId, nextBid, this.now(), nextTickSize, nextBook.neg_risk, true);
        }
      }
    } catch (error) {
      await this.audit({ type: "market-order", side: "SELL", outcome: position.outcome, tokenId, result: "request_failed" });
      const message = error instanceof Error ? error.message.toLowerCase() : "";
      if (message.includes("min") || message.includes("size")) this.alert = "STAKE TOO SMALL TO EXIT SAFELY · SELL FAILED, RETRYING";
      else this.alert = "SELL FAILED, RETRYING";
      this.lastAction = this.alert;
      this.notifyFailure(this.alert, now);
      this.stopConfirmationCount = 2;
      if (!message.includes("min") && !message.includes("size") && !this.options.account.ledger.some((fill) => fill.exchangeOrderId === orderId && fill.side === "SELL")) {
        this.options.account.livePendingOrder = { orderId, tokenId, side: "SELL", outcome: position.outcome, requestedAt: now, amount: request.amount, windowId: position.windowId, windowSlug: position.windowSlug, windowStart: position.windowStart, windowEnd: position.windowEnd };
        this.alert = orderId ? "SELL FAILED, RETRYING" : "SELL FILL UNCONFIRMED · MANUAL RECONCILIATION REQUIRED";
        this.lastAction = this.alert;
        await this.options.persist();
        return;
      }
      this.scheduleRetry(now, true);
      await this.options.persist();
      this.log("[live] sell failed; position remains open and will retry");
    }
  }

  private async resolveOpenPosition(position: PaperPosition, snapshot: MarketSnapshot, now: number): Promise<void> {
    try {
      const resolution = await this.options.resolveWindow(position.windowStart ?? snapshot.windowStart);
      if (!resolution) {
        this.alert = "Waiting for market resolution";
        return;
      }
      const payout = resolution.outcome === position.outcome ? LIVE_TRADING_CONFIG.TARGET : 0;
      const usd = position.shares * payout;
      const fill: LedgerFill = {
        id: randomUUID(), timestamp: now, windowId: position.windowId, windowSlug: position.windowSlug,
        side: "SELL", outcome: position.outcome, price: payout, fillPrice: payout, decisionPrice: payout,
        shares: position.shares, usd, fee: 0, slippage: 0, reason: payout === 1 ? "LIVE_RESOLUTION_WIN" : "LIVE_RESOLUTION_LOSS",
        priceToBeat: position.priceToBeat, btcAtEntry: position.btcAtEntry, btcAtExit: snapshot.btcPrice ?? undefined
      };
      this.options.account.ledger.push(fill);
      this.updateRealizedPnl();
      if (payout === 1) this.alert = "CLAIM WINNINGS ON POLYMARKET";
      this.options.account.openPosition = null;
      this.updateDailyPnl(now);
      this.lastAction = payout === 1 ? "Resolved win recorded; winnings await claim" : "Resolved loss recorded";
      await this.options.persist();
      this.notifyClosedPosition(position, "window end");
    } catch {
      this.alert = "Waiting for market resolution";
      this.log("[live] resolution lookup failed; position remains open");
    }
  }

  private async reconcilePending(snapshot: MarketSnapshot, now: number): Promise<void> {
    const pending = this.options.account.livePendingOrder;
    if (!pending) return;
    const client = this.options.client!;
    if (!pending.orderId) {
      this.alert = "FILL UNCONFIRMED · MANUAL RECONCILIATION REQUIRED";
      this.lastAction = this.alert;
      return;
    }
    if (pending.orderId) {
      const trades = matchedTrades(await client.getTrades({ asset_id: pending.tokenId }), pending.orderId, pending.side);
      const fill = this.aggregateFills(trades, null, pending.side);
      if (fill && fill.shares > 0 && fill.usd > 0) {
        let retrySellImmediately = false;
        let closedPosition: PaperPosition | null = null;
        let openedPosition: PaperPosition | null = null;
        const fee = fill.fee ?? await this.feeFromRate(pending.tokenId, fill.shares, fill.usd / fill.shares);
        const fillSnapshot = {
          ...snapshot,
          windowId: pending.windowId ?? snapshot.windowId,
          windowSlug: pending.windowSlug ?? snapshot.windowSlug,
          windowStart: pending.windowStart ?? snapshot.windowStart,
          windowEnd: pending.windowEnd ?? snapshot.windowEnd
        };
        if (pending.side === "BUY" && !this.options.account.openPosition) {
          const entryPrice = fill.usd / fill.shares;
          const ledgerFill = this.makeFill("BUY", pending.outcome, fillSnapshot, pending.tokenId, fill.shares, fill.usd, fee, "LIVE_ENTRY", now);
          ledgerFill.exchangeOrderId = pending.orderId ?? undefined;
          this.options.account.ledger.push(ledgerFill);
          openedPosition = {
            outcome: pending.outcome, windowId: fillSnapshot.windowId, windowSlug: fillSnapshot.windowSlug,
            windowStart: fillSnapshot.windowStart, windowEnd: fillSnapshot.windowEnd,
            entryPrice, shares: fill.shares, cost: fill.usd + fee, openedAt: now,
            stopLossUsd: LIVE_TRADING_CONFIG.STOP_LOSS_USD,
            stopLossPrice: entryPrice - LIVE_TRADING_CONFIG.STOP_LOSS_USD / fill.shares,
            maxEntryPrice: LIVE_TRADING_CONFIG.ENTRY_MAX, live: true, tokenId: pending.tokenId,
            priceToBeat: snapshot.priceToBeat ?? undefined, btcAtEntry: snapshot.btcPrice ?? undefined
          };
          this.options.account.openPosition = openedPosition;
          this.options.account.entriesThisWindow[fillSnapshot.windowId] = true;
          this.lastAction = "Reconciled confirmed live buy fill";
        } else if (pending.side === "SELL" && this.options.account.openPosition) {
          const position = this.options.account.openPosition;
          const sold = Math.min(position.shares, fill.shares);
          const fillRatio = sold / fill.shares;
          const sharesBeforeFill = position.shares;
          const allocatedCost = position.cost * (sold / sharesBeforeFill);
          const ledgerFill = this.makeFill("SELL", pending.outcome, fillSnapshot, pending.tokenId, sold, fill.usd * fillRatio, fee * fillRatio, "LIVE_STOP_LOSS", now);
          ledgerFill.exchangeOrderId = pending.orderId ?? undefined;
          this.options.account.ledger.push(ledgerFill);
          position.shares = Math.max(0, position.shares - sold);
          position.cost = Math.max(0, position.cost - allocatedCost);
          if (position.shares <= 1e-8) {
            closedPosition = position;
            this.options.account.openPosition = null;
            this.updateDailyPnl(now);
            this.alert = null;
            this.lastAction = "Reconciled completed live sale";
          } else {
            this.alert = "SELL FAILED, RETRYING";
            this.lastAction = "Reconciled partial live sale; retrying remainder";
            this.scheduleRetry(now, true);
            this.stopConfirmationCount = 2;
            retrySellImmediately = true;
          }
          this.updateRealizedPnl();
          this.updateDailyPnl(now);
        }
        this.options.account.livePendingOrder = undefined;
        await this.refreshBalanceAfterFill();
        await this.options.persist();
        if (openedPosition) {
          this.options.notifyTrade?.({
            kind: "opened", side: pending.outcome, price: fill.usd / fill.shares, shares: fill.shares, usd: fill.usd,
            priceToBeat: snapshot.priceToBeat, btcPrice: snapshot.btcPrice,
            secondsLeft: Math.max(0, fillSnapshot.windowEnd - now / 1000)
          });
        }
        if (closedPosition) this.notifyClosedPosition(closedPosition, "stop-loss");
        if (retrySellImmediately && this.options.account.openPosition) {
          const book = await client.getOrderBook(pending.tokenId);
          const tickSize = await client.getTickSize(pending.tokenId);
          const bid = book.bids.map((level) => Number(level.price)).filter((price) => Number.isFinite(price) && price > 0).sort((a, b) => b - a)[0];
          const bidSize = bid === undefined ? 0 : Number(book.bids.find((level) => Number(level.price) === bid)?.size ?? 0);
          if (bid && bidSize > 0 && !this.isStale(book, now)) {
            this.nextRetryAt = 0;
            await this.sellRemaining(this.options.account.openPosition, snapshot, pending.tokenId, bid, now, tickSize, book.neg_risk, true);
          }
        }
        return;
      }
    }
    const openOrders = await client.getOpenOrders();
    if (pending.orderId && openOrders.some((order) => order.id === pending.orderId)) {
      this.lastAction = "Waiting for CLOB order reconciliation";
      return;
    }
    if (now - pending.requestedAt < LIVE_TRADING_CONFIG.RETRY_BASE_MS) {
      this.lastAction = "Waiting for CLOB fill data to become available";
      return;
    }
    this.options.account.livePendingOrder = undefined;
    if (pending.side === "SELL" && this.options.account.openPosition) {
      this.alert = "SELL FAILED, RETRYING";
      this.lastAction = "No sale fill confirmed; retrying";
      this.scheduleRetry(now, true);
    } else {
      this.alert = null;
      this.lastAction = "No buy fill confirmed; entry can retry";
    }
    await this.options.persist();
  }

  private async refreshRealBalance(): Promise<void> {
    try {
      this.realBalance = await this.readBalance();
      if (this.realBalance !== null) this.options.account.cashBalance = this.realBalance;
    }
    catch {
      this.realBalance = null;
      this.log("[live] collateral balance refresh failed");
    }
  }
  private async refreshBalanceAfterFill(): Promise<void> {
    try {
      this.realBalance = await this.readBalance();
      this.options.account.cashBalance = this.realBalance ?? this.options.account.cashBalance;
    } catch {
      this.log("[live] balance refresh failed after confirmed fill");
    }
  }
  private async readBalance(): Promise<number | null> {
    const response = await this.options.client!.getBalanceAllowance({ asset_type: "COLLATERAL" });
    return parseCollateralBalance(response.balance);
  }
  private updateBookMeta(book: LiveOrderBook, tickSize: string): { minOrderSize: number | null; tickSize: string | null } {
    this.currentBookMeta = { minOrderSize: toNumber(book.min_order_size), tickSize: tickSize || book.tick_size || null };
    return this.currentBookMeta;
  }
  private isStale(book: LiveOrderBook, now: number): boolean {
    const updatedAt = bookTimestampMs(book.timestamp);
    return !updatedAt || now - updatedAt > LIVE_TRADING_CONFIG.BOOK_MAX_AGE_MS || updatedAt - now > LIVE_TRADING_CONFIG.BOOK_MAX_AGE_MS;
  }
  private notifyFailure(reason: string, now: number): void {
    if (!this.options.notifyTrade || now - this.lastFailureNoticeAt < 60_000) return;
    this.lastFailureNoticeAt = now;
    this.options.notifyTrade({ kind: "rejected", reason });
  }
  private notifyClosedPosition(position: PaperPosition, reason: string): void {
    if (!this.options.notifyTrade) return;
    const roundTrips = deriveRoundTrips(this.options.account.ledger);
    const matching = roundTrips.filter((trade) =>
      trade.buy.windowId === position.windowId && trade.buy.outcome === position.outcome
      && trade.buy.timestamp <= position.openedAt
    );
    if (!matching.length) return;
    const latestEntryTs = Math.max(...matching.map((trade) => trade.buy.timestamp));
    const closedTrades = matching.filter((trade) => trade.buy.timestamp === latestEntryTs);
    const pnl = closedTrades.reduce((sum, trade) => sum + trade.pnl, 0);
    const cost = closedTrades.reduce((sum, trade) => sum + trade.buy.usd + trade.buy.fee, 0);
    const shares = closedTrades.reduce((sum, trade) => sum + trade.sell.shares, 0);
    const proceeds = closedTrades.reduce((sum, trade) => sum + trade.sell.usd, 0);
    this.options.notifyTrade({
      kind: "closed", side: position.outcome, price: shares > 0 ? proceeds / shares : 0,
      reason, pnl, pnlPercent: cost > 0 ? pnl / cost * 100 : 0, balance: this.options.account.cashBalance
    });
  }
  private roundDownToTick(price: number, tickSize: string): number {
    const tick = Number(tickSize);
    if (!Number.isFinite(tick) || tick <= 0) return 0;
    const decimalPlaces = tickSize.includes(".") ? tickSize.length - tickSize.indexOf(".") - 1 : 0;
    const precision = 10 ** decimalPlaces;
    const rounded = Math.round(Math.floor((price + 1e-10) / tick) * tick * precision) / precision;
    return Math.max(tick, rounded);
  }
  private resetEntryTimers(): void { this.heldSince.UP = null; this.heldSince.DOWN = null; }
  private scheduleRetry(now: number, fixedInterval = false): void {
    this.nextRetryAt = now + (fixedInterval ? LIVE_TRADING_CONFIG.RETRY_BASE_MS : this.retryMs);
    if (!fixedInterval) this.retryMs = Math.min(this.retryMs * 2, LIVE_TRADING_CONFIG.MAX_RETRY_MS);
  }
  private setError(message: string): void { this.alert = message; this.lastAction = message; }
  private orderId(response: unknown): string | null {
    if (!response || typeof response !== "object") return null;
    const value = (response as Record<string, unknown>).orderID ?? (response as Record<string, unknown>).orderId;
    return typeof value === "string" ? value : null;
  }
  private responseSummary(response: unknown): Record<string, unknown> {
    if (!response || typeof response !== "object") return { status: "unrecognized response" };
    const raw = response as Record<string, unknown>;
    return {
      success: typeof raw.success === "boolean" ? raw.success : undefined,
      status: typeof raw.status === "string" ? raw.status : undefined,
      orderID: this.orderId(response),
      takingAmount: toNumber(raw.takingAmount),
      makingAmount: toNumber(raw.makingAmount),
      error: raw.errorMsg ? "[redacted]" : undefined
    };
  }
  private aggregateFills(trades: LiveTrade[], response: unknown, side: "BUY" | "SELL"): { shares: number; usd: number; fee: number | null } | null {
    if (trades.length) {
      let shares = 0;
      let usd = 0;
      let fee = 0;
      let feeKnown = true;
      for (const trade of trades) {
        const matchingMaker = trade.maker_orders?.find((maker) => maker.matched_amount);
        const size = toNumber(matchingMaker?.matched_amount) ?? toNumber(trade.size) ?? 0;
        const price = toNumber(trade.price) ?? 0;
        if (size <= 0 || price <= 0) continue;
        shares += size;
        usd += size * price;
        const tradeFee = this.tradeFee(trade);
        if (tradeFee === null) feeKnown = false;
        else fee += tradeFee;
      }
      if (shares > 0) return { shares, usd, fee: feeKnown ? fee : null };
    }
    if (!response || typeof response !== "object") return null;
    const raw = response as Record<string, unknown>;
    const success = raw.success === true || raw.status === "matched" || raw.status === "partially_matched";
    const first = toNumber(raw.takingAmount);
    const second = toNumber(raw.makingAmount);
    if (!success || first === null || second === null || first <= 0 || second <= 0) return null;
    const shares = side === "BUY" ? first : second;
    const usd = side === "BUY" ? second : first;
    return shares > 0 && usd > 0 ? { shares, usd, fee: null } : null;
  }
  private tradeFee(trade: LiveTrade): number | null {
    const explicit = toNumber(trade.fee);
    if (explicit !== null) return explicit;
    const size = toNumber(trade.size);
    const price = toNumber(trade.price);
    const feeRateBps = toNumber(trade.fee_rate_bps);
    if (size === null || price === null || feeRateBps === null) return null;
    return feeForFill(size, price, feeRateBps / 10_000);
  }
  private async feeFromRate(tokenId: string, shares: number, price: number): Promise<number> {
    const rateBps = await this.options.client!.getFeeRateBps(tokenId);
    return feeForFill(shares, price, rateBps / 10_000);
  }
  private makeFill(side: "BUY" | "SELL", outcome: Outcome, snapshot: MarketSnapshot, tokenId: string, shares: number, usd: number, fee: number, reason: string, now: number, decisionPrice?: number): LedgerFill {
    return {
      id: randomUUID(), timestamp: now, windowId: snapshot.windowId, windowSlug: snapshot.windowSlug,
      side, outcome, price: shares ? usd / shares : 0, fillPrice: shares ? usd / shares : 0,
      decisionPrice, shares, usd, fee, slippage: 0, reason, priceToBeat: snapshot.priceToBeat ?? undefined,
      btcAtEntry: side === "BUY" ? snapshot.btcPrice ?? undefined : undefined,
      btcAtExit: side === "SELL" ? snapshot.btcPrice ?? undefined : undefined,
      rulesVersion: this.options.account.rulesVersion ?? 1, tokenId
    };
  }
  private updateDailyPnl(now: number): void {
    const key = utcDay(now);
    const pnl = deriveRoundTrips(this.options.account.ledger).filter((trade) => utcDay(trade.sell.timestamp) === key).reduce((sum, trade) => sum + trade.pnl, 0);
    this.options.account.dailyPnl ??= {};
    this.options.account.dailyPnl[key] = pnl;
  }
  private updateRealizedPnl(): void {
    this.options.account.totalRealizedPnl = deriveRoundTrips(this.options.account.ledger).reduce((sum, trade) => sum + trade.pnl, 0);
  }
  private async audit(entry: Record<string, unknown>): Promise<void> {
    try {
      await mkdir(this.auditDirectory, { recursive: true });
      const filename = `live-orders-${utcDay(this.now())}.ndjson`;
      const safe = this.redact({ ts: this.now(), ...entry });
      await appendFile(join(this.auditDirectory, filename), `${JSON.stringify(safe)}\n`, "utf8");
    } catch {
      this.log("[live] order audit write failed");
    }
  }
  private redact(value: unknown): unknown {
    if (typeof value === "string") return value.replace(/0x[0-9a-fA-F]{64}/g, "[redacted]");
    if (Array.isArray(value)) return value.map((item) => this.redact(item));
    if (!value || typeof value !== "object") return value;
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [
      key,
      /private.?key|secret|passphrase|api.?key/i.test(key) ? "[redacted]" : this.redact(item)
    ]));
  }
}
