import "dotenv/config";
import { join } from "node:path";
import type { AccountId, AccountRules } from "./types.js";

const num = (name: string, fallback: number): number => {
  const value = Number(process.env[name]);
  return Number.isFinite(value) ? value : fallback;
};
const source = (name: string): "env" | "default" => process.env[name] !== undefined && process.env[name] !== "" ? "env" : "default";

export const config = {
  dataDir: process.env.DATA_DIR || join(process.cwd(), "data"),
  pricesDir: process.env.PRICES_DIR || join(process.env.DATA_DIR || join(process.cwd(), "data"), "prices"),
  priceRecording: process.env.PRICE_RECORDING !== "false" && process.env.PRICE_RECORDING !== "0",
  maxPricesMb: num("MAX_PRICES_MB", 500),
  port: num("PORT", 3001),
  startingBalance: 100,
  entryTrigger: num("ENTRY_TRIGGER_PRICE", 0.93),
  maxEntryPrice: num("MAX_ENTRY_PRICE", 0.95),
  entryHoldMs: num("ENTRY_HOLD_MS", 400),
  minSecondsRemaining: num("MIN_SECONDS_REMAINING", 90),
  tradeSizeUsd: num("TRADE_SIZE_USD", 100),
  takeProfit: num("TAKE_PROFIT_PRICE", 0.99),
  stopLossUsd: num("STOP_LOSS_USD", 10),
  reversalPrice: num("REVERSAL_OPPOSITE_PRICE", 0.35),
  slippageBps: num("SLIPPAGE_BPS", 50),
  feeRate: num("FEE_RATE", 0.07),
  fillDelayMinMs: num("FILL_DELAY_MIN_MS", 300),
  fillDelayMaxMs: num("FILL_DELAY_MAX_MS", 600),
  maxTradeSizeUsd: num("MAX_TRADE_SIZE_USD", 100),
  maxOpenPositions: num("MAX_OPEN_POSITIONS", 1),
  tickMs: num("ENGINE_TICK_MS", 25),
  liveTrading: process.env.LIVE_TRADING === "true",
  polyFunderAddress: process.env.POLY_FUNDER_ADDRESS || "0x0ef09cca617a7ab3a35d11a7c375fb1eb45051b5",
  polySignatureType: 1,
  dashboardUser: process.env.DASH_USER || "admin",
  dashboardPassword: process.env.DASH_PASSWORD || ""
} as const;
export const LIVE_TRADING_CONFIG = {
  STAKE_USD: 1,
  ENTRY_MIN: 0.93,
  ENTRY_MAX: 0.95,
  HOLD_SECONDS: 10,
  STOP_LOSS_USD: 0.5,
  TARGET: 1.00,
  MAX_DAILY_LOSS: 1.5,
  FEE_BUFFER_USD: 0.1,
  STOP_SLIPPAGE: 0.02,
  BOOK_MAX_AGE_MS: 3000,
  RETRY_BASE_MS: 1000,
  MAX_RETRY_MS: 30000
} as const;
export const FOUR_HOUR_BOT_CONFIG = {
  marketType: "4h",
  windowSeconds: 4 * 60 * 60,
  ENTRY_MIN: 0.91,
  ENTRY_MAX: 0.93,
  HOLD_SECONDS: 300,
  STAKE: 150,
  TARGET: 1.00,
  STOP: null,
  startingBalance: 200
} as const;
export const configSources = {
  entryTrigger: source("ENTRY_TRIGGER_PRICE"),
  takeProfit: source("TAKE_PROFIT_PRICE"),
  stopLossUsd: source("STOP_LOSS_USD"),
  maxEntryPrice: source("MAX_ENTRY_PRICE"),
  tradeSizeUsd: source("TRADE_SIZE_USD"),
  slippageBps: source("SLIPPAGE_BPS")
} as const;

export type EngineConfig = typeof config;

export const defaultAccountRules = (id: AccountId = "mine"): AccountRules => id === "fourHour" ? ({
  entryMin: FOUR_HOUR_BOT_CONFIG.ENTRY_MIN,
  entryMax: FOUR_HOUR_BOT_CONFIG.ENTRY_MAX,
  holdMs: FOUR_HOUR_BOT_CONFIG.HOLD_SECONDS * 1000,
  target: FOUR_HOUR_BOT_CONFIG.TARGET,
  stopLossUsd: 0,
  reversalPrice: 1,
  tradeSizeUsd: FOUR_HOUR_BOT_CONFIG.STAKE,
  maxSecondsRemaining: FOUR_HOUR_BOT_CONFIG.windowSeconds,
  minSecondsRemaining: 0,
  oneTradePerWindow: true,
  enableGapFilter: false,
  minGapTable: []
}) : ({
  entryMin: 0.93, entryMax: 0.95, holdMs: 400, target: 0.99, stopLossUsd: 10,
  reversalPrice: 0.35, tradeSizeUsd: 100, maxSecondsRemaining: 3600,
  minSecondsRemaining: 90, oneTradePerWindow: true, enableGapFilter: true,
  minGapTable: [{ secondsLeft: 2400, minGap: 250 }, { secondsLeft: 1800, minGap: 200 }, { secondsLeft: 1200, minGap: 150 }, { secondsLeft: 600, minGap: 100 }, { secondsLeft: 300, minGap: 60 }, { secondsLeft: 0, minGap: 60 }]
});

export type EditableMineRules = Pick<AccountRules, "entryMin" | "entryMax" | "target" | "stopLossUsd" | "tradeSizeUsd" | "maxSecondsRemaining" | "enableGapFilter" | "minGapTable">;
export const validateMineRules = (input: unknown, minSecondsRemaining: number, maxTradeSizeUsd: number): { rules: EditableMineRules } | { error: string } => {
  if (!input || typeof input !== "object" || Array.isArray(input)) return { error: "Rules must be an object" };
  const values = input as Record<string, unknown>;
  const { entryMin, entryMax, target, stopLossUsd, tradeSizeUsd, maxSecondsRemaining } = values;
  const enableGapFilter = values.enableGapFilter === undefined ? true : values.enableGapFilter;
  const minGapTable = values.minGapTable === undefined ? defaultAccountRules("mine").minGapTable : values.minGapTable;
  const isFiniteNumber = (value: unknown): value is number => typeof value === "number" && Number.isFinite(value);
  if (!isFiniteNumber(entryMin) || !isFiniteNumber(entryMax) || !isFiniteNumber(target) || !isFiniteNumber(stopLossUsd) || !isFiniteNumber(tradeSizeUsd) || !isFiniteNumber(maxSecondsRemaining) || typeof enableGapFilter !== "boolean" || !Array.isArray(minGapTable)) {
    return { error: "All editable rule fields must be finite numbers" };
  }
  const rules: EditableMineRules = {
    entryMin, entryMax, target, stopLossUsd, tradeSizeUsd, maxSecondsRemaining, enableGapFilter, minGapTable: minGapTable as EditableMineRules["minGapTable"]
  };
  if (rules.minGapTable.length === 0 || rules.minGapTable.some((row) => !row || !isFiniteNumber(row.secondsLeft) || !isFiniteNumber(row.minGap) || row.secondsLeft < 0 || row.minGap < 0) || rules.minGapTable.some((row, index) => index > 0 && row.secondsLeft >= rules.minGapTable[index - 1]!.secondsLeft)) return { error: "Gap table secondsLeft must descend and all values must be numbers >= 0" };
  if (rules.entryMin < 0.5 || rules.entryMin >= rules.entryMax || rules.entryMax > 0.97) return { error: "Require 0.50 <= entryMin < entryMax <= 0.97" };
  if (rules.entryMax >= rules.target || rules.target > 0.99) return { error: "Require entryMax < target <= 0.99" };
  if (rules.tradeSizeUsd < 1 || rules.tradeSizeUsd > Math.min(100, maxTradeSizeUsd) || rules.stopLossUsd < 0.25 || rules.stopLossUsd > rules.tradeSizeUsd) {
    return { error: `Require 1 <= tradeSizeUsd <= ${Math.min(100, maxTradeSizeUsd)} and 0.25 <= stopLossUsd <= tradeSizeUsd` };
  }
  if (rules.maxSecondsRemaining < 60 || rules.maxSecondsRemaining > 3600 || rules.maxSecondsRemaining <= minSecondsRemaining) return { error: `Require ${minSecondsRemaining} < maxSecondsRemaining <= 3600` };
  return { rules };
};
