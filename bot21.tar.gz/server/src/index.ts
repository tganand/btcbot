import express from "express";
import cors from "cors";
import { createServer } from "node:http";
import { join } from "node:path";
import { config, configSources, defaultAccountRules, FOUR_HOUR_BOT_CONFIG, LIVE_TRADING_CONFIG, validateMineRules } from "./config.js";
import { freshAccounts, loadAccounts, saveAccounts, resetOneAccountState, resetPaperAccount } from "./store.js";
import { buildTradesCsv, calculatePortfolioMetrics, reconcilePaperAccount, recordEquityPoint } from "./math.js";
import { MarketFeed, marketWindowStart } from "./marketFeed.js";
import { EntryEngine } from "./entryEngine.js";
import { PaperExecutor } from "./paperExecutor.js";
import { lookupResolution } from "./settlement.js";
import type { AccountRules, MarketSnapshot, PaperAccount, PaperAccountsState } from "./types.js";
import type { LiveTradingOptions } from "./liveTrading.js";
import { createBasicAuth, requireProductionPassword } from "./auth.js";
import { PriceRecorder } from "./priceRecorder.js";
import { BtcReferencePrice } from "./referencePrice.js";
import { createLiveClobClient } from "./liveClob.js";
import { loadLiveAccount, saveLiveAccount } from "./liveStore.js";
import { LiveTradingEngine } from "./liveTrading.js";
import { initializeTelegram, sendTelegram, sendTelegramTradeNotice } from "./telegram.js";

requireProductionPassword();
const app = express();
app.use(cors());
app.use(express.json());
app.use(createBasicAuth(config.dashboardUser, config.dashboardPassword));
const server = createServer(app);
let state: PaperAccountsState = freshAccounts();
let liveEngine: LiveTradingEngine | undefined;
let liveAccount: PaperAccount | undefined;
let liveOptions: LiveTradingOptions | undefined;
const mineAccount = (): PaperAccount => liveAccount ?? state.accounts.mine;
let snapshot: MarketSnapshot = { windowId: "", windowStart: 0, windowEnd: 0, windowTitle: "Waiting for next window", serverNow: Date.now(), up: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, down: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, feedHealth: "DISCONNECTED", consistent: false, feedMessage: "No active market found" };
let fourHourSnapshot: MarketSnapshot = { ...snapshot, windowId: "", windowSlug: "", windowStart: 0, windowEnd: 0 };
const clients = new Set<express.Response>();
const btcReference = new BtcReferencePrice({ onUpdate: () => {
  snapshot = { ...snapshot, ...btcReference.getValues(snapshot.windowStart) };
  fourHourSnapshot = { ...fourHourSnapshot, ...btcReference.getValues(fourHourSnapshot.windowStart) };
  priceTick();
} });
const priceRecorder = new PriceRecorder({
  directory: config.pricesDir,
  marketType: "1h",
  enabled: config.priceRecording,
  maxBytes: config.maxPricesMb * 1024 * 1024,
  resolveWindow: (windowStart) => lookupResolution(windowStart, "1h")
});
const fourHourRecorder = new PriceRecorder({
  directory: join(config.pricesDir, "4h"),
  marketType: "4h",
  enabled: config.priceRecording,
  maxBytes: config.maxPricesMb * 1024 * 1024,
  resolveWindow: (windowStart) => lookupResolution(windowStart, "4h")
});
let engine: EntryEngine | undefined;
let fourHourEngine: EntryEngine | undefined;
const broadcast = (type: string, payload: unknown) => { for (const client of clients) client.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`); };
const fourHourFull = () => {
  const account = state.accounts.fourHour;
  const metrics = calculatePortfolioMetrics(account, fourHourSnapshot, config.feeRate);
  const entryStatus = fourHourEngine?.getStatuses() ?? { UP: null, DOWN: null };
  return {
    account: { id: "fourHour", name: "4-hour rules", ...account, rules: fourHourEngine?.rules ?? account.rules ?? defaultAccountRules("fourHour"), entryStatus, pendingOrder: fourHourEngine?.getPendingOrder() ?? null },
    snapshot: fourHourSnapshot,
    metrics,
    entryStatus
  };
};
const full = () => {
  const account = mineAccount();
  const metrics = calculatePortfolioMetrics(account, snapshot, config.feeRate);
  if (config.liveTrading) {
    metrics.unrealizedPnl = 0;
    metrics.equity = account.cashBalance + (account.openPosition?.cost ?? 0);
  }
  const entryStatus = engine?.getStatuses() ?? { UP: null, DOWN: null };
  return {
    account: {
      id: "mine",
      name: "My rules",
      ...account,
      rules: engine?.rules ?? account.rules ?? defaultAccountRules("mine"),
      entryStatus,
      pendingOrder: engine?.getPendingOrder() ?? null
    },
    snapshot,
    metrics,
    config: { entryTrigger: config.entryTrigger, takeProfit: config.takeProfit, stopLossUsd: config.stopLossUsd, maxEntryPrice: config.maxEntryPrice, tradeSizeUsd: config.tradeSizeUsd, maxTradeSizeUsd: config.maxTradeSizeUsd, slippageBps: config.slippageBps, feeRate: config.feeRate, sources: configSources },
    entryStatus,
    fourHour: fourHourFull(),
    liveTrading: config.liveTrading ? liveEngine?.getStatus() ?? null : null
  };
};
app.get("/api/state", (_req, res) => res.json(full()));
app.get("/api/recording/status", async (_req, res) => res.json(await priceRecorder.getStatus()));
app.get("/api/four-hour/recording/status", async (_req, res) => res.json(await fourHourRecorder.getStatus()));
app.get("/api/accounts/mine/rules", (_req, res) => {
  const account = mineAccount();
  res.json({ rules: engine?.rules ?? account.rules ?? defaultAccountRules("mine"), rulesVersion: account.rulesVersion ?? 1, history: account.rulesHistory ?? [] });
});
app.put("/api/accounts/mine/rules", async (req, res) => {
  if (req.body?.confirm !== true) { res.status(400).json({ error: "confirm=true required" }); return; }
  const validation = validateMineRules(req.body, defaultAccountRules("mine").minSecondsRemaining, config.maxTradeSizeUsd);
  if ("error" in validation) { res.status(400).json({ error: validation.error }); return; }
  const rules: AccountRules = { ...(engine?.rules ?? mineAccount().rules ?? defaultAccountRules("mine")), ...validation.rules };
  const account = mineAccount();
  const version = (account.rulesVersion ?? 1) + 1;
  account.rules = { ...rules };
  account.rulesVersion = version;
  account.rulesHistory = [...(account.rulesHistory ?? []), { version, timestamp: Date.now(), rules: { ...rules } }].slice(-50);
  if (engine) engine.rules = { ...rules };
  if (config.liveTrading) await saveLiveAccount(account);
  else {
    reconcilePaperAccount(account);
    await saveAccounts(state);
  }
  broadcast("momentum_account_update", full());
  res.json({ rules: account.rules, rulesVersion: version, history: account.rulesHistory });
});
app.get("/api/trades.csv", (_req, res) => {
  const csv = buildTradesCsv(mineAccount().ledger);
  res.type("text/csv").setHeader("Content-Disposition", "attachment; filename=\"mine-trades.csv\"");
  res.send(csv);
});
app.get("/api/four-hour/trades.csv", (_req, res) => {
  const csv = buildTradesCsv(state.accounts.fourHour.ledger);
  res.type("text/csv").setHeader("Content-Disposition", "attachment; filename=\"four-hour-trades.csv\"");
  res.send(csv);
});
const resetAccount = async (res: express.Response): Promise<void> => {
  if (config.liveTrading) { res.status(409).json({ error: "Paper reset is disabled while live trading is enabled" }); return; }
  try {
    await resetOneAccountState(state);
    engine?.cancelPendingOrder("account reset");
    state.accounts.mine.rules = defaultAccountRules("mine");
    state.accounts.mine.rulesVersion = 1;
    state.accounts.mine.rulesHistory = [];
    if (engine) engine.rules = defaultAccountRules("mine");
    reconcilePaperAccount(state.accounts.mine);
    await saveAccounts(state);
    broadcast("momentum_account_update", full());
    res.json(full());
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message === "Close the open trade first") { res.status(409).json({ error: message }); return; }
    console.error(`[mine][store] reset archive failed: ${message}`);
    res.status(500).json({ error: "Unable to archive current account" });
  }
};
app.post("/api/reset", async (req, res) => {
  if (req.body?.confirm !== true) { res.status(400).json({ error: "confirm=true required" }); return; }
  await resetAccount(res);
});
app.post("/api/live/kill-switch", async (_req, res) => {
  if (!config.liveTrading || !liveEngine) { res.status(404).json({ error: "Live trading is not enabled" }); return; }
  await liveEngine.killSwitch();
  broadcast("momentum_account_update", full());
  res.json({ status: liveEngine.getStatus() });
});
app.post("/api/four-hour/reset", async (req, res) => {
  if (req.body?.confirm !== true) { res.status(400).json({ error: "confirm=true required" }); return; }
  try {
    fourHourEngine?.cancelPendingOrder("account reset");
    await resetPaperAccount(state, "fourHour");
    reconcilePaperAccount(state.accounts.fourHour);
    await saveAccounts(state);
    broadcast("momentum_account_update", full());
    res.json(full());
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message === "Close the open trade first") { res.status(409).json({ error: message }); return; }
    console.error(`[4h][store] reset failed: ${message}`);
    res.status(500).json({ error: "Unable to reset 4-hour account" });
  }
});
app.get("/events", (req, res) => { res.setHeader("Content-Type", "text/event-stream"); res.setHeader("Cache-Control", "no-cache"); res.setHeader("Connection", "keep-alive"); res.flushHeaders(); clients.add(res); res.write(`event: momentum_account_update\ndata: ${JSON.stringify(full())}\n\n`); req.on("close", () => clients.delete(res)); });
const clientDist = join(process.cwd(), "client", "dist");
app.use(express.static(clientDist, { setHeaders: (res, filePath) => { if (filePath.endsWith("\\index.html") || filePath.endsWith("/index.html")) res.setHeader("Cache-Control", "no-store"); else if (filePath.includes("\\assets\\") || filePath.includes("/assets/")) res.setHeader("Cache-Control", "public, max-age=31536000, immutable"); } }));
app.get("*", (_req, res) => { res.setHeader("Cache-Control", "no-store"); res.sendFile(join(clientDist, "index.html")); });
setInterval(() => {
  if (config.liveTrading) {
    if (liveEngine) void liveEngine.tick(snapshot).catch(() => console.error("[live] tick loop error"));
  } else {
    try { engine?.tick(snapshot); }
    catch (error) { console.error(`[engine] tick loop error: ${error instanceof Error ? error.stack ?? error.message : String(error)}`); }
  }
  try { fourHourEngine?.tick(fourHourSnapshot); }
  catch (error) { console.error(`[4h][engine] tick loop error: ${error instanceof Error ? error.stack ?? error.message : String(error)}`); }
}, config.tickMs);
const priceTick = () => {
  snapshot = { ...snapshot, serverNow: Date.now() };
  fourHourSnapshot = { ...fourHourSnapshot, serverNow: snapshot.serverNow };
  btcReference.observeWindow(snapshot);
  btcReference.observeWindow(fourHourSnapshot);
  snapshot = { ...snapshot, ...btcReference.getValues(snapshot.windowStart) };
  fourHourSnapshot = { ...fourHourSnapshot, ...btcReference.getValues(fourHourSnapshot.windowStart) };
  priceRecorder.tick(snapshot);
  fourHourRecorder.tick(fourHourSnapshot);
  if (!config.liveTrading) {
    const account = state.accounts.mine;
    const equityPointsBefore = account.equityHistory?.length ?? 0;
    recordEquityPoint(account, snapshot, Date.now(), config.feeRate);
    if ((account.equityHistory?.length ?? 0) !== equityPointsBefore) void saveAccounts(state);
  }
  const fourHourEquityBefore = state.accounts.fourHour.equityHistory?.length ?? 0;
  recordEquityPoint(state.accounts.fourHour, fourHourSnapshot, Date.now(), config.feeRate);
  if ((state.accounts.fourHour.equityHistory?.length ?? 0) !== fourHourEquityBefore) void saveAccounts(state);
  const stale = snapshot.feedHealth === "LIVE" && (Date.now() - Math.max(snapshot.up.lastUpdateTs, snapshot.down.lastUpdateTs) > 3000);
  if (stale) snapshot = { ...snapshot, feedHealth: "STALE", feedMessage: "WebSocket connected but no price update for 3 seconds" };
  const metrics = calculatePortfolioMetrics(mineAccount(), snapshot, config.feeRate);
  if (config.liveTrading) {
    metrics.unrealizedPnl = 0;
    metrics.equity = mineAccount().cashBalance + (mineAccount().openPosition?.cost ?? 0);
  }
  broadcast("price_tick", {
    up: snapshot.up, down: snapshot.down, feedHealth: snapshot.feedHealth, feedMessage: snapshot.feedMessage,
    windowId: snapshot.windowId, windowStart: snapshot.windowStart, windowEnd: snapshot.windowEnd,
    windowTitle: snapshot.windowTitle, serverNow: snapshot.serverNow,
    priceToBeat: snapshot.priceToBeat, priceToBeatSource: snapshot.priceToBeatSource,
    btcPrice: snapshot.btcPrice, btcPriceSource: snapshot.btcPriceSource,
    secondsRemaining: Math.max(0, snapshot.windowEnd - Date.now() / 1000),
    metrics, entryStatus: engine?.getStatuses(), account: config.liveTrading ? full().account : undefined,
    liveTrading: config.liveTrading ? liveEngine?.getStatus() ?? null : null,
    fourHour: { ...fourHourFull(), secondsRemaining: Math.max(0, fourHourSnapshot.windowEnd - Date.now() / 1000) }
  });
};
setInterval(priceTick, 500);
setInterval(() => {
  void btcReference.refresh(snapshot).then((prices) => {
    snapshot = { ...snapshot, ...prices };
    fourHourSnapshot = { ...fourHourSnapshot, ...btcReference.getValues(fourHourSnapshot.windowStart) };
    priceTick();
  }).catch(() => {
    snapshot = { ...snapshot, btcPrice: null, btcPriceSource: null };
    fourHourSnapshot = { ...fourHourSnapshot, btcPrice: null, btcPriceSource: null };
    priceTick();
  });
}, 1000);
setInterval(() => { for (const client of clients) client.write(": keep-alive\n\n"); }, 15000);
const resolverFor = (marketType: "1h" | "4h") => async (position: NonNullable<PaperAccount["openPosition"]>) => {
  const windowStart = position.windowStart ?? marketWindowStart(marketType, position.openedAt);
  return lookupResolution(windowStart, marketType);
};
const initializeLiveClient = async (): Promise<void> => {
  let retryMs = 1000;
  while (config.liveTrading && liveOptions && !liveOptions.client) {
    try {
      liveOptions.client = await createLiveClobClient(process.env);
      return;
    } catch {
      liveEngine?.reportStartupError("Live CLOB unavailable; entries paused");
      console.error("[live] CLOB credentials or connection unavailable; retry scheduled");
      await new Promise((resolve) => setTimeout(resolve, retryMs));
      retryMs = Math.min(retryMs * 2, LIVE_TRADING_CONFIG.MAX_RETRY_MS);
    }
  }
};
const start = async (): Promise<void> => {
  await initializeTelegram();
  sendTelegram("Bot started");
  void priceRecorder.start();
  void fourHourRecorder.start();
  btcReference.start();
  state = await loadAccounts();
  if (config.liveTrading) {
    liveAccount = await loadLiveAccount();
    liveAccount.rules ??= defaultAccountRules("mine");
    liveOptions = {
      client: null,
      account: liveAccount,
      funderAddress: config.polyFunderAddress,
      enabled: true,
      resolveWindow: (windowStart) => lookupResolution(windowStart, "1h"),
      persist: () => saveLiveAccount(liveAccount!),
      log: (message) => console.info(message),
      auditDirectory: join(config.dataDir, "live-orders"),
      notifyTrade: (notice) => sendTelegramTradeNotice({ ...notice, market: "1H", mode: "LIVE" })
    };
    liveEngine = new LiveTradingEngine(liveOptions);
    liveEngine.reportStartupError("Connecting to Polymarket CLOB; entries paused");
    await saveLiveAccount(liveAccount);
  } else {
    const account = state.accounts.mine;
    console.info("[mine][engine] pending orders are memory-only; none restored");
    const rules = account.rules ?? defaultAccountRules("mine");
    account.rules = rules;
    account.rulesVersion ??= 1;
    engine = new EntryEngine(config, account, new PaperExecutor(config), () => {
      reconcilePaperAccount(account);
      void saveAccounts(state);
      broadcast("momentum_account_update", full());
    }, resolverFor("1h"), Date.now(), "mine", rules, Math.random, Date.now, {}, (notice) =>
      sendTelegramTradeNotice({ ...notice, market: "1H", mode: "PAPER" }));
    await engine.recoverStalePosition();
  }
  const fourHourAccount = state.accounts.fourHour;
  const fourHourRules = defaultAccountRules("fourHour");
  fourHourAccount.rules = fourHourRules;
  fourHourEngine = new EntryEngine(config, fourHourAccount, new PaperExecutor(config), () => {
    reconcilePaperAccount(fourHourAccount);
    void saveAccounts(state);
    broadcast("momentum_account_update", full());
  }, resolverFor("4h"), Date.now(), "fourHour", fourHourRules, Math.random, Date.now, {
    windowSeconds: FOUR_HOUR_BOT_CONFIG.windowSeconds,
    holdToResolution: true,
    continuousEntryBand: true,
    strictlyExceedsHold: true
  }, (notice) => sendTelegramTradeNotice({ ...notice, market: "4H", mode: "PAPER" }));
  await fourHourEngine.recoverStalePosition();
  if (!config.liveTrading) reconcilePaperAccount(state.accounts.mine);
  await saveAccounts(state);
  server.listen(config.port, () => {
    if (config.liveTrading) console.log(`[mine][live] enabled stake=${LIVE_TRADING_CONFIG.STAKE_USD} entry=${LIVE_TRADING_CONFIG.ENTRY_MIN}-${LIVE_TRADING_CONFIG.ENTRY_MAX} hold=${LIVE_TRADING_CONFIG.HOLD_SECONDS}s`);
    else console.log(`[mine][rules] entry=${JSON.stringify(state.accounts.mine.rules)} source=saved-account (entry/target/stop/size/gap table); runtime fees=${config.feeRate} source=env/default fillDelay=${config.fillDelayMinMs}-${config.fillDelayMaxMs} source=env/default`);
    console.log(`Paper terminal server listening on http://localhost:${config.port}`);
  });
  if (config.liveTrading) void initializeLiveClient();
  const feed = new MarketFeed((next) => {
    btcReference.observeWindow(next);
    snapshot = btcReference.attach(next);
    priceTick();
  });
  const fourHourFeed = new MarketFeed((next) => {
    btcReference.observeWindow(next);
    fourHourSnapshot = btcReference.attach(next);
    priceTick();
  }, "4h");
  void feed.connect();
  void fourHourFeed.connect();
};
void start();
