import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { config, defaultAccountRules } from "./config.js";
import { freshAccount } from "./store.js";
import type { PaperAccount } from "./types.js";

export const liveAccountPath = join(config.dataDir, "live_1h_state.json");
const saveQueues = new Map<string, Promise<void>>();

export const loadLiveAccount = async (path = liveAccountPath): Promise<PaperAccount> => {
  let contents: string;
  try {
    contents = await readFile(path, "utf8");
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "ENOENT") return freshAccount("mine");
    throw error;
  }
  const stored = JSON.parse(contents) as Partial<PaperAccount>;
  const account = { ...freshAccount("mine"), ...stored };
  account.cashBalance = Number.isFinite(account.cashBalance) ? Math.max(0, account.cashBalance) : account.startingBalance;
  account.rules = { ...defaultAccountRules("mine"), ...(stored.rules ?? {}) };
  account.ledger = (stored.ledger ?? []).map((fill) => ({
    ...fill, id: fill.id ?? randomUUID(), timestamp: fill.timestamp ?? 0,
    windowId: fill.windowId ?? "", fee: fill.fee ?? 0, slippage: fill.slippage ?? 0
  }));
  account.entriesThisWindow ??= {};
  account.lastEntryExitByOutcome ??= {};
  account.dailyPnl ??= {};
  return account;
};

export const saveLiveAccount = async (account: PaperAccount, path = liveAccountPath): Promise<void> => {
  const prior = saveQueues.get(path) ?? Promise.resolve();
  const next = prior.then(async () => {
    await mkdir(dirname(path), { recursive: true });
    const temporary = `${path}.${randomUUID()}.tmp`;
    await writeFile(temporary, JSON.stringify(account, null, 2), "utf8");
    await rename(temporary, path);
  });
  saveQueues.set(path, next);
  try { await next; }
  finally { if (saveQueues.get(path) === next) saveQueues.delete(path); }
};
