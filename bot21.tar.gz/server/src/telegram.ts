import { homedir } from "node:os";
import { join } from "node:path";
import { readFile } from "node:fs/promises";

export interface TelegramTradeNotice {
  kind: "opened" | "closed" | "rejected";
  market: "1H" | "4H";
  mode: "PAPER" | "LIVE";
  side?: "UP" | "DOWN";
  price?: number;
  shares?: number;
  usd?: number;
  priceToBeat?: number | null;
  btcPrice?: number | null;
  secondsLeft?: number;
  reason?: string;
  pnl?: number;
  pnlPercent?: number;
  balance?: number;
}

const escapeHtml = (value: string): string =>
  value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const usd = (value: number | null | undefined): string =>
  typeof value === "number" && Number.isFinite(value) ? `$${value.toFixed(2)}` : "--";

const price = (value: number | null | undefined): string =>
  typeof value === "number" && Number.isFinite(value) ? `$${value.toFixed(4)}` : "--";

const signedUsd = (value: number): string => `${value >= 0 ? "+" : "-"}$${Math.abs(value).toFixed(2)}`;

export const formatTelegramTradeNotice = (notice: TelegramTradeNotice): string => {
  const label = `${notice.market} · ${notice.mode}`;
  if (notice.kind === "rejected") {
    return `⚠️ <b>Trade rejected · ${label}</b>\nReason: ${escapeHtml(notice.reason ?? "Unknown")}`;
  }
  if (notice.kind === "opened") {
    return [
      `🟢 <b>BUY opened · ${label}</b>`,
      `Side: ${notice.side ?? "--"}`,
      `Entry: ${price(notice.price)}`,
      `Shares: ${notice.shares?.toFixed(4) ?? "--"}`,
      `Amount: ${usd(notice.usd)}`,
      `Price to beat: ${usd(notice.priceToBeat)}`,
      `Current BTC: ${usd(notice.btcPrice)}`,
      `Seconds left: ${notice.secondsLeft?.toFixed(0) ?? "--"}`
    ].join("\n");
  }
  const pnl = notice.pnl ?? 0;
  const icon = pnl >= 0 ? "🟢" : "🔴";
  const signedPercent = `${(notice.pnlPercent ?? 0) >= 0 ? "+" : ""}${(notice.pnlPercent ?? 0).toFixed(2)}%`;
  return [
    `${icon} <b>SELL closed · ${label}</b>`,
    `Side: ${notice.side ?? "--"}`,
    `Exit: ${price(notice.price)}`,
    `Reason: ${escapeHtml(notice.reason ?? "unknown")}`,
    `PnL: ${signedUsd(pnl)} (${signedPercent})`,
    `New balance: ${usd(notice.balance)}`
  ].join("\n");
};

export class TelegramNotifier {
  public constructor(
    private readonly token: string,
    private readonly chatId: string,
    private readonly fetcher: typeof fetch = fetch,
    private readonly log: (message: string) => void = console.info
  ) {}

  public send(text: string): void {
    void this.deliver(text).catch(() => undefined);
  }

  private async deliver(text: string): Promise<void> {
    let failure = "request failed";
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10_000);
      try {
        const response = await this.fetcher(`https://api.telegram.org/bot${this.token}/sendMessage`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ chat_id: this.chatId, text, parse_mode: "HTML" }),
          signal: controller.signal
        });
        if (response.ok) {
          const result = await response.json() as { ok?: boolean; description?: string };
          if (result.ok !== false) return;
          failure = result.description || "Telegram rejected the message";
        } else {
          const result = await response.json().catch(() => null) as { description?: string } | null;
          failure = result?.description || `HTTP ${response.status}`;
        }
      } catch {
        failure = "request failed or timed out";
      } finally {
        clearTimeout(timeout);
      }
    }
    const safeFailure = this.token ? failure.split(this.token).join("[redacted]") : failure;
    try { this.log(`Telegram send failed: ${safeFailure}`); }
    catch { /* Notification logging must not affect the bot. */ }
  }
}

let notifier: TelegramNotifier | undefined;
let disabledLogged = false;

const readTelegramFile = async (): Promise<Record<string, string>> => {
  try {
    const contents = await readFile(join(homedir(), ".telegram.env"), "utf8");
    const values: Record<string, string> = {};
    for (const line of contents.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const separator = trimmed.indexOf("=");
      if (separator <= 0) continue;
      const key = trimmed.slice(0, separator).trim();
      let value = trimmed.slice(separator + 1).trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      values[key] = value;
    }
    return values;
  } catch {
    return {};
  }
};

export const initializeTelegram = async (): Promise<void> => {
  const fileValues = await readTelegramFile();
  const token = fileValues.TELEGRAM_BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN || "";
  const chatId = fileValues.TELEGRAM_CHAT_ID || process.env.TELEGRAM_CHAT_ID || "";
  if (!token || !chatId) {
    notifier = undefined;
    if (!disabledLogged) {
      console.info("Telegram disabled");
      disabledLogged = true;
    }
    return;
  }
  notifier = new TelegramNotifier(token, chatId, fetch, (message) => console.error(message));
  disabledLogged = false;
};

export const sendTelegram = (text: string): void => {
  notifier?.send(text);
};

export const sendTelegramTradeNotice = (notice: TelegramTradeNotice): void => {
  sendTelegram(formatTelegramTradeNotice(notice));
};
