import { describe, expect, it } from "vitest";
import { formatTelegramTradeNotice, TelegramNotifier } from "./telegram.js";

describe("Telegram notifications", () => {
  it("formats labeled trade notices with a separate fact per line", () => {
    const text = formatTelegramTradeNotice({
      kind: "opened", market: "4H", mode: "PAPER", side: "DOWN", price: 0.92, shares: 12.5, usd: 11.5,
      priceToBeat: 74000, btcPrice: 74100, secondsLeft: 1200
    });
    expect(text).toContain("BUY opened · 4H · PAPER");
    expect(text).toContain("Side: DOWN");
    expect(text).toContain("Price to beat: $74000.00");
    expect(text.split("\n")).toHaveLength(8);
  });

  it("retries one failure and redacts the token from logged descriptions", async () => {
    const token = "secret-bot-token";
    let calls = 0;
    let requestUrl = "";
    let requestBody = "";
    let logged = "";
    let finish!: () => void;
    const loggedPromise = new Promise<void>((resolve) => { finish = resolve; });
    const notifier = new TelegramNotifier(token, "chat-1", async (input, init) => {
      calls += 1;
      requestUrl = String(input);
      requestBody = String(init?.body);
      return new Response(JSON.stringify({ ok: false, description: `invalid token ${token}` }), { status: 400 });
    }, (message) => { logged = message; finish(); });

    expect(() => notifier.send("hello")).not.toThrow();
    await loggedPromise;
    expect(calls).toBe(2);
    expect(requestUrl).toContain(token);
    expect(JSON.parse(requestBody)).toMatchObject({ chat_id: "chat-1", text: "hello", parse_mode: "HTML" });
    expect(logged).toContain("invalid token [redacted]");
    expect(logged).not.toContain(token);
  });
});
