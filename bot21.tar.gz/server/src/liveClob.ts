import { readFile } from "node:fs/promises";
import { ClobClient, Chain, AssetType, OrderType, Side, SignatureType } from "@polymarket/clob-client";
import type { TickSize } from "@polymarket/clob-client";
import { createWalletClient, http } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { polygon } from "viem/chains";
import type { LiveChainPosition, LiveClobClient, LiveOrderBook, LiveTrade } from "./liveTrading.js";

const CLOB_HOST = "https://clob.polymarket.com";
const DATA_API = "https://data-api.polymarket.com/positions";
const KEY_PATTERN = /^0x[0-9a-fA-F]{64}$/;

const readPrivateKey = async (environment: NodeJS.ProcessEnv): Promise<`0x${string}`> => {
  let key = environment.POLY_PRIVATE_KEY?.trim();
  if (!key && environment.POLY_KEY_FILE) {
    try { key = (await readFile(environment.POLY_KEY_FILE, "utf8")).trim(); }
    catch { throw new Error("LIVE_CREDENTIALS_UNAVAILABLE"); }
  }
  if (!key || !KEY_PATTERN.test(key)) throw new Error("LIVE_CREDENTIALS_UNAVAILABLE");
  return key as `0x${string}`;
};

class PolymarketClobAdapter implements LiveClobClient {
  public constructor(private readonly client: ClobClient, private readonly funder: string, private readonly fetcher: typeof fetch) {}
  public async getOrderBook(tokenId: string): Promise<LiveOrderBook> {
    return await this.client.getOrderBook(tokenId) as LiveOrderBook;
  }
  public async getTickSize(tokenId: string): Promise<string> {
    return await this.client.getTickSize(tokenId);
  }
  public async getNegRisk(tokenId: string): Promise<boolean> {
    return await this.client.getNegRisk(tokenId);
  }
  public async getBalanceAllowance(_params: { asset_type: "COLLATERAL" }): Promise<{ balance: string }> {
    return await this.client.getBalanceAllowance({ asset_type: AssetType.COLLATERAL });
  }
  public async getFeeRateBps(tokenId: string): Promise<number> {
    return await this.client.getFeeRateBps(tokenId);
  }
  public async createAndPostMarketOrder(
    order: { tokenID: string; amount: number; price: number; side: "BUY" | "SELL" },
    options: { tickSize: string; negRisk: boolean },
    orderType: "FAK"
  ): Promise<unknown> {
    return await this.client.createAndPostMarketOrder(
      { ...order, side: order.side === "BUY" ? Side.BUY : Side.SELL, orderType: OrderType.FAK },
      { tickSize: options.tickSize as TickSize, negRisk: options.negRisk },
      OrderType.FAK
    );
  }
  public async getOpenOrders(): Promise<Array<{ id?: string; asset_id?: string }>> {
    return await this.client.getOpenOrders();
  }
  public async getTrades(params?: { asset_id?: string }): Promise<LiveTrade[]> {
    return await this.client.getTrades(params);
  }
  public async getPositions(): Promise<LiveChainPosition[]> {
    const response = await this.fetcher(`${DATA_API}?user=${encodeURIComponent(this.funder)}`);
    if (!response.ok) throw new Error("LIVE_POSITIONS_UNAVAILABLE");
    const rows: unknown = await response.json();
    return Array.isArray(rows) ? rows as LiveChainPosition[] : [];
  }
  public async cancelOrders(orderIds: string[]): Promise<unknown> {
    return await this.client.cancelOrders(orderIds);
  }
  public async cancelAll(): Promise<unknown> {
    return await this.client.cancelAll();
  }
}

export const createLiveClobClient = async (
  environment: NodeJS.ProcessEnv = process.env,
  fetcher: typeof fetch = fetch
): Promise<LiveClobClient> => {
  const key = await readPrivateKey(environment);
  const funder = environment.POLY_FUNDER_ADDRESS || "0x0ef09cca617a7ab3a35d11a7c375fb1eb45051b5";
  const signatureType = Number(environment.POLY_SIGNATURE_TYPE ?? "1");
  if (signatureType !== 1 || !/^0x[0-9a-fA-F]{40}$/.test(funder)) throw new Error("LIVE_CREDENTIALS_UNAVAILABLE");
  const account = privateKeyToAccount(key);
  const signer = createWalletClient({ account, chain: polygon, transport: http() });
  const unauthenticated = new ClobClient(CLOB_HOST, Chain.POLYGON, signer);
  const credentials = await unauthenticated.createOrDeriveApiKey();
  const client = new ClobClient(
    CLOB_HOST, Chain.POLYGON, signer, credentials, SignatureType.POLY_PROXY, funder,
    undefined, true, undefined, undefined, true, undefined, true
  );
  return new PolymarketClobAdapter(client, funder, fetcher);
};
