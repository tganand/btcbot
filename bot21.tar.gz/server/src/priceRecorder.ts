import { constants } from "node:fs";
import { appendFile, copyFile, mkdir, readdir, stat, unlink } from "node:fs/promises";
import { createReadStream, createWriteStream } from "node:fs";
import { join } from "node:path";
import { createGunzip, createGzip } from "node:zlib";
import { pipeline } from "node:stream/promises";
import type { MarketSnapshot, MarketType, Outcome, Resolution } from "./types.js";

const HOUR_FILE = /^\d{4}-\d{2}-\d{2}-\d{2}\.ndjson(?:\.gz)?$/;
const RESULT_RETRY_MS = 30_000;
const RESULT_TIMEOUT_MS = 10 * 60_000;
const STATUS_LOG_MS = 10 * 60_000;

export interface PriceRecorderOptions {
  directory: string;
  marketType?: MarketType;
  enabled?: boolean;
  maxBytes?: number;
  now?: () => number;
  resolveWindow: (windowStart: number) => Promise<Resolution | null>;
  log?: (message: string) => void;
}

export interface RecordingStatus {
  enabled: boolean;
  filesCount: number;
  totalBytes: number;
  lastWriteTs: number | null;
  linesToday: number;
  currentFile: string | null;
}

interface PendingResult {
  windowSlug: string;
  windowStart: number;
  startedAt: number;
  nextAttemptAt: number;
  inFlight: boolean;
  btc: number | null;
  priceToBeat: number | null;
}

const hourFileFor = (timestamp: number): string =>
  `${new Date(timestamp).toISOString().slice(0, 13).replace("T", "-")}.ndjson`;

const windowStartFor = (snapshot: MarketSnapshot): number => {
  if (snapshot.windowStart > 0) return snapshot.windowStart;
  const suffix = snapshot.windowSlug?.match(/-(\d{9,})$/)?.[1];
  return suffix ? Number(suffix) : 0;
};

export class PriceRecorder {
  private readonly now: () => number;
  private readonly log: (message: string) => void;
  private readonly enabled: boolean;
  private readonly maxBytes: number;
  private readonly marketType: MarketType;
  private queue: Promise<void> = Promise.resolve();
  private initialized = false;
  private initialization: Promise<void> | null = null;
  private lastRecordedSecond = -1;
  private lastObserved: { windowSlug: string; windowStart: number; windowEnd: number; btc: number | null; priceToBeat: number | null } | null = null;
  private readonly pendingResults = new Map<string, PendingResult>();
  private readonly completedResults = new Set<string>();
  private readonly resultTasks = new Set<Promise<void>>();
  private sizeLimitReached = false;
  private lastWriteTs: number | null = null;
  private linesToday = 0;
  private currentFile: string | null = null;
  private nextStatusLogAt = 0;
  private cachedStatus: RecordingStatus;

  public constructor(private readonly options: PriceRecorderOptions) {
    this.now = options.now ?? Date.now;
    this.log = options.log ?? console.info;
    this.enabled = options.enabled ?? true;
    this.maxBytes = (options.maxBytes ?? 500 * 1024 * 1024);
    this.marketType = options.marketType ?? "1h";
    this.cachedStatus = {
      enabled: this.enabled,
      filesCount: 0,
      totalBytes: 0,
      lastWriteTs: null,
      linesToday: 0,
      currentFile: null
    };
  }

  public start(): Promise<void> {
    if (!this.initialization) {
      this.initialization = this.initialize().catch(() => {
        this.error("startup");
      });
    }
    return this.initialization;
  }

  public tick(snapshot: MarketSnapshot): void {
    try {
      const now = this.now();
      if (this.enabled) this.tickResults(snapshot, now);
      if (this.enabled && snapshot.windowSlug && snapshot.windowStart > 0 && snapshot.windowEnd > 0) {
        const second = Math.floor(now / 1000);
        if (second !== this.lastRecordedSecond) {
          this.lastRecordedSecond = second;
          const row = {
            ts: now,
            marketType: this.marketType,
            windowSlug: snapshot.windowSlug,
            btc: snapshot.btcPrice ?? null,
            priceToBeat: snapshot.priceToBeat ?? null,
            secondsRemaining: Math.max(0, snapshot.windowEnd - now / 1000),
            feedHealth: snapshot.feedHealth,
            up: { bid: snapshot.up.bid, ask: snapshot.up.ask, bidSize: snapshot.up.bidSize, askSize: snapshot.up.askSize },
            down: { bid: snapshot.down.bid, ask: snapshot.down.ask, bidSize: snapshot.down.bidSize, askSize: snapshot.down.askSize }
          };
          this.enqueue(() => this.writeLine(now, row));
        }
      }
      if (now >= this.nextStatusLogAt) {
        this.nextStatusLogAt = now + STATUS_LOG_MS;
        if (this.enabled) {
          void this.getStatus().then((status) => {
            this.log(`[recorder] enabled=${status.enabled} files=${status.filesCount} bytes=${status.totalBytes}`);
          }).catch(() => this.error("status"));
        }
      }
    } catch {
      this.error("tick");
    }
  }

  public async getStatus(): Promise<RecordingStatus> {
    try {
      await this.start();
      await this.queue;
      const files = await readdir(this.options.directory);
      let totalBytes = 0;
      let filesCount = 0;
      let linesToday = 0;
      const todayPrefix = new Date(this.now()).toISOString().slice(0, 10);
      for (const file of files) {
        if (!HOUR_FILE.test(file)) continue;
        const path = join(this.options.directory, file);
        const fileStat = await stat(path);
        filesCount += 1;
        totalBytes += fileStat.size;
        this.lastWriteTs = Math.max(this.lastWriteTs ?? 0, fileStat.mtimeMs);
        if (file.startsWith(`${todayPrefix}-`)) linesToday += await this.countLines(path, file.endsWith(".gz"));
      }
      this.linesToday = linesToday;
      const activeHour = hourFileFor(this.now());
      this.currentFile = files.includes(activeHour) ? activeHour : null;
      this.cachedStatus = {
        enabled: this.enabled && !this.sizeLimitReached,
        filesCount,
        totalBytes,
        lastWriteTs: this.lastWriteTs,
        linesToday,
        currentFile: this.currentFile
      };
      return { ...this.cachedStatus };
    } catch {
      this.error("status");
      return { ...this.cachedStatus };
    }
  }

  public async flush(): Promise<void> {
    await this.start();
    while (true) {
      await this.queue;
      const tasks = [...this.resultTasks];
      if (!tasks.length) return;
      await Promise.all(tasks);
    }
  }

  private async initialize(): Promise<void> {
    try {
      await mkdir(this.options.directory, { recursive: true });
      if (this.enabled) await this.compressOlderFiles(this.now());
      await this.refreshCachedSize();
      this.initialized = true;
      this.nextStatusLogAt = this.now() + STATUS_LOG_MS;
    } catch {
      this.error("startup");
    }
  }

  private tickResults(snapshot: MarketSnapshot, now: number): void {
    const slug = snapshot.windowSlug;
    const start = windowStartFor(snapshot);
    if (!slug || start <= 0 || snapshot.windowEnd <= 0) return;
    if (this.lastObserved && this.lastObserved.windowSlug !== slug) {
      this.queueResult(this.lastObserved.windowSlug, this.lastObserved.windowStart, now, this.lastObserved.btc, this.lastObserved.priceToBeat);
    }
    this.lastObserved = { windowSlug: slug, windowStart: start, windowEnd: snapshot.windowEnd, btc: snapshot.btcPrice ?? null, priceToBeat: snapshot.priceToBeat ?? null };
    if (now >= snapshot.windowEnd * 1000) this.queueResult(slug, start, now, snapshot.btcPrice ?? null, snapshot.priceToBeat ?? null);
    for (const result of this.pendingResults.values()) {
      if (!result.inFlight && now >= result.nextAttemptAt) {
        const task = this.resolveResult(result, now);
        this.resultTasks.add(task);
        void task.then(() => this.resultTasks.delete(task), () => this.resultTasks.delete(task));
      }
    }
  }

  private queueResult(windowSlug: string, windowStart: number, now: number, btc: number | null, priceToBeat: number | null): void {
    if (this.completedResults.has(windowSlug) || this.pendingResults.has(windowSlug)) return;
    this.pendingResults.set(windowSlug, {
      windowSlug, windowStart, startedAt: now, nextAttemptAt: now, inFlight: false, btc, priceToBeat
    });
  }

  private async resolveResult(result: PendingResult, now: number): Promise<void> {
    if (result.inFlight || !this.pendingResults.has(result.windowSlug)) return;
    result.inFlight = true;
    try {
      if (now - result.startedAt >= RESULT_TIMEOUT_MS) {
        if (!await this.writeResult(result, null, now)) result.nextAttemptAt = now + RESULT_RETRY_MS;
        return;
      }
      const resolution = await this.options.resolveWindow(result.windowStart);
      if (resolution?.outcome === "UP" || resolution?.outcome === "DOWN") {
        if (!await this.writeResult(result, resolution.outcome, now)) result.nextAttemptAt = now + RESULT_RETRY_MS;
      } else {
        result.nextAttemptAt = now + RESULT_RETRY_MS;
      }
    } catch {
      this.error("result");
      result.nextAttemptAt = now + RESULT_RETRY_MS;
    } finally {
      result.inFlight = false;
    }
  }

  private async writeResult(result: PendingResult, winner: Outcome | null, now: number): Promise<boolean> {
    if (!this.enabled) return true;
    const written = await this.enqueueAsync(() => this.writeLine(now, {
      type: "result", marketType: this.marketType, windowSlug: result.windowSlug, winner, ts: now,
      btc: result.btc, priceToBeat: result.priceToBeat
    }));
    if (!written) return false;
    this.pendingResults.delete(result.windowSlug);
    this.completedResults.add(result.windowSlug);
    return true;
  }

  private enqueue(task: () => Promise<void>): void {
    void this.enqueueAsync(task);
  }

  private enqueueAsync(task: () => Promise<void>): Promise<boolean> {
    const next = this.queue.then(async () => {
      await this.start();
      if (!this.initialized) return false;
      await task();
      return true;
    });
    this.queue = next.then(() => undefined, () => {
      this.error("write");
      return undefined;
    });
    return next.then((written) => written, () => false);
  }

  private async writeLine(timestamp: number, row: Record<string, unknown>): Promise<void> {
    if (!this.enabled || this.sizeLimitReached) return;
    const file = hourFileFor(timestamp);
    const path = join(this.options.directory, file);
    const gzPath = `${path}.gz`;
    await this.compressOlderFiles(timestamp);
    const compressedExists = await stat(gzPath).then(() => true, () => false);
    if (compressedExists) {
      this.sizeLimitReached = true;
      this.cachedStatus.enabled = false;
      this.error("hour already compressed");
      return;
    }
    const line = `${JSON.stringify(row)}\n`;
    const folderSize = await this.folderSize();
    if (folderSize + Buffer.byteLength(line) > this.maxBytes) {
      this.sizeLimitReached = true;
      this.cachedStatus.enabled = false;
      this.error("size limit reached");
      return;
    }
    await appendFile(path, line, "utf8");
    this.currentFile = file;
    this.lastWriteTs = timestamp;
    this.linesToday += new Date(timestamp).toISOString().slice(0, 10) === new Date(this.now()).toISOString().slice(0, 10) ? 1 : 0;
    this.cachedStatus.lastWriteTs = timestamp;
    this.cachedStatus.linesToday = this.linesToday;
    this.cachedStatus.currentFile = file;
    this.cachedStatus.totalBytes = folderSize + Buffer.byteLength(line);
    this.cachedStatus.filesCount = (await this.fileNames()).length;
  }

  private async compressOlderFiles(now: number): Promise<void> {
    const currentHour = hourFileFor(now);
    for (const file of await this.fileNames()) {
      if (!file.endsWith(".ndjson") || file >= currentHour) continue;
      const source = join(this.options.directory, file);
      const target = `${source}.gz`;
      if (await stat(target).then(() => true, () => false)) continue;
      const temp = `${target}.${process.pid}.tmp`;
      try {
        await pipeline(createReadStream(source), createGzip(), createWriteStream(temp, { flags: "wx" }));
        await copyFile(temp, target, constants.COPYFILE_EXCL);
        await unlink(temp);
        await unlink(source);
      } catch (error) {
        await unlink(temp).catch(() => undefined);
        if ((error as NodeJS.ErrnoException).code === "EEXIST") continue;
        throw error;
      }
    }
    if (this.currentFile && this.currentFile < currentHour) this.currentFile = null;
  }

  private async fileNames(): Promise<string[]> {
    return (await readdir(this.options.directory)).filter((file) => HOUR_FILE.test(file));
  }

  private async folderSize(): Promise<number> {
    let total = 0;
    for (const file of await readdir(this.options.directory)) {
      const fileStat = await stat(join(this.options.directory, file));
      if (fileStat.isFile()) total += fileStat.size;
    }
    return total;
  }

  private async refreshCachedSize(): Promise<void> {
    const files = await this.fileNames();
    const totalBytes = await this.folderSize();
    this.cachedStatus.filesCount = files.length;
    this.cachedStatus.totalBytes = totalBytes;
    if (totalBytes > this.maxBytes) {
      this.sizeLimitReached = true;
      this.cachedStatus.enabled = false;
      this.error("size limit reached");
    }
  }

  private async countLines(path: string, compressed: boolean): Promise<number> {
    const input = createReadStream(path);
    const lines = compressed ? input.pipe(createGunzip()) : input;
    let count = 0;
    for await (const _line of lines) count += 1;
    return count;
  }

  private error(operation: string): void {
    this.log(`[recorder] ${operation} failed`);
  }
}
