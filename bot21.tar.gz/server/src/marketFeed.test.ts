import { describe, expect, it } from "vitest";
import { buildFourHourSlug, buildHourlySlug, fourHourWindowStart, hourlyWindowStart, marketWindowEnd, nextFourHourWindowStart, parseDiscoveredMarket } from "./marketFeed.js";

const seconds = (value: string): number => Date.parse(value) / 1000;

describe("hourly market discovery", () => {
  it("builds the requested hourly slugs including noon and midnight", () => {
    expect(buildHourlySlug(seconds("2026-11-10T05:00:00Z"))).toBe("bitcoin-up-or-down-november-10-2026-12am-et");
    expect(buildHourlySlug(seconds("2026-11-10T17:00:00Z"))).toBe("bitcoin-up-or-down-november-10-2026-12pm-et");
    expect(buildHourlySlug(seconds("2026-11-10T07:00:00Z"))).toBe("bitcoin-up-or-down-november-10-2026-2am-et");
  });

  describe("4-hour market discovery", () => {
    it("builds timestamp slugs and aligns starts to ET 4-hour boundaries", () => {
      const start = seconds("2026-06-15T12:00:00Z");
      expect(buildFourHourSlug(start)).toBe(`btc-updown-4h-${start}`);
      expect(fourHourWindowStart(Date.parse("2026-06-15T15:22:00Z"))).toBe(seconds("2026-06-15T12:00:00Z"));
      expect(marketWindowEnd("4h", start)).toBe(seconds("2026-06-15T16:00:00Z"));
    });

    it("uses ET clock boundaries across the November daylight-saving transition", () => {
      const midnightEdt = seconds("2026-11-01T04:00:00Z");
      const fourAmEst = seconds("2026-11-01T09:00:00Z");
      expect(fourHourWindowStart(Date.parse("2026-11-01T06:30:00Z"))).toBe(midnightEdt);
      expect(nextFourHourWindowStart(midnightEdt)).toBe(fourAmEst);
      expect(fourAmEst - midnightEdt).toBe(5 * 3600);
      expect(fourHourWindowStart(Date.parse("2026-11-01T10:00:00Z"))).toBe(fourAmEst);
    });

    it("parses 4-hour token IDs, title, fixed window, and explicit price to beat", () => {
      const start = seconds("2026-11-01T04:00:00Z");
      const discovered = parseDiscoveredMarket([{
        slug: buildFourHourSlug(start),
        title: "Bitcoin Up or Down — 4 hours",
        eventMetadata: { priceToBeat: 70000 },
        markets: [{ clobTokenIds: '["token-down","token-up"]', outcomes: '["Down","Up"]' }]
      }], start, "4h");
      expect(discovered).toMatchObject({
        slug: buildFourHourSlug(start),
        title: "Bitcoin Up or Down — 4 hours",
        windowStart: start,
        windowEnd: seconds("2026-11-01T09:00:00Z"),
        tokens: { UP: "token-up", DOWN: "token-down" },
        priceToBeat: 70000
      });
    });
  });

  it("uses the current ET hour across daylight-saving changes and midnight rollover", () => {
    const justBeforeEtMidnight = Date.parse("2026-11-11T04:59:59Z");
    const atEtMidnight = Date.parse("2026-11-11T05:00:00Z");
    const before = hourlyWindowStart(justBeforeEtMidnight);
    const after = hourlyWindowStart(atEtMidnight);
    expect(buildHourlySlug(before)).toBe("bitcoin-up-or-down-november-10-2026-11pm-et");
    expect(buildHourlySlug(after)).toBe("bitcoin-up-or-down-november-11-2026-12am-et");
    const springForward = hourlyWindowStart(Date.parse("2026-03-08T07:30:00Z"));
    expect(buildHourlySlug(springForward)).toBe("bitcoin-up-or-down-march-8-2026-3am-et");
    expect(springForward).toBe(seconds("2026-03-08T07:00:00Z"));
  });

  it("parses Gamma outcomes and sets an exact one-hour window", () => {
    const start = seconds("2026-11-10T07:00:00Z");
    const discovered = parseDiscoveredMarket([{
      slug: "bitcoin-up-or-down-november-10-2026-2am-et",
      title: "Bitcoin Up or Down",
      markets: [{ clobTokenIds: '["token-up","token-down"]', outcomes: '["Up","Down"]' }]
    }], start);
    expect(discovered).toMatchObject({
      slug: "bitcoin-up-or-down-november-10-2026-2am-et",
      windowStart: start,
      windowEnd: start + 3600,
      tokens: { UP: "token-up", DOWN: "token-down" }
    });
  });
});
