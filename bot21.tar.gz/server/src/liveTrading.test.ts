import { mkdtemp, readFile, readdir, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { defaultAccountRules } from "./config.js";
import { freshAccount } from "./store.js";
import { LiveTradingEngine } from "./liveTrading.js";
import type { LiveChainPosition, LiveClobClient, LiveOrderBook, LiveTrade } from "./liveTrading.js";
import type { MarketSnapshot, PaperAccount } from "./types.js";

const temporaryDirectories: string[] = [];

const snapshot = (): MarketSnapshot => ({
  windowId: "hour-0",
  windowSlug: "bitcoin-up-or-down-june-1-2026-12am-et",
  windowStart: 0,
  windowEnd: 3600,
  tokenIds: { UP: "up-token", DOWN: "down-token" },
  up: { bid: 0.93, ask: 0.94, bidSize: 50, askSize: 50, lastUpdateTs: 1000 },
  down: { bid: 0.05, ask: 0.06, bidSize: 50, askSize: 50, lastUpdateTs: 1000 },
  feedHealth: "LIVE",
  consistent: true,
  feedMessage: "live"
});

type SaleResult = { shares: number; price: number } | { reject: string };

class MockClob implements LiveClobClient {
  public now = 1000;
  public asks = [{ price: "0.94", size: "100" }];
  public bids = [{ price: "0.93", size: "100" }];
  public trades: LiveTrade[] = [];
  public positions: LiveChainPosition[] = [];
  public sales: SaleResult[] = [];
  public bookTimestamp: string | null = null;
  public orders: Array<{ order: { tokenID: string; amount: number; price: number; side: "BUY" | "SELL" }; type: "FAK" }> = [];
  public cancelAllCalls = 0;
  public bookError: Error | null = null;
  public orderError: Error | null = null;
  private nextOrder = 0;

  public async getOrderBook(_tokenId: string): Promise<LiveOrderBook> {
    if (this.bookError) throw this.bookError;
    return {
      timestamp: this.bookTimestamp ?? new Date(this.now).toISOString(),
      bids: this.bids,
      asks: this.asks,
      min_order_size: "5",
      tick_size: "0.01",
      neg_risk: false
    };
  }
  public async getTickSize(): Promise<string> { return "0.01"; }
  public async getNegRisk(): Promise<boolean> { return false; }
  public async getBalanceAllowance(): Promise<{ balance: string }> { return { balance: "100000000" }; }
  public async getFeeRateBps(): Promise<number> { return 700; }
  public async createAndPostMarketOrder(
    order: { tokenID: string; amount: number; price: number; side: "BUY" | "SELL" },
    _options: { tickSize: string; negRisk: boolean },
    orderType: "FAK"
  ): Promise<unknown> {
    this.orders.push({ order, type: orderType });
    if (this.orderError) throw this.orderError;
    const orderID = `order-${++this.nextOrder}`;
    if (order.side === "BUY") {
      const shares = order.amount / 0.94;
      this.trades.push({ taker_order_id: orderID, asset_id: order.tokenID, side: "BUY", size: String(shares), price: "0.94", fee_rate_bps: "700" });
      return { success: true, status: "matched", orderID, takingAmount: String(shares), makingAmount: String(order.amount) };
    }
    const outcome = this.sales.shift() ?? { shares: order.amount, price: 0.4 };
    if ("reject" in outcome) throw new Error(outcome.reject);
    this.trades.push({ taker_order_id: orderID, asset_id: order.tokenID, side: "SELL", size: String(outcome.shares), price: String(outcome.price), fee_rate_bps: "700" });
    return {
      success: true,
      status: outcome.shares < order.amount ? "partially_matched" : "matched",
      orderID,
      takingAmount: String(outcome.shares * outcome.price),
      makingAmount: String(outcome.shares)
    };
  }
  public async getOpenOrders(): Promise<Array<{ id?: string; asset_id?: string }>> { return []; }
  public async getTrades(params?: { asset_id?: string }): Promise<LiveTrade[]> { return this.trades.filter((trade) => !params?.asset_id || trade.asset_id === params.asset_id); }
  public async getPositions(): Promise<LiveChainPosition[]> { return this.positions; }
  public async cancelOrders(): Promise<unknown> { return {}; }
  public async cancelAll(): Promise<unknown> { this.cancelAllCalls += 1; return {}; }
}

const makeAccount = (): PaperAccount => {
  const account = freshAccount("mine");
  account.rules = { ...defaultAccountRules("mine"), enableGapFilter: false };
  return account;
};

const harness = async (account = makeAccount()) => {
  const directory = await mkdtemp(join(tmpdir(), "live-trading-test-"));
  temporaryDirectories.push(directory);
  const client = new MockClob();
  const logs: string[] = [];
  const engine = new LiveTradingEngine({
    client,
    account,
    funderAddress: "0x0000000000000000000000000000000000000001",
    enabled: true,
    resolveWindow: async () => null,
    persist: async () => undefined,
    log: (message) => logs.push(message),
    auditDirectory: directory,
    now: () => client.now
  });
  await engine.recover(snapshot());
  return { account, client, engine, logs, directory };
};

const tickAt = async (engine: LiveTradingEngine, client: MockClob, time: number, current = snapshot()): Promise<void> => {
  client.now = time;
  await engine.tick(current, time);
};

const enter = async (h: Awaited<ReturnType<typeof harness>>): Promise<void> => {
  await tickAt(h.engine, h.client, 2000);
  await tickAt(h.engine, h.client, 12000);
  expect(h.client.orders).toHaveLength(0);
  await tickAt(h.engine, h.client, 13001);
};

afterEach(async () => {
  await Promise.all(temporaryDirectories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});

describe("opt-in 1H live trading controller", () => {
  it("requires more than ten seconds in the entry band, resets outside it, and never buys above the cap", async () => {
    const h = await harness();
    await tickAt(h.engine, h.client, 2000);
    await tickAt(h.engine, h.client, 5000, { ...snapshot(), up: { ...snapshot().up, ask: 0.96 } });
    await tickAt(h.engine, h.client, 6000);
    await tickAt(h.engine, h.client, 15000);
    expect(h.client.orders).toHaveLength(0);
    await tickAt(h.engine, h.client, 17001);
    expect(h.client.orders[0]?.order).toMatchObject({ side: "BUY", amount: 1 });
    expect(h.client.orders[0]?.order.price).toBe(0.95);
    expect(h.client.orders[0]?.type).toBe("FAK");
    expect(h.engine.getStatus()).toMatchObject({ minOrderSize: 5, tickSize: "0.01" });

    const capped = await harness();
    capped.client.asks = [{ price: "0.96", size: "100" }];
    await enter(capped);
    expect(capped.client.orders).toHaveLength(0);
    expect(capped.engine.getStatus().lastAction).toContain("above 0.95");
  });

  it("does not close on empty or stale books and does not send a take-profit order", async () => {
    const h = await harness();
    await enter(h);
    const open = h.account.openPosition;
    expect(open).not.toBeNull();
    await tickAt(h.engine, h.client, 14001);
    expect(h.client.orders).toHaveLength(1);
    expect(h.account.openPosition).not.toBeNull();

    h.client.bids = [];
    await tickAt(h.engine, h.client, 15001);
    expect(h.account.openPosition).not.toBeNull();
    expect(h.engine.getStatus().alert).toBe("Waiting: no bids");

    h.client.bids = [{ price: "0.4", size: "10" }];
    h.client.bookTimestamp = "1970-01-01T00:00:01.000Z";
    await tickAt(h.engine, h.client, 16001);
    expect(h.account.openPosition).not.toBeNull();
    expect(h.client.orders).toHaveLength(1);
  });

  it("confirms stop on two fresh reads, sells at the bid, and retries partial fills and rejected sells", async () => {
    const h = await harness();
    await enter(h);
    h.client.bids = [{ price: "0.4", size: "10" }];
    h.client.sales = [
      { shares: 0.4, price: 0.39 },
      { reject: "minimum size rejected" },
      { shares: 1, price: 0.35 }
    ];
    await tickAt(h.engine, h.client, 14001);
    expect(h.client.orders).toHaveLength(1);
    await tickAt(h.engine, h.client, 15001);
    expect(h.client.orders).toHaveLength(3);
    expect(h.client.orders[1]?.order).toMatchObject({ side: "SELL", price: 0.38, amount: openPositionShares(h.account) + 0.4 });
    expect(h.account.openPosition).not.toBeNull();
    expect(h.account.ledger.filter((fill) => fill.side === "SELL")).toHaveLength(1);
    expect(h.engine.getStatus().alert).toContain("STAKE TOO SMALL TO EXIT SAFELY");
    await tickAt(h.engine, h.client, 16001);
    expect(h.account.openPosition).toBeNull();
    expect(h.account.ledger.filter((fill) => fill.side === "SELL")).toHaveLength(2);
    expect(h.client.orders.every((item) => item.type === "FAK")).toBe(true);
  });

  it("resolves a winning position at the $1 payout without placing a take-profit order", async () => {
    const h = await harness();
    await enter(h);
    h.engine = new LiveTradingEngine({
      client: h.client, account: h.account, funderAddress: "0x0000000000000000000000000000000000000001",
      enabled: true, resolveWindow: async () => ({ outcome: "UP", price: 1 }),
      persist: async () => undefined, auditDirectory: h.directory, now: () => h.client.now
    });
    await h.engine.recover(snapshot());
    await tickAt(h.engine, h.client, 3_600_001, { ...snapshot(), windowId: "next", windowStart: 3600, windowEnd: 7200 });
    const sale = h.account.ledger.filter((fill) => fill.side === "SELL").at(-1);
    expect(sale).toMatchObject({ price: 1, usd: h.account.ledger[0]!.shares, fee: 0, reason: "LIVE_RESOLUTION_WIN" });
    expect(h.account.openPosition).toBeNull();
    expect(h.engine.getStatus().alert).toBe("CLAIM WINNINGS ON POLYMARKET");
    expect(h.client.orders).toHaveLength(1);
  });

  it("ignores limit-order minimum size, but leaves a rejected market sell open with a clear alert", async () => {
    const h = await harness();
    await enter(h);
    expect(h.client.orders[0]?.order.amount).toBe(1);
    h.client.bids = [{ price: "0.4", size: "10" }];
    h.client.sales = [{ reject: "minimum size violation" }];
    await tickAt(h.engine, h.client, 14001);
    await tickAt(h.engine, h.client, 15001);
    expect(h.client.orders).toHaveLength(2);
    expect(h.account.openPosition).not.toBeNull();
    expect(h.engine.getStatus().alert).toContain("STAKE TOO SMALL TO EXIT SAFELY");
  });

  it("enforces the daily loss limit and the authenticated kill-switch action", async () => {
    const account = makeAccount();
    account.dailyPnl = { "1970-01-01": -1.5 };
    const h = await harness(account);
    await tickAt(h.engine, h.client, 2000);
    await tickAt(h.engine, h.client, 13001);
    expect(h.client.orders).toHaveLength(0);
    await h.engine.killSwitch();
    expect(h.client.cancelAllCalls).toBe(1);
    expect(h.engine.getStatus().halted).toBe(true);
    await tickAt(h.engine, h.client, 14001);
    expect(h.client.orders).toHaveLength(0);
  });

  it("reconciles an open CLOB position after restart", async () => {
    const account = makeAccount();
    const client = new MockClob();
    client.positions = [{ asset: "up-token", size: "1.25", avgPrice: "0.94", outcome: "Up" }];
    client.trades = [{ taker_order_id: "prior-buy", asset_id: "up-token", side: "BUY", size: "1.25", price: "0.94", fee_rate_bps: "700" }];
    const directory = await mkdtemp(join(tmpdir(), "live-restart-test-"));
    temporaryDirectories.push(directory);
    const engine = new LiveTradingEngine({
      client, account, funderAddress: "0x0000000000000000000000000000000000000001",
      enabled: true, resolveWindow: async () => null, persist: async () => undefined,
      auditDirectory: directory, now: () => client.now
    });
    await engine.recover(snapshot());
    expect(account.openPosition).toMatchObject({ live: true, tokenId: "up-token", shares: 1.25, entryPrice: 0.94 });
    expect(account.ledger).toHaveLength(1);
    expect(account.entriesThisWindow["hour-0"]).toBe(true);
    expect(engine.getStatus().connected).toBe(true);
  });

  it("never exposes a private key in logs or the order audit", async () => {
    const h = await harness();
    const secret = `0x${"a".repeat(64)}`;
    h.client.orderError = new Error(secret);
    await tickAt(h.engine, h.client, 2000);
    await tickAt(h.engine, h.client, 12000);
    await tickAt(h.engine, h.client, 13001);
    const auditFiles = await readdir(h.directory);
    const auditText = (await Promise.all(auditFiles.map((name) => readFile(join(h.directory, name), "utf8")))).join("\n");
    expect(h.logs.join("\n")).not.toContain(secret);
    expect(auditText).not.toContain(secret);
  });
});

const openPositionShares = (account: PaperAccount): number => account.openPosition?.shares ?? 0;
