# Polymarket Bitcoin Hourly Paper Terminal

This project is **paper-trading only**. It does not create real orders or use wallets or keys. One market feed drives a single simulated account, **My rules**. The state file is stored atomically under `DATA_DIR` (default: `data`). Legacy single-account state and Mine from the previous multi-account format are both migrated with the Mine ledger preserved; any old Claude account is discarded.

The market is the Bitcoin hourly Up/Down event. The server builds each Gamma slug from the current `America/New_York` hour and uses a 3,600-second window. Mine starts with $100 and defaults to entry range 93¢–95¢, a 99¢ target, a $10 stop loss, and a $100 trade budget. `MAX_TRADE_SIZE_USD` caps editable trade size (default $100). Buy sizing accounts for fees so a fill cannot make paper cash negative; an undersized ask is skipped rather than partially filled.

Paper fills include taker fees and simulated slippage. The fee is calculated per fill as:

```text
shares × FEE_RATE × price × (1 - price)
```

`FEE_RATE` defaults to `0.07`; fills also use a randomized 300–600 ms delay (`FILL_DELAY_MIN_MS` and `FILL_DELAY_MAX_MS`). `SLIPPAGE_BPS` controls simulated adverse slippage. Settlement is not charged a taker fee. **Verify the current fee model at [docs.polymarket.com/trading/fees](https://docs.polymarket.com/trading/fees)** before using the simulator to model costs.

## Run

```bash
npm install
copy .env.example .env
npm run build
npm start
```

Production serves the website, API, and SSE endpoint from one port (`PORT`, default `3001`). `npm run dev` starts the server and Vite client separately. `npm test` runs offline tests; persistence tests direct all reads and writes to a temporary directory rather than the real `data` folder.

The website, API, reset endpoints, and SSE stream use HTTP Basic Auth. Set `DASH_USER` and `DASH_PASSWORD` in `.env`. In production (`NODE_ENV=production`), the server refuses to start unless `DASH_PASSWORD` is set:

```env
DASH_USER=admin
DASH_PASSWORD=use-a-long-random-password
PORT=3001
FEE_RATE=0.07
SLIPPAGE_BPS=50
FILL_DELAY_MIN_MS=300
FILL_DELAY_MAX_MS=600
MAX_TRADE_SIZE_USD=25
```

Mine's editable rules apply only to new entries. CSV export and reset are available for the single paper account.

## BTC reference price

The display-only BTC reference uses Polymarket's `crypto_prices_chainlink` live-data WebSocket (`btc/usd`) when its timestamp is within five seconds. Stale or unavailable stream data falls back to Coinbase BTC-USD, then Kraken XBT/USD. The source appears beside the current price; none of these prices affect paper trading decisions.

## Price recorder

The optional price recorder watches the same active market snapshot as the paper account and writes one NDJSON quote line per second, plus a result line after Gamma reports the settled winner. Hourly market records include `"marketType":"1h"`; old 15-minute records remain distinguishable and are not rewritten. Files are organized by UTC hour in `data/prices` by default; completed hours are gzip-compressed. It never places orders or changes account state.

```env
PRICE_RECORDING=true
PRICES_DIR=data/prices
MAX_PRICES_MB=500
FEE_RATE=0.07
ENTRY_TRIGGER_PRICE=0.93
TRADE_SIZE_USD=100
STOP_LOSS_USD=10
MAX_TRADE_SIZE_USD=100
SLIPPAGE_BPS=50
FILL_DELAY_MIN_MS=300
FILL_DELAY_MAX_MS=600
```

Set `PRICE_RECORDING=false` to disable recording. `PRICES_DIR` selects the output folder, and recording stops if its files exceed `MAX_PRICES_MB`. The authenticated `GET /api/recording/status` endpoint reports recorder health and storage usage.
