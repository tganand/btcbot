import { describe, expect, it } from "vitest";
import type { MarketSnapshot } from "./types.js";
import { extractPriceToBeat } from "./marketFeed.js";
import { BtcReferencePrice, parseCoinbaseSpot, parseKrakenSpot, parsePolymarketSpotMessage } from "./referencePrice.js";

const start = 1_800_000_000;
const snapshot = (windowStart: number, priceToBeat?: number, priceToBeatSource?: "polymarket" | "approx" | null): MarketSnapshot => ({
  windowId: "window",
  windowStart,
  windowEnd: windowStart + 3600,
  up: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 },
  down: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 },
  feedHealth: "DISCONNECTED",
  consistent: false,
  feedMessage: "",
  priceToBeat: priceToBeat ?? null,
  priceToBeatSource: priceToBeatSource ?? null
});

const response = (payload: unknown, status = 200): Response =>
  new Response(JSON.stringify(payload), { status, headers: { "Content-Type": "application/json" } });

describe("BTC reference prices", () => {
  it("parses the last Chainlink snapshot point and ignores the earlier history", () => {
    const now = 1_800_000_000_000;
    expect(parsePolymarketSpotMessage(JSON.stringify({
      payload: {
        data: [
          { timestamp: now - 1000, value: 73700 },
          { timestamp: now, value: 73741.455 }
        ]
      }
    }), now)).toEqual({ timestamp: now, price: 73741.455 });
  });

  it("parses only the verified Chainlink BTC/USD update and rejects PING, other symbols, and stale ticks", () => {
    const now = 1_800_000_000_000;
    const tick = { symbol: "btc/usd", timestamp: now, value: 73741.455 };
    expect(parsePolymarketSpotMessage(JSON.stringify({
      topic: "crypto_prices_chainlink", type: "update", payload: tick
    }), now)).toEqual({ timestamp: now, price: 73741.455 });
    expect(parsePolymarketSpotMessage("PING", now)).toBeNull();
    expect(parsePolymarketSpotMessage(JSON.stringify({
      topic: "crypto_prices", type: "update", payload: tick
    }), now)).toBeNull();
    expect(parsePolymarketSpotMessage(JSON.stringify({
      topic: "crypto_prices_chainlink", type: "update", payload: { ...tick, symbol: "eth/usd" }
    }), now)).toBeNull();
    expect(parsePolymarketSpotMessage(JSON.stringify({
      topic: "crypto_prices_chainlink", type: "update", payload: { ...tick, timestamp: now - 5001 }
    }), now)).toBeNull();
  });

  it("selects only explicit Polymarket start prices from metadata or descriptions", () => {
    expect(extractPriceToBeat({
      eventMetadata: '{"price_to_beat":"74,000.25"}'
    })).toBe(74000.25);
    expect(extractPriceToBeat({}, {
      description: "The Bitcoin price to beat is $73,950 at the start of this market."
    })).toBe(73950);
    expect(extractPriceToBeat({ description: "Bitcoin is currently $74,000." })).toBeNull();
  });

  it("uses the first live tick in the active window as an approximate beat when Gamma has none", async () => {
    const now = start * 1000 + 1000;
    const prices = new BtcReferencePrice({
      now: () => now,
      fetcher: async () => response({ price: "74001.50" })
    });
    const values = await prices.refresh(snapshot(start));
    expect(values).toEqual({
      btcPrice: 74001.5,
      btcPriceSource: "coinbase",
      priceToBeat: 74001.5,
      priceToBeatSource: "approx"
    });
  });

  it("keeps an exact Polymarket price-to-beat and falls back to Kraken if Coinbase fails", async () => {
    const prices = new BtcReferencePrice({
      now: () => start * 1000 + 1000,
      fetcher: async (url) => {
        if (url.includes("coinbase")) throw new Error("offline");
        return response({ result: { XXBTZUSD: { c: ["73999.1", "0.01"] } } });
      }
    });
    prices.setWindow(start, 73900, "polymarket");
    const values = await prices.refresh(snapshot(start, 73900, "polymarket"));
    expect(parseCoinbaseSpot({ price: "74000" })).toBe(74000);
    expect(parseKrakenSpot({ result: { XXBTZUSD: { c: ["73999.1", "0.01"] } } })).toBe(73999.1);
    expect(values).toEqual({
      btcPrice: 73999.1,
      btcPriceSource: "kraken",
      priceToBeat: 73900,
      priceToBeatSource: "polymarket"
    });
  });

  it("returns null prices and source when both spot endpoints fail", async () => {
    const prices = new BtcReferencePrice({
      now: () => start * 1000,
      fetcher: async () => { throw new Error("offline"); }
    });
    const values = await prices.refresh(snapshot(start));
    expect(values.btcPrice).toBeNull();
    expect(values.btcPriceSource).toBeNull();
    expect(values.priceToBeat).toBeNull();
    expect(values.priceToBeatSource).toBeNull();
  });
});
