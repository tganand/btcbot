import { describe, expect, it } from "vitest";
import { buildTradesCsv, calculatePortfolioMetrics, deriveRoundTrips, feeForFill, reconcilePaperAccount, stopPrice } from "./math.js";
import { applyLastTrade, applyPriceChange, isLastTradePriceEvent, MessageDeduper } from "./marketFeed.js";
import { parseResolution } from "./settlement.js";
import type { PaperAccount } from "./types.js";
describe("paper math", () => {
  it("calculates taker fees from shares and price at 91c, 99c, and 78c", () => {
    expect(feeForFill(10, 0.91)).toBeCloseTo(0.05733);
    expect(feeForFill(10, 0.99)).toBeCloseTo(0.00693);
    expect(feeForFill(10, 0.78)).toBeCloseTo(0.11928);
  });
  it("uses per-asset best prices instead of changed mirror levels", () => {
    const up = { bids: new Map([["0.54", 100]]), asks: new Map([["0.55", 100]]) };
    const down = { bids: new Map([["0.45", 100]]), asks: new Map([["0.46", 100]]) };
    const upQuote = applyPriceChange(up, { asset_id: "up", price: "0.43", side: "BUY", size: "20", best_bid: "0.54", best_ask: "0.55" });
    const downQuote = applyPriceChange(down, { asset_id: "down", price: "0.57", side: "SELL", size: "20", best_bid: "0.45", best_ask: "0.46" });
    expect(upQuote).toMatchObject({ bid: 0.54, ask: 0.55, bidSize: 100, askSize: 100 });
    expect(downQuote).toMatchObject({ bid: 0.45, ask: 0.46, bidSize: 100, askSize: 100 });
  });
  it("does not promote a changed 0.99 sell level to best ask", () => {
    const levels = { bids: new Map([["0.57", 100]]), asks: new Map([["0.58", 100]]) };
    const quote = applyPriceChange(levels, { asset_id: "up", price: "0.99", side: "SELL", size: "92203", best_bid: "0.57", best_ask: "0.58" });
    expect(quote.ask).toBe(0.58);
    expect(quote.askSize).toBe(100);
  });
  it("does not treat last trade price as a quote", () => {
    const levels = { bids: new Map([["0.54", 100]]), asks: new Map([["0.55", 100]]) };
    expect(isLastTradePriceEvent({ event_type: "last_trade_price", price: "0.99", side: "SELL" })).toBe(true);
    const book = applyLastTrade({ bid: 0.54, ask: 0.55, bidSize: 10, askSize: 10, lastUpdateTs: 1 }, 0.99);
    expect(book).toMatchObject({ bid: 0.54, ask: 0.55, lastTrade: 0.99 });
  });
  it("deduplicates an identical message once", () => {
    const deduper = new MessageDeduper();
    expect(deduper.seen('{"id":1}')).toBe(false);
    expect(deduper.seen('{"id":1}')).toBe(true);
  });
  it("calculates exact stop price", () => expect(stopPrice({ entryPrice: 0.91, shares: 10 / 0.91 } as never, 3)).toBeCloseTo(0.637));
  it("reconciles corrupted state", () => {
    const a: PaperAccount = { startingBalance: 100, cashBalance: 0, totalRealizedPnl: 99, openPosition: null, ledger: [{ id: "1", timestamp: 1, windowId: "w", side: "BUY", outcome: "UP", price: 0.91, shares: 10 / 0.91, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" }], version: 0, reconciliationStatus: "MISMATCH", reconciliationDiff: 0, entriesThisWindow: {}, lastEntryExitByOutcome: {} };
    reconcilePaperAccount(a); expect(a.cashBalance).toBe(90); expect(a.totalRealizedPnl).toBe(0); expect(a.reconciliationStatus).toBe("RECONCILED");
  });
  it("reconciles an open position with realized PnL from closed trades only", () => {
    const a: PaperAccount = { startingBalance: 100, cashBalance: 0, totalRealizedPnl: 0, openPosition: null, ledger: [
      { id: "b1", timestamp: 1, windowId: "w", side: "BUY", outcome: "DOWN", price: 0.93465, shares: 10.699, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" },
      { id: "s1", timestamp: 2, windowId: "w", side: "SELL", outcome: "DOWN", price: 1, shares: 10.699, usd: 10.699, fee: 0, slippage: 0, reason: "SETTLEMENT" },
      { id: "b2", timestamp: 3, windowId: "w2", side: "BUY", outcome: "DOWN", price: 0.97485, shares: 10.258, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" }
    ], version: 0, reconciliationStatus: "MISMATCH", reconciliationDiff: 10, entriesThisWindow: {}, lastEntryExitByOutcome: {} };
    reconcilePaperAccount(a);
    expect(a.cashBalance).toBeCloseTo(90.699);
    expect(a.totalRealizedPnl).toBeCloseTo(0.699);
    expect(a.reconciliationStatus).toBe("RECONCILED");
  });
  it("reconciles cash and closed-round-trip PnL net of fees", () => {
    const a: PaperAccount = { startingBalance: 100, cashBalance: 0, totalRealizedPnl: 0, openPosition: null, ledger: [
      { id: "b", timestamp: 1, windowId: "fee-w", side: "BUY", outcome: "UP", price: .9, shares: 10, usd: 9, fee: .063, slippage: 0, reason: "ENTRY" },
      { id: "s", timestamp: 2, windowId: "fee-w", side: "SELL", outcome: "UP", price: 1, shares: 10, usd: 10, fee: .007, slippage: 0, reason: "TAKE_PROFIT" },
      { id: "open", timestamp: 3, windowId: "next", side: "BUY", outcome: "UP", price: .9, shares: 10, usd: 9, fee: .063, slippage: 0, reason: "ENTRY" }
    ], version: 0, reconciliationStatus: "MISMATCH", reconciliationDiff: 0, entriesThisWindow: {}, lastEntryExitByOutcome: {} };
    reconcilePaperAccount(a);
    expect(a.cashBalance).toBeCloseTo(91.867);
    expect(a.totalRealizedPnl).toBeCloseTo(0.93);
  });
  it("reconciles a losing settlement at zero", () => {
    const a: PaperAccount = { startingBalance: 100, cashBalance: 0, totalRealizedPnl: 0, openPosition: null, ledger: [
      { id: "b", timestamp: 1, windowId: "w", side: "BUY", outcome: "DOWN", price: 0.93465, shares: 10.699, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" },
      { id: "s", timestamp: 2, windowId: "w", side: "SELL", outcome: "DOWN", price: 0, shares: 10.699, usd: 0, fee: 0, slippage: 0, reason: "SETTLEMENT" },
      { id: "b2", timestamp: 3, windowId: "w2", side: "BUY", outcome: "DOWN", price: 0.97485, shares: 10.258, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" }
    ], version: 0, reconciliationStatus: "MISMATCH", reconciliationDiff: 10, entriesThisWindow: {}, lastEntryExitByOutcome: {} };
    reconcilePaperAccount(a);
    expect(a.cashBalance).toBe(80);
    expect(a.totalRealizedPnl).toBe(-10);
  });
  it("derives completed trades", () => expect(deriveRoundTrips([{ id: "b", timestamp: 1, windowId: "w", side: "BUY", outcome: "UP", price: .9, shares: 10, usd: 9, fee: 0, slippage: 0, reason: "ENTRY" }, { id: "s", timestamp: 2, windowId: "w", side: "SELL", outcome: "UP", price: 1, shares: 10, usd: 10, fee: 0, slippage: 0, reason: "TAKE_PROFIT" }]).length).toBe(1));
  it("calculates break-even win rate from net round trips", () => {
    const account: PaperAccount = { startingBalance: 100, cashBalance: 101, totalRealizedPnl: 1, openPosition: null, version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0, entriesThisWindow: {}, lastEntryExitByOutcome: {}, ledger: [
      { id: "b1", timestamp: 1, windowId: "w1", side: "BUY", outcome: "UP", price: 0.8, shares: 10, usd: 8, fee: 0, slippage: 0, reason: "ENTRY" },
      { id: "s1", timestamp: 2, windowId: "w1", side: "SELL", outcome: "UP", price: 1, shares: 10, usd: 10, fee: 0, slippage: 0, reason: "TAKE_PROFIT" },
      { id: "b2", timestamp: 3, windowId: "w2", side: "BUY", outcome: "DOWN", price: 0.9, shares: 10, usd: 9, fee: 0, slippage: 0, reason: "ENTRY" },
      { id: "s2", timestamp: 4, windowId: "w2", side: "SELL", outcome: "DOWN", price: 0.8, shares: 10, usd: 8, fee: 0, slippage: 0, reason: "STOP_LOSS" }
    ] };
    expect(calculatePortfolioMetrics(account, { windowId: "", windowStart: 0, windowEnd: 0, up: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, down: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, feedHealth: "DISCONNECTED", consistent: false, feedMessage: "" }).breakEvenWinRate).toBeCloseTo(1 / 3);
  });
  it("escapes CSV fields containing quotes, commas, and newlines", () => {
    const csv = buildTradesCsv([
      { id: "b", timestamp: 1, windowId: 'w,"one\nline', side: "BUY", outcome: "UP", price: .9, shares: 10, usd: 9, fee: .06, slippage: 0, reason: "ENTRY" },
      { id: "s", timestamp: 2, windowId: 'w,"one\nline', side: "SELL", outcome: "UP", price: 1, shares: 10, usd: 10, fee: .01, slippage: 0, reason: "TAKE_PROFIT" }
    ]);
    expect(csv).toContain('"w,""one\nline"');
    expect(csv.split("\r\n")).toHaveLength(2);
  });
  it("only accepts a closed exact 1/0 Gamma resolution", () => {
    expect(parseResolution([{ markets: [{ closed: true, outcomes: "[\"Up\",\"Down\"]", outcomePrices: "[\"0\",\"1\"]" }] }])).toEqual({ outcome: "DOWN", price: 1 });
    expect(parseResolution([{ markets: [{ closed: false, outcomes: "[\"Up\",\"Down\"]", outcomePrices: "[\"0\",\"1\"]" }] }])).toBeNull();
    expect(parseResolution([{ markets: [{ closed: true, outcomes: "[\"Up\",\"Down\"]", outcomePrices: "[\"0.5\",\"0.5\"]" }] }])).toBeNull();
  });
});
