import { describe, expect, it } from "vitest";
import { defaultAccountRules, validateMineRules } from "./config.js";

describe("paper account rules", () => {
  it("uses the hourly Mine defaults", () => {
    expect(defaultAccountRules("mine")).toMatchObject({ entryMin: 0.93, entryMax: 0.95, target: 0.99, stopLossUsd: 10, tradeSizeUsd: 100, minSecondsRemaining: 90, maxSecondsRemaining: 3600, oneTradePerWindow: true });
  });

  it("accepts valid editable rules and rejects each invalid range", () => {
    const valid = { entryMin: 0.93, entryMax: 0.95, target: 0.99, stopLossUsd: 10, tradeSizeUsd: 100, maxSecondsRemaining: 3600 };
    expect(validateMineRules(valid, 90, 100)).toMatchObject({ rules: valid });
    expect(validateMineRules({ ...valid, entryMin: 0.49 }, 90, 100)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, entryMin: 0.97 }, 90, 100)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, target: 0.95 }, 90, 100)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, stopLossUsd: 101 }, 90, 100)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, tradeSizeUsd: 101 }, 90, 100)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, maxSecondsRemaining: 3601 }, 90, 100)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, maxSecondsRemaining: 90 }, 90, 100)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, stopLossUsd: 100, tradeSizeUsd: 99 }, 90, 100)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, entryMin: Number.NaN }, 90, 100)).toHaveProperty("error");
  });
});
