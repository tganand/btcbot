import { createHash, timingSafeEqual } from "node:crypto";
import type { NextFunction, Request, Response } from "express";

type FailureWindow = { startedAt: number; count: number };

const constantTimeEqual = (left: string, right: string): boolean => {
  const leftDigest = createHash("sha256").update(left).digest();
  const rightDigest = createHash("sha256").update(right).digest();
  return timingSafeEqual(leftDigest, rightDigest);
};

const getCredentials = (header: string | undefined): { user: string; password: string } | null => {
  if (!header?.startsWith("Basic ")) return null;
  try {
    const decoded = Buffer.from(header.slice(6), "base64").toString("utf8");
    const separator = decoded.indexOf(":");
    if (separator < 0) return null;
    return { user: decoded.slice(0, separator), password: decoded.slice(separator + 1) };
  } catch {
    return null;
  }
};

export const createBasicAuth = (user: string, password: string, now = (): number => Date.now()) => {
  const failures = new Map<string, FailureWindow>();
  return (req: Request, res: Response, next: NextFunction): void => {
    const ip = req.ip ?? req.socket.remoteAddress ?? "unknown";
    const current = failures.get(ip);
    const timestamp = now();
    if (current && timestamp - current.startedAt >= 60_000) failures.delete(ip);
    const active = failures.get(ip);
    if (active && active.count >= 10) {
      res.setHeader("Retry-After", "60");
      res.status(429).json({ error: "too many failed login attempts" });
      return;
    }

    const supplied = getCredentials(req.header("authorization"));
    const suppliedUser = supplied?.user ?? "";
    const suppliedPassword = supplied?.password ?? "";
    const userMatches = constantTimeEqual(suppliedUser, user);
    const passwordMatches = constantTimeEqual(suppliedPassword, password);
    const valid = supplied !== null && userMatches && passwordMatches;
    if (!valid) {
      const window = failures.get(ip);
      if (window) window.count += 1;
      else failures.set(ip, { startedAt: timestamp, count: 1 });
      res.setHeader("WWW-Authenticate", 'Basic realm="Paper Terminal"');
      res.status(401).json({ error: "authentication required" });
      return;
    }

    failures.delete(ip);
    next();
  };
};

export const requireProductionPassword = (environment: NodeJS.ProcessEnv = process.env): void => {
  if (environment.NODE_ENV === "production" && !environment.DASH_PASSWORD) {
    throw new Error("DASH_PASSWORD must be set when NODE_ENV=production; refusing to start");
  }
};
