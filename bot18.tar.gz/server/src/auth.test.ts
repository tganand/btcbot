import { describe, expect, it, vi } from "vitest";
import type { Request, Response } from "express";
import { createBasicAuth, requireProductionPassword } from "./auth.js";

const response = () => {
  const headers = new Map<string, string>();
  const result = {
    statusCode: 200,
    body: undefined as unknown,
    setHeader: vi.fn((name: string, value: string) => headers.set(name, value)),
    status: vi.fn(function (this: typeof result, code: number) { result.statusCode = code; return this; }),
    json: vi.fn((body: unknown) => { result.body = body; return result; }),
    headers
  };
  return result as unknown as Response & { statusCode: number; headers: Map<string, string> };
};

const request = (authorization: string | undefined): Request => ({
  ip: "192.0.2.10",
  socket: { remoteAddress: "192.0.2.10" },
  header: (name: string) => name.toLowerCase() === "authorization" ? authorization : undefined
} as unknown as Request);

const basic = (user: string, password: string) => `Basic ${Buffer.from(`${user}:${password}`).toString("base64")}`;

describe("dashboard authentication", () => {
  it("rejects missing and wrong credentials, then accepts correct credentials", () => {
    const middleware = createBasicAuth("dash", "secret");
    const missing = response();
    middleware(request(undefined), missing, vi.fn());
    expect(missing.statusCode).toBe(401);
    const wrong = response();
    middleware(request(basic("dash", "wrong")), wrong, vi.fn());
    expect(wrong.statusCode).toBe(401);
    const correct = response();
    const next = vi.fn();
    middleware(request(basic("dash", "secret")), correct, next);
    expect(next).toHaveBeenCalledOnce();
  });

  it("limits failed logins per IP", () => {
    const middleware = createBasicAuth("dash", "secret");
    for (let attempt = 0; attempt < 10; attempt += 1) {
      const result = response();
      middleware(request(basic("dash", "wrong")), result, vi.fn());
      expect(result.statusCode).toBe(401);
    }
    const limited = response();
    middleware(request(basic("dash", "wrong")), limited, vi.fn());
    expect(limited.statusCode).toBe(429);
  });

  it("requires a password in production", () => {
    expect(() => requireProductionPassword({ NODE_ENV: "production" })).toThrow("DASH_PASSWORD");
    expect(() => requireProductionPassword({ NODE_ENV: "production", DASH_PASSWORD: "secret" })).not.toThrow();
  });
});
