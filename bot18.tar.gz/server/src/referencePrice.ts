import WebSocket from "ws";
import type { MarketSnapshot } from "./types.js";

export type SpotSource = "polymarket" | "coinbase" | "kraken";
export type BeatSource = "polymarket" | "approx";

export interface ReferencePrices {
  btcPrice: number | null;
  btcPriceSource: SpotSource | null;
  priceToBeat: number | null;
  priceToBeatSource: BeatSource | null;
}

type Fetcher = (url: string, init?: RequestInit) => Promise<Response>;

const coinbaseUrl = "https://api.exchange.coinbase.com/products/BTC-USD/ticker";
const krakenUrl = "https://api.kraken.com/0/public/Ticker?pair=XBTUSD";
const polymarketWsUrl = "wss://ws-live-data.polymarket.com";
const CHAINLINK_TOPIC = "crypto_prices_chainlink";
const BTC_SYMBOL = "btc/usd";
const MAX_SPOT_AGE_MS = 5000;

export interface PolymarketSpotTick {
  price: number;
  timestamp: number;
}

const validPrice = (value: unknown): number | null => {
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
};

export const parseCoinbaseSpot = (payload: unknown): number | null => {
  if (!payload || typeof payload !== "object") return null;
  return validPrice((payload as Record<string, unknown>).price);
};

export const parseKrakenSpot = (payload: unknown): number | null => {
  if (!payload || typeof payload !== "object") return null;
  const result = (payload as Record<string, unknown>).result;
  if (!result || typeof result !== "object") return null;
  const ticker = Object.values(result).find((value) => value && typeof value === "object");
  if (!ticker || typeof ticker !== "object") return null;
  const close = (ticker as Record<string, unknown>).c;
  return Array.isArray(close) ? validPrice(close[0]) : null;
};

const websocketMessageText = (raw: unknown): string | null => {
  if (typeof raw === "string") return raw;
  if (Buffer.isBuffer(raw)) return raw.toString("utf8");
  if (raw instanceof ArrayBuffer) return Buffer.from(raw).toString("utf8");
  if (Array.isArray(raw) && raw.every(Buffer.isBuffer)) return Buffer.concat(raw).toString("utf8");
  if (ArrayBuffer.isView(raw)) return Buffer.from(raw.buffer, raw.byteOffset, raw.byteLength).toString("utf8");
  return null;
};

export const parsePolymarketSpotMessage = (raw: unknown, now = Date.now()): PolymarketSpotTick | null => {
  try {
    const text = websocketMessageText(raw);
    if (text === null) return null;
    const parsed: unknown = JSON.parse(text);
    if (!parsed || typeof parsed !== "object") return null;
    const message = parsed as Record<string, unknown>;
    const payload = message.payload;
    if (!payload || typeof payload !== "object") return null;
    const data = payload as Record<string, unknown>;
    let tick: Record<string, unknown> | undefined;
    if (Array.isArray(data.data)) {
      const last = data.data.at(-1);
      if (last && typeof last === "object") tick = last as Record<string, unknown>;
    } else if (
      message.topic === CHAINLINK_TOPIC &&
      message.type === "update" &&
      data.symbol === BTC_SYMBOL
    ) {
      tick = data;
    }
    if (!tick) return null;
    const price = validPrice(tick.value);
    const timestamp = typeof tick.timestamp === "number" ? tick.timestamp : Number(tick.timestamp);
    if (price === null || !Number.isFinite(timestamp) || now - timestamp > MAX_SPOT_AGE_MS || timestamp - now > MAX_SPOT_AGE_MS) return null;
    return { price, timestamp };
  } catch {
    return null;
  }
};

export class BtcReferencePrice {
  private readonly now: () => number;
  private readonly fetcher: Fetcher;
  private readonly log: (message: string) => void;
  private inFlight = false;
  private lastUnavailableLogAt = 0;
  private windowStart = 0;
  private approxRecordedForWindow = 0;
  private socket: WebSocket | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private started = false;
  private chainlinkTimestamp = 0;
  private values: ReferencePrices = {
    btcPrice: null,
    btcPriceSource: null,
    priceToBeat: null,
    priceToBeatSource: null
  };

  public constructor(options: { now?: () => number; fetcher?: Fetcher; log?: (message: string) => void } = {}) {
    this.now = options.now ?? Date.now;
    this.fetcher = options.fetcher ?? fetch;
    this.log = options.log ?? console.warn;
  }

  public start(): void {
    if (this.started) return;
    this.started = true;
    this.connectPolymarket();
  }

  public setWindow(windowStart: number, priceToBeat?: number | null, source?: BeatSource | null): void {
    if (windowStart !== this.windowStart) {
      this.windowStart = windowStart;
      this.approxRecordedForWindow = 0;
      this.values.priceToBeat = null;
      this.values.priceToBeatSource = null;
    }
    if (source === "polymarket" && validPrice(priceToBeat) !== null) {
      this.values.priceToBeat = priceToBeat!;
      this.values.priceToBeatSource = "polymarket";
      this.approxRecordedForWindow = windowStart;
    }
  }

  public getValues(): ReferencePrices {
    return { ...this.values };
  }

  public attach(snapshot: MarketSnapshot): MarketSnapshot {
    return { ...snapshot, ...this.values };
  }

  public async refresh(snapshot: MarketSnapshot): Promise<ReferencePrices> {
    try {
      this.setWindow(snapshot.windowStart, snapshot.priceToBeat, snapshot.priceToBeatSource);
    } catch (error) {
      try { this.log(`[reference] window update failed: ${error instanceof Error ? error.message : String(error)}`); } catch { /* display-only failure */ }
    }
    if (this.inFlight) return this.getValues();
    this.inFlight = true;
    try {
      const requestStartedAt = this.now();
      if (this.hasFreshChainlink(requestStartedAt)) return this.getValues();
      if (this.values.btcPriceSource === "polymarket") {
        this.values.btcPrice = null;
        this.values.btcPriceSource = null;
      }
      let price: number | null;
      let source: SpotSource | null;
      try {
        price = await this.fetchSpot(coinbaseUrl, parseCoinbaseSpot);
        if (price === null) throw new Error("invalid Coinbase ticker");
        source = "coinbase";
      } catch {
        try {
          price = await this.fetchSpot(krakenUrl, parseKrakenSpot);
          source = price === null ? null : "kraken";
        } catch {
          price = null;
          source = null;
        }
      }
      const now = this.now();
      if (this.hasFreshChainlink(now)) return this.getValues();
      this.values.btcPrice = price;
      this.values.btcPriceSource = source;
      if (price === null && now - this.lastUnavailableLogAt >= 60_000) {
        this.lastUnavailableLogAt = now;
        try { this.log("[reference] BTC spot unavailable from Coinbase and Kraken"); } catch { /* display-only failure */ }
      }
      if (price !== null) this.setSpot(price, source ?? "coinbase", now);
      return this.getValues();
    } catch (error) {
      this.values.btcPrice = null;
      this.values.btcPriceSource = null;
      try { this.log(`[reference] BTC price unavailable: ${error instanceof Error ? error.message : String(error)}`); } catch { /* display-only failure */ }
      return this.getValues();
    } finally {
      this.inFlight = false;
    }
  }

  private async fetchSpot(url: string, parse: (payload: unknown) => number | null): Promise<number | null> {
    const response = await this.fetcher(url, { signal: AbortSignal.timeout(2500) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return parse(await response.json());
  }

  private hasFreshChainlink(now: number): boolean {
    return this.values.btcPriceSource === "polymarket" &&
      this.chainlinkTimestamp > 0 &&
      now - this.chainlinkTimestamp <= MAX_SPOT_AGE_MS &&
      this.chainlinkTimestamp - now <= MAX_SPOT_AGE_MS;
  }

  private connectPolymarket(): void {
    try {
      const socket = new WebSocket(polymarketWsUrl);
      this.socket = socket;
      socket.on("open", () => {
        try {
          socket.send(JSON.stringify({
            action: "subscribe",
            subscriptions: [{ topic: CHAINLINK_TOPIC, type: "*" }]
          }));
        } catch {
          this.safeLog("[reference] Polymarket BTC subscribe failed");
        }
      });
      socket.on("message", (raw) => {
        try {
          const tick = parsePolymarketSpotMessage(raw, this.now());
          if (!tick) return;
          this.chainlinkTimestamp = tick.timestamp;
          this.setSpot(tick.price, "polymarket", tick.timestamp);
        } catch {
          this.safeLog("[reference] Polymarket BTC message failed");
        }
      });
      socket.on("error", () => {
        try { socket.close(); } catch { this.scheduleReconnect(); }
      });
      socket.on("close", () => {
        if (this.socket === socket) this.socket = null;
        this.scheduleReconnect();
      });
    } catch {
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect(): void {
    if (!this.started || this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connectPolymarket();
    }, 5000);
  }

  private setSpot(price: number, source: SpotSource, timestamp: number): void {
    this.values.btcPrice = price;
    this.values.btcPriceSource = source;
    if (
      this.windowStart > 0 &&
      timestamp >= this.windowStart * 1000 &&
      timestamp < (this.windowStart + 3600) * 1000 &&
      this.approxRecordedForWindow !== this.windowStart &&
      this.values.priceToBeatSource !== "polymarket"
    ) {
      this.values.priceToBeat = price;
      this.values.priceToBeatSource = "approx";
      this.approxRecordedForWindow = this.windowStart;
    }
  }

  private safeLog(message: string): void {
    try { this.log(message); } catch { /* logging must not affect display updates */ }
  }
}
