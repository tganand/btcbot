import { mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { gunzipSync } from "node:zlib";
import { afterEach, describe, expect, it } from "vitest";
import type { MarketSnapshot, Outcome } from "./types.js";
import { PriceRecorder } from "./priceRecorder.js";

const directories: string[] = [];
const createDirectory = async (): Promise<string> => {
  const directory = await mkdtemp(join(tmpdir(), "paper-price-recorder-"));
  directories.push(directory);
  return directory;
};

afterEach(async () => {
  await Promise.all(directories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});

const makeSnapshot = (now: number, slug = "bitcoin-up-or-down-november-10-2026-2am-et"): MarketSnapshot => ({
  windowId: slug,
  windowSlug: slug,
  windowStart: 1794225600,
  windowEnd: 1794226500,
  windowTitle: "BTC Up or Down",
  serverNow: now,
  up: { bid: 0.41, ask: 0.43, bidSize: 12, askSize: 15, lastUpdateTs: now },
  down: { bid: 0.57, ask: 0.59, bidSize: 9, askSize: 13, lastUpdateTs: now },
  feedHealth: "LIVE",
  consistent: true,
  feedMessage: ""
});

const makeRecorder = (directory: string, clock: { value: number }, resolveWindow: (start: number) => Promise<{ outcome: Outcome; price: number } | null> = async () => null, options: { maxBytes?: number; enabled?: boolean; logs?: string[] } = {}) =>
  new PriceRecorder({
    directory,
    now: () => clock.value,
    resolveWindow,
    maxBytes: options.maxBytes,
    enabled: options.enabled,
    log: (message) => options.logs?.push(message)
  });

describe("PriceRecorder", () => {
  it("writes the requested once-per-second JSON line shape", async () => {
    const directory = await createDirectory();
    const clock = { value: Date.UTC(2026, 10, 9, 18, 7, 0) };
    const recorder = makeRecorder(directory, clock);
    await recorder.start();
    const snapshot = makeSnapshot(clock.value);
    snapshot.btcPrice = 74001.25;
    snapshot.priceToBeat = 73950;
    recorder.tick(snapshot);
    recorder.tick(snapshot);
    await recorder.flush();

    const status = await recorder.getStatus();
    expect(status.filesCount).toBe(1);
    expect(status.linesToday).toBe(1);
    const file = await readFile(join(directory, status.currentFile!), "utf8");
    const row = JSON.parse(file.trim()) as Record<string, unknown>;
    expect(row).toEqual({
      ts: clock.value,
      marketType: "1h",
      windowSlug: snapshot.windowSlug,
      btc: 74001.25,
      priceToBeat: 73950,
      secondsRemaining: Math.max(0, snapshot.windowEnd - clock.value / 1000),
      feedHealth: "LIVE",
      up: { bid: 0.41, ask: 0.43, bidSize: 12, askSize: 15 },
      down: { bid: 0.57, ask: 0.59, bidSize: 9, askSize: 13 }
    });
  });

  it("compresses the prior hour on rollover and retains the current hour as plain NDJSON", async () => {
    const directory = await createDirectory();
    const clock = { value: Date.UTC(2026, 10, 9, 12, 59, 59) };
    const recorder = makeRecorder(directory, clock);
    await recorder.start();
    recorder.tick(makeSnapshot(clock.value));
    await recorder.flush();
    clock.value += 1000;
    recorder.tick(makeSnapshot(clock.value));
    await recorder.flush();

    const files = await readdir(directory);
    const oldGzip = files.find((file) => file === "2026-11-09-12.ndjson.gz");
    expect(oldGzip).toBeDefined();
    expect(files).not.toContain("2026-11-09-12.ndjson");
    expect(files).toContain("2026-11-09-13.ndjson");
    expect(gunzipSync(await readFile(join(directory, oldGzip!))).toString("utf8").trim()).toContain('"windowSlug"');
  });

  it("compresses leftover plain files from earlier hours at startup", async () => {
    const directory = await createDirectory();
    const oldName = "2026-11-09-11.ndjson";
    await writeFile(join(directory, oldName), '{"ts":1}\n', "utf8");
    const clock = { value: Date.UTC(2026, 10, 9, 12, 0, 0) };
    const recorder = makeRecorder(directory, clock);
    await recorder.start();

    const files = await readdir(directory);
    expect(files).toContain(`${oldName}.gz`);
    expect(files).not.toContain(oldName);
    expect(gunzipSync(await readFile(join(directory, `${oldName}.gz`))).toString("utf8")).toBe('{"ts":1}\n');
  });

  it("leaves existing compressed history untouched", async () => {
    const directory = await createDirectory();
    const oldGzip = join(directory, "2026-11-08-11.ndjson.gz");
    const original = Buffer.from("preserve old 15-minute archive");
    await writeFile(oldGzip, original);
    const clock = { value: Date.UTC(2026, 10, 9, 12, 0, 0) };
    const recorder = makeRecorder(directory, clock);
    await recorder.start();
    expect(await readFile(oldGzip)).toEqual(original);
  });

  it("writes a result line using the existing resolution outcome", async () => {
    const directory = await createDirectory();
    const clock = { value: Date.UTC(2026, 10, 9, 18, 0, 0) };
    const recorder = makeRecorder(directory, clock, async () => ({ outcome: "UP", price: 1 }));
    await recorder.start();
    const snapshot = makeSnapshot(clock.value);
    snapshot.windowEnd = clock.value / 1000 - 1;
    recorder.tick(snapshot);
    await recorder.flush();

    const files = await readdir(directory);
    const content = await readFile(join(directory, files.find((file) => file.endsWith(".ndjson"))!), "utf8");
    expect(content.split("\n").filter(Boolean).map((line) => JSON.parse(line))).toContainEqual({
      type: "result",
      marketType: "1h",
      windowSlug: snapshot.windowSlug,
      winner: "UP",
      ts: clock.value,
      btc: null,
      priceToBeat: null
    });
  });

  it("retries unresolved results every 30 seconds and writes null after ten minutes", async () => {
    const directory = await createDirectory();
    const clock = { value: Date.UTC(2026, 10, 9, 18, 0, 0) };
    let attempts = 0;
    const recorder = makeRecorder(directory, clock, async () => { attempts += 1; return null; });
    await recorder.start();
    const snapshot = makeSnapshot(clock.value);
    snapshot.windowEnd = clock.value / 1000 - 1;
    for (let elapsed = 0; elapsed <= 10 * 60_000; elapsed += 30_000) {
      clock.value = Date.UTC(2026, 10, 9, 18, 0, 0) + elapsed;
      recorder.tick(snapshot);
      await recorder.flush();
    }

    const files = await readdir(directory);
    const content = await readFile(join(directory, files.find((file) => file.endsWith(".ndjson"))!), "utf8");
    const rows = content.split("\n").filter(Boolean).map((line) => JSON.parse(line));
    expect(attempts).toBe(20);
    expect(rows).toContainEqual({
      type: "result",
      marketType: "1h",
      windowSlug: snapshot.windowSlug,
      winner: null,
      ts: Date.UTC(2026, 10, 9, 18, 10, 0),
      btc: null,
      priceToBeat: null
    });
  });

  it("stops recording when the size limit would be exceeded", async () => {
    const directory = await createDirectory();
    const clock = { value: Date.UTC(2026, 10, 9, 18, 0, 0) };
    const logs: string[] = [];
    const recorder = makeRecorder(directory, clock, undefined, { maxBytes: 10, logs });
    await recorder.start();
    recorder.tick(makeSnapshot(clock.value));
    await recorder.flush();

    const status = await recorder.getStatus();
    expect(status.enabled).toBe(false);
    expect(status.totalBytes).toBe(0);
    expect(logs).toContain("[recorder] size limit reached failed");
  });

  it("contains a write error and allows the caller to continue", async () => {
    const root = await createDirectory();
    const notDirectory = join(root, "file");
    await writeFile(notDirectory, "not a directory");
    const clock = { value: Date.UTC(2026, 10, 9, 18, 0, 0) };
    const logs: string[] = [];
    const recorder = makeRecorder(notDirectory, clock, undefined, { logs });
    await expect(recorder.start()).resolves.toBeUndefined();
    expect(() => recorder.tick(makeSnapshot(clock.value))).not.toThrow();
    await expect(recorder.flush()).resolves.toBeUndefined();
    expect(logs.some((message) => message.startsWith("[recorder]"))).toBe(true);
  });
});
