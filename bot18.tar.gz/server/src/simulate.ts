import { stopPrice } from "./math.js";
const shares = 10 / 0.91;
console.log(JSON.stringify({ shares, stopPrice: stopPrice({ outcome: "UP", windowId: "sim", entryPrice: 0.91, shares, cost: 10, openedAt: Date.now() }, 3) }));
