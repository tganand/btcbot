import { describe, expect, it } from "vitest";
import { buildHourlySlug, hourlyWindowStart, parseDiscoveredMarket } from "./marketFeed.js";

const seconds = (value: string): number => Date.parse(value) / 1000;

describe("hourly market discovery", () => {
  it("builds the requested hourly slugs including noon and midnight", () => {
    expect(buildHourlySlug(seconds("2026-11-10T05:00:00Z"))).toBe("bitcoin-up-or-down-november-10-2026-12am-et");
    expect(buildHourlySlug(seconds("2026-11-10T17:00:00Z"))).toBe("bitcoin-up-or-down-november-10-2026-12pm-et");
    expect(buildHourlySlug(seconds("2026-11-10T07:00:00Z"))).toBe("bitcoin-up-or-down-november-10-2026-2am-et");
  });

  it("uses the current ET hour across daylight-saving changes and midnight rollover", () => {
    const justBeforeEtMidnight = Date.parse("2026-11-11T04:59:59Z");
    const atEtMidnight = Date.parse("2026-11-11T05:00:00Z");
    const before = hourlyWindowStart(justBeforeEtMidnight);
    const after = hourlyWindowStart(atEtMidnight);
    expect(buildHourlySlug(before)).toBe("bitcoin-up-or-down-november-10-2026-11pm-et");
    expect(buildHourlySlug(after)).toBe("bitcoin-up-or-down-november-11-2026-12am-et");
    const springForward = hourlyWindowStart(Date.parse("2026-03-08T07:30:00Z"));
    expect(buildHourlySlug(springForward)).toBe("bitcoin-up-or-down-march-8-2026-3am-et");
    expect(springForward).toBe(seconds("2026-03-08T07:00:00Z"));
  });

  it("parses Gamma outcomes and sets an exact one-hour window", () => {
    const start = seconds("2026-11-10T07:00:00Z");
    const discovered = parseDiscoveredMarket([{
      slug: "bitcoin-up-or-down-november-10-2026-2am-et",
      title: "Bitcoin Up or Down",
      markets: [{ clobTokenIds: '["token-up","token-down"]', outcomes: '["Up","Down"]' }]
    }], start);
    expect(discovered).toMatchObject({
      slug: "bitcoin-up-or-down-november-10-2026-2am-et",
      windowStart: start,
      windowEnd: start + 3600,
      tokens: { UP: "token-up", DOWN: "token-down" }
    });
  });
});
