import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll } from "vitest";

const testDataDir = mkdtempSync(join(tmpdir(), "polymarket-paper-terminal-test-"));
process.env.DATA_DIR = testDataDir;
afterAll(() => rmSync(testDataDir, { recursive: true, force: true }));
