import { describe, expect, it } from "vitest";
import { formatEtWindow } from "./window.js";

describe("Polymarket window labels", () => {
  it("formats an hourly window in Eastern time", () => {
    const start = Date.UTC(2026, 0, 1, 7) / 1000;
    const end = start + 3600;
    expect(formatEtWindow(start, end)).toBe("2:00 AM - 3:00 AM ET");
    expect(end - start).toBe(3600);
  });

  it("waits instead of showing an invalid same-time window", () => {
    expect(formatEtWindow(0, 0)).toBe("Waiting for next window");
    expect(formatEtWindow(100, 100)).toBe("Waiting for next window");
  });
});
