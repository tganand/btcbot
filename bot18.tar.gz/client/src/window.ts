const etClock = new Intl.DateTimeFormat("en-US", {
  hour: "numeric",
  minute: "2-digit",
  hour12: true,
  timeZone: "America/New_York"
});

export const formatEtWindow = (startSeconds: number, endSeconds: number): string => {
  if (!Number.isFinite(startSeconds) || !Number.isFinite(endSeconds) || startSeconds <= 0 || endSeconds <= startSeconds) return "Waiting for next window";
  return `${etClock.format(new Date(startSeconds * 1000))} - ${etClock.format(new Date(endSeconds * 1000))} ET`;
};

export const formatLocalWindow = (startSeconds: number, endSeconds: number): string => {
  if (!Number.isFinite(startSeconds) || !Number.isFinite(endSeconds) || startSeconds <= 0 || endSeconds <= startSeconds) return "";
  const options: Intl.DateTimeFormatOptions = { hour: "numeric", minute: "2-digit" };
  return `${new Date(startSeconds * 1000).toLocaleTimeString([], options)} - ${new Date(endSeconds * 1000).toLocaleTimeString([], options)} local`;
};
