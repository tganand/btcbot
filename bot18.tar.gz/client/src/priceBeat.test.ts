import { describe, expect, it } from "vitest";
import { differenceFromBeat, outcomeDifferenceFromBeat, sourceLabel, winningTradePriceBeatLine } from "./priceBeat.js";

describe("BTC reference display helpers", () => {
  it("calculates directional differences for UP and DOWN outcomes", () => {
    expect(differenceFromBeat(74042, 74000)).toBe(42);
    expect(outcomeDifferenceFromBeat("UP", 74042, 74000)).toBe(42);
    expect(outcomeDifferenceFromBeat("DOWN", 73958, 74000)).toBe(42);
    expect(outcomeDifferenceFromBeat("DOWN", 74042, 74000)).toBe(-42);
  });

  it("shows price-to-beat context on winning trades only", () => {
    expect(winningTradePriceBeatLine("UP", 1.2, 74042, 74000)).toBe("BTC +$42.00 above price to beat at exit");
    expect(winningTradePriceBeatLine("DOWN", 1.2, 73958, 74000)).toBe("BTC +$42.00 below price to beat at exit");
    expect(winningTradePriceBeatLine("UP", -1, 74042, 74000)).toBeNull();
  });

  it("formats absent data sources safely", () => {
    expect(sourceLabel(null)).toBe("--");
    expect(sourceLabel(undefined)).toBe("--");
    expect(sourceLabel("coinbase")).toBe("COINBASE");
  });
});
