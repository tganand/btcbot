export type MarketOutcome = "UP" | "DOWN";

const isFinitePrice = (value: unknown): value is number =>
  typeof value === "number" && Number.isFinite(value);

export const differenceFromBeat = (current: unknown, beat: unknown): number | null =>
  isFinitePrice(current) && isFinitePrice(beat) ? current - beat : null;

export const outcomeDifferenceFromBeat = (outcome: MarketOutcome, current: unknown, beat: unknown): number | null => {
  const difference = differenceFromBeat(current, beat);
  if (difference === null) return null;
  return outcome === "UP" ? difference : -difference;
};

export const sourceLabel = (source: unknown): string =>
  typeof source === "string" && source.length > 0 ? source.toUpperCase() : "--";

export const winningTradePriceBeatLine = (
  outcome: MarketOutcome,
  pnl: number,
  btcAtExit: unknown,
  priceToBeat: unknown
): string | null => {
  if (!Number.isFinite(pnl) || pnl <= 0 || !isFinitePrice(btcAtExit) || !isFinitePrice(priceToBeat)) return null;
  const actualDifference = btcAtExit - priceToBeat;
  const outcomeDifference = outcome === "UP" ? actualDifference : -actualDifference;
  const direction = actualDifference >= 0 ? "above" : "below";
  return `BTC ${outcomeDifference >= 0 ? "+" : "-"}$${Math.abs(actualDifference).toFixed(2)} ${direction} price to beat at exit`;
};
