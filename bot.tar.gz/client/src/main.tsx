import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

type Metrics = { realizedPnl: number; unrealizedPnl: number; equity: number; cash: number; trades: number; wins: number; losses: number; winRate: number; avgWin: number; avgLoss: number; profitFactor: number; maxDrawdown: number; bestTrade: number; worstTrade: number; exitReasons: Record<string, number> };
type State = { account: { cashBalance: number; totalRealizedPnl: number; reconciliationStatus: string; openPosition: unknown; ledger: Array<{ side: string; outcome: string; price: number; usd: number; reason: string }> }; snapshot: { windowId: string; windowStart: number; windowEnd: number; up: { bid: number; ask: number }; down: { bid: number; ask: number }; feedHealth: string; feedMessage: string; consistent: boolean }; metrics: Metrics };
const money = (v: number) => `$${v.toFixed(2)}`;
function App() {
  const [state, setState] = useState<State | null>(null);
  const [connected, setConnected] = useState(false);
  const load = () => fetch("/api/state").then(r => r.json()).then(setState);
  useEffect(() => { void load(); const events = new EventSource("/events"); events.onopen = () => setConnected(true); events.onerror = () => setConnected(false); events.addEventListener("momentum_account_update", e => setState(JSON.parse(e.data))); events.addEventListener("price_tick", e => setState(s => s ? ({ ...s, snapshot: { ...s.snapshot, ...JSON.parse(e.data) } }) : s)); return () => events.close(); }, []);
  if (!state) return <main className="loading">Connecting to paper terminal…</main>;
  const card = (name: string, quote: { bid: number; ask: number }) => <section className="card price"><div className="label">{name}</div><div className="big">{(quote.ask * 100).toFixed(1)}¢</div><div className="sub">Bid {(quote.bid * 100).toFixed(1)}¢ · Ask {(quote.ask * 100).toFixed(1)}¢</div></section>;
  const metrics = [["Equity", money(state.metrics.equity)], ["Cash", money(state.metrics.cash)], ["Realized", money(state.metrics.realizedPnl)], ["Unrealized", money(state.metrics.unrealizedPnl)], ["Win rate", `${(state.metrics.winRate * 100).toFixed(1)}%`], ["Profit factor", state.metrics.profitFactor.toFixed(2)], ["Trades", String(state.metrics.trades)], ["Drawdown", money(state.metrics.maxDrawdown)], ["Wins/Losses", `${state.metrics.wins}/${state.metrics.losses}`]];
  return <main><header><strong>BTC 15M PAPER TERMINAL</strong><span className={connected ? "live" : "offline"}>● {connected ? "LIVE" : "RECONNECTING"}</span><span>Feed: {state.snapshot.feedHealth}</span><span>{state.snapshot.feedMessage}</span><span>Window: {state.snapshot.windowId || "none"}</span></header><div className="hero">{card("UP", state.snapshot.up)}{card("DOWN", state.snapshot.down)}</div><section className="card status"><span>Binary check: {state.snapshot.consistent ? "OK" : "WAITING FOR LIVE BOOK"}</span>{metrics.map(([label, value]) => <span key={label}><small>{label}</small> {value}</span>)}</section><section className="card"><h2>{state.account.openPosition ? "⚡ LIVE TRADE" : "Waiting for a trigger…"}</h2><p>{state.account.openPosition ? "Server-authoritative position active." : state.snapshot.feedMessage}</p></section><footer>Reconciliation: <b>{state.account.reconciliationStatus}</b></footer></main>;
}
createRoot(document.getElementById("root")!).render(<React.StrictMode><App /></React.StrictMode>);
