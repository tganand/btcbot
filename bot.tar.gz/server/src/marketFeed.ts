import WebSocket from "ws";
import type { Book, MarketSnapshot, Outcome } from "./types.js";

interface GammaMarket {
  id?: string;
  conditionId?: string;
  clobTokenIds?: string | string[];
  outcomes?: string | string[];
}

interface GammaEvent {
  id?: string;
  slug?: string;
  markets?: GammaMarket[];
}

interface DiscoveredMarket {
  id: string;
  slug: string;
  windowStart: number;
  windowEnd: number;
  tokens: Record<Outcome, string>;
}

const gammaBaseUrl = "https://gamma-api.polymarket.com/events";
const wsUrl = "wss://ws-subscriptions-clob.polymarket.com/ws/market";
const blankBook = (): Book => ({ bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 });

const parseList = (value: string | string[] | undefined): string[] => {
  if (Array.isArray(value)) return value;
  if (!value) return [];
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
};

const windowStartNow = (): number => Math.floor(Date.now() / 1000 / 900) * 900;

export const discoverMarket = async (windowStart = windowStartNow()): Promise<DiscoveredMarket> => {
  const slug = `btc-updown-15m-${windowStart}`;
  const url = `${gammaBaseUrl}?slug=${encodeURIComponent(slug)}`;
  console.log(`[market] requesting slug=${slug}`);
  console.log(`[market] GET ${url}`);
  const response = await fetch(url);
  console.log(`[market] Gamma response status=${response.status}`);
  if (!response.ok) throw new Error(`Gamma HTTP ${response.status}`);
  const payload: unknown = await response.json();
  const events = Array.isArray(payload) ? payload as GammaEvent[] : [];
  console.log(`[market] events found=${events.length}`);
  const event = events[0];
  const market = event?.markets?.[0];
  if (!market) throw new Error("No active market found");

  const tokenIds = parseList(market.clobTokenIds);
  const outcomes = parseList(market.outcomes);
  console.log(`[market] slug=${slug} markets=${event.markets?.length ?? 0} outcomes=${JSON.stringify(outcomes)} tokenIds=${JSON.stringify(tokenIds)}`);
  const upIndex = outcomes.findIndex((outcome) => outcome.trim().toLowerCase() === "up");
  const downIndex = outcomes.findIndex((outcome) => outcome.trim().toLowerCase() === "down");
  const up = tokenIds[upIndex];
  const down = tokenIds[downIndex];
  if (!up || !down) throw new Error(`Market ${slug} has no parseable Up/Down token ids`);

  const result = {
    id: market.conditionId ?? market.id ?? event.id ?? slug,
    slug,
    windowStart,
    windowEnd: windowStart + 900,
    tokens: { UP: up, DOWN: down }
  };
  console.log(`[market] tokens found slug=${slug} UP=${up} DOWN=${down} window=${result.windowStart}-${result.windowEnd}`);
  return result;
};

export class MarketFeed {
  public snapshot: MarketSnapshot = {
    windowId: "",
    windowStart: 0,
    windowEnd: 0,
    up: blankBook(),
    down: blankBook(),
    feedHealth: "DISCONNECTED",
    consistent: false,
    feedMessage: "No active market found"
  };
  private socket: WebSocket | undefined;
  private market: DiscoveredMarket | undefined;
  private retryTimer: ReturnType<typeof setTimeout> | undefined;
  private rolloverTimer: ReturnType<typeof setInterval> | undefined;
  private loggedMessages = 0;
  private requestedWindow = windowStartNow();

  public constructor(private readonly onChange: (snapshot: MarketSnapshot) => void) {}

  public async connect(windowStart = windowStartNow(), waitingForNextWindow = false): Promise<void> {
    this.requestedWindow = windowStart;
    try {
      this.market = await discoverMarket(windowStart);
      this.loggedMessages = 0;
      this.snapshot = {
        ...this.snapshot,
        windowId: this.market.id,
        windowStart: this.market.windowStart,
        windowEnd: this.market.windowEnd,
        up: blankBook(),
        down: blankBook(),
        feedHealth: "DISCONNECTED",
        feedMessage: "Connecting to CLOB WebSocket"
      };
      this.onChange(this.snapshot);
      this.openSocket();
      this.startRolloverWatcher();
    } catch (error) {
      const cause = error instanceof Error && error.cause instanceof Error ? ` (${error.cause.message})` : "";
      const message = `${error instanceof Error ? error.message : String(error)}${cause}`;
      console.error(`[market] discovery failed slug=btc-updown-15m-${windowStart}: ${message}`);
      this.snapshot = {
        ...this.snapshot,
        feedHealth: "DISCONNECTED",
        feedMessage: waitingForNextWindow ? "Waiting for next window" : message
      };
      this.onChange(this.snapshot);
      this.retryTimer = setTimeout(() => void this.connect(windowStart, waitingForNextWindow), waitingForNextWindow ? 2000 : 3000);
    }
  }

  private startRolloverWatcher(): void {
    if (this.rolloverTimer) clearInterval(this.rolloverTimer);
    this.rolloverTimer = setInterval(() => {
      if (!this.market || Date.now() / 1000 < this.market.windowEnd) return;
      const nextWindow = this.market.windowStart + 900;
      console.log(`[market] window ended; looking up next window W=${nextWindow}`);
      this.socket?.close();
      this.market = undefined;
      if (this.rolloverTimer) clearInterval(this.rolloverTimer);
      void this.connect(nextWindow, true);
    }, 1000);
  }

  private openSocket(): void {
    if (!this.market) return;
    console.log(`[clob] connecting URL=${wsUrl}`);
    this.socket = new WebSocket(wsUrl);
    this.socket.on("open", () => {
      const tokenIds = [this.market!.tokens.UP, this.market!.tokens.DOWN];
      console.log(`[clob] open; subscribing tokenIds=${JSON.stringify(tokenIds)}`);
      this.socket!.send(JSON.stringify({ assets_ids: tokenIds, type: "market" }));
      this.snapshot = { ...this.snapshot, feedHealth: "LIVE", feedMessage: "Live CLOB feed connected" };
      this.onChange(this.snapshot);
    });
    this.socket.on("message", (raw) => {
      const text = raw.toString();
      if (this.loggedMessages < 5) {
        this.loggedMessages += 1;
        console.log(`[clob] message ${this.loggedMessages}/5 bytes=${text.length} payload=${text.slice(0, 1000)}`);
      }
      this.handleMessage(text);
    });
    this.socket.on("error", (error) => {
      console.error(`[clob] error: ${error.message}`);
      this.snapshot = { ...this.snapshot, feedHealth: "DISCONNECTED", feedMessage: `WebSocket error: ${error.message}` };
      this.onChange(this.snapshot);
    });
    this.socket.on("close", (code, reason) => {
      console.warn(`[clob] close code=${code} reason=${reason.toString()}`);
      if (this.market) {
        this.snapshot = { ...this.snapshot, feedHealth: "DISCONNECTED", feedMessage: "WebSocket closed; retrying" };
        this.onChange(this.snapshot);
        this.retryTimer = setTimeout(() => void this.connect(this.requestedWindow), 2000);
      }
    });
  }

  private handleMessage(raw: string): void {
    let payload: unknown;
    try { payload = JSON.parse(raw); } catch { return; }
    const messages = Array.isArray(payload) ? payload : [payload];
    for (const item of messages) {
      if (!item || typeof item !== "object") continue;
      const message = item as Record<string, unknown>;
      if (Array.isArray(message.price_changes)) {
        for (const change of message.price_changes) if (change && typeof change === "object") this.handleMessage(JSON.stringify(change));
        continue;
      }
      const asset = String(message.asset_id ?? message.assetId ?? "");
      const outcome: Outcome | undefined = this.market && asset === this.market.tokens.UP ? "UP" : this.market && asset === this.market.tokens.DOWN ? "DOWN" : undefined;
      if (!outcome) continue;
      const book = { ...(outcome === "UP" ? this.snapshot.up : this.snapshot.down) };
      const bids = Array.isArray(message.bids) ? message.bids : [];
      const asks = Array.isArray(message.asks) ? message.asks : [];
      if (bids.length) { const best = bids.map((entry) => entry as Record<string, unknown>).sort((a, b) => Number(b.price) - Number(a.price))[0]!; book.bid = Number(best.price); book.bidSize = Number(best.size); }
      if (asks.length) { const best = asks.map((entry) => entry as Record<string, unknown>).sort((a, b) => Number(a.price) - Number(b.price))[0]!; book.ask = Number(best.price); book.askSize = Number(best.size); }
      if (message.best_bid !== undefined) book.bid = Number(message.best_bid);
      if (message.best_ask !== undefined) book.ask = Number(message.best_ask);
      if (message.price && message.side === "BUY") book.bid = Number(message.price);
      if (message.price && message.side === "SELL") book.ask = Number(message.price);
      book.lastUpdateTs = Date.now();
      const upMid = (this.snapshot.up.bid + this.snapshot.up.ask) / 2;
      const downMid = (this.snapshot.down.bid + this.snapshot.down.ask) / 2;
      this.snapshot = { ...this.snapshot, ...(outcome === "UP" ? { up: book } : { down: book }), consistent: upMid > 0 && downMid > 0 && Math.abs(upMid + downMid - 1) <= 0.03, feedHealth: "LIVE", feedMessage: "Live prices flowing" };
      this.onChange(this.snapshot);
    }
  }
}
