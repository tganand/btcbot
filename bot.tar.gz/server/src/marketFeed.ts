import WebSocket from "ws";
import type { Book, MarketSnapshot, Outcome } from "./types.js";

interface GammaMarket {
  id?: string;
  conditionId?: string;
  clobTokenIds?: string | string[];
  outcomes?: string | string[];
}

interface GammaEvent {
  id?: string;
  slug?: string;
  markets?: GammaMarket[];
}

interface DiscoveredMarket {
  id: string;
  slug: string;
  windowStart: number;
  windowEnd: number;
  tokens: Record<Outcome, string>;
}

interface PriceLevel {
  price: number;
  size: number;
}

const gammaBaseUrl = "https://gamma-api.polymarket.com/events";
const wsUrl = "wss://ws-subscriptions-clob.polymarket.com/ws/market";
const blankBook = (): Book => ({ bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 });

const parseList = (value: string | string[] | undefined): string[] => {
  if (Array.isArray(value)) return value;
  if (!value) return [];
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
};

const windowStartNow = (): number => Math.floor(Date.now() / 1000 / 900) * 900;

export const discoverMarket = async (windowStart = windowStartNow()): Promise<DiscoveredMarket> => {
  const slug = `btc-updown-15m-${windowStart}`;
  const url = `${gammaBaseUrl}?slug=${encodeURIComponent(slug)}`;
  console.log(`[market] requesting slug=${slug}`);
  console.log(`[market] GET ${url}`);
  const response = await fetch(url);
  console.log(`[market] Gamma response status=${response.status}`);
  if (!response.ok) throw new Error(`Gamma HTTP ${response.status}`);
  const payload: unknown = await response.json();
  const events = Array.isArray(payload) ? payload as GammaEvent[] : [];
  console.log(`[market] events found=${events.length}`);
  const event = events[0];
  const market = event?.markets?.[0];
  if (!market) throw new Error("No active market found");

  const tokenIds = parseList(market.clobTokenIds);
  const outcomes = parseList(market.outcomes);
  console.log(`[market] slug=${slug} markets=${event.markets?.length ?? 0} outcomes=${JSON.stringify(outcomes)} tokenIds=${JSON.stringify(tokenIds)}`);
  const upIndex = outcomes.findIndex((outcome) => outcome.trim().toLowerCase() === "up");
  const downIndex = outcomes.findIndex((outcome) => outcome.trim().toLowerCase() === "down");
  const up = tokenIds[upIndex];
  const down = tokenIds[downIndex];
  if (!up || !down) throw new Error(`Market ${slug} has no parseable Up/Down token ids`);

  const result = {
    id: market.conditionId ?? market.id ?? event.id ?? slug,
    slug,
    windowStart,
    windowEnd: windowStart + 900,
    tokens: { UP: up, DOWN: down }
  };
  console.log(`[market] tokens found slug=${slug} UP=${up} DOWN=${down} window=${result.windowStart}-${result.windowEnd}`);
  return result;
};

export class MarketFeed {
  public snapshot: MarketSnapshot = {
    windowId: "",
    windowStart: 0,
    windowEnd: 0,
    up: blankBook(),
    down: blankBook(),
    feedHealth: "DISCONNECTED",
    consistent: false,
    feedMessage: "No active market found"
  };
  private socket: WebSocket | undefined;
  private market: DiscoveredMarket | undefined;
  private retryTimer: ReturnType<typeof setTimeout> | undefined;
  private rolloverTimer: ReturnType<typeof setInterval> | undefined;
  private loggedMessages = 0;
  private loggedBookTokens = new Set<string>();
  private levels = new Map<string, { bids: Map<string, number>; asks: Map<string, number> }>();
  private requestedWindow = windowStartNow();

  public constructor(private readonly onChange: (snapshot: MarketSnapshot) => void) {}

  public async connect(windowStart = windowStartNow(), waitingForNextWindow = false): Promise<void> {
    this.requestedWindow = windowStart;
    try {
      this.market = await discoverMarket(windowStart);
      this.loggedMessages = 0;
      this.loggedBookTokens.clear();
      this.levels = new Map([
        [this.market.tokens.UP, { bids: new Map(), asks: new Map() }],
        [this.market.tokens.DOWN, { bids: new Map(), asks: new Map() }]
      ]);
      this.snapshot = {
        ...this.snapshot,
        windowId: this.market.id,
        windowStart: this.market.windowStart,
        windowEnd: this.market.windowEnd,
        up: blankBook(),
        down: blankBook(),
        feedHealth: "DISCONNECTED",
        feedMessage: "Connecting to CLOB WebSocket"
      };
      this.onChange(this.snapshot);
      this.openSocket();
      void this.compareRestBooks();
      this.startRolloverWatcher();
    } catch (error) {
      const cause = error instanceof Error && error.cause instanceof Error ? ` (${error.cause.message})` : "";
      const message = `${error instanceof Error ? error.message : String(error)}${cause}`;
      console.error(`[market] discovery failed slug=btc-updown-15m-${windowStart}: ${message}`);
      this.snapshot = {
        ...this.snapshot,
        feedHealth: "DISCONNECTED",
        feedMessage: waitingForNextWindow ? "Waiting for next window" : message
      };
      this.onChange(this.snapshot);
      this.retryTimer = setTimeout(() => void this.connect(windowStart, waitingForNextWindow), waitingForNextWindow ? 2000 : 3000);
    }
  }

  private startRolloverWatcher(): void {
    if (this.rolloverTimer) clearInterval(this.rolloverTimer);
    this.rolloverTimer = setInterval(() => {
      if (!this.market || Date.now() / 1000 < this.market.windowEnd) return;
      const nextWindow = this.market.windowStart + 900;
      console.log(`[market] window ended; looking up next window W=${nextWindow}`);
      this.socket?.close();
      this.market = undefined;
      if (this.rolloverTimer) clearInterval(this.rolloverTimer);
      void this.connect(nextWindow, true);
    }, 1000);
  }

  private openSocket(): void {
    if (!this.market) return;
    console.log(`[clob] connecting URL=${wsUrl}`);
    this.socket = new WebSocket(wsUrl);
    this.socket.on("open", () => {
      const tokenIds = [this.market!.tokens.UP, this.market!.tokens.DOWN];
      console.log(`[clob] open; subscribing tokenIds=${JSON.stringify(tokenIds)}`);
      this.socket!.send(JSON.stringify({ assets_ids: tokenIds, type: "market" }));
      this.snapshot = { ...this.snapshot, feedHealth: "LIVE", feedMessage: "Live CLOB feed connected" };
      this.onChange(this.snapshot);
    });
    this.socket.on("message", (raw) => {
      const text = raw.toString();
      if (this.loggedMessages < 5) {
        this.loggedMessages += 1;
        console.log(`[clob] message ${this.loggedMessages}/5 bytes=${text.length} payload=${text.slice(0, 1000)}`);
      }
      this.handleMessage(text);
    });
    this.socket.on("error", (error) => {
      console.error(`[clob] error: ${error.message}`);
      this.snapshot = { ...this.snapshot, feedHealth: "DISCONNECTED", feedMessage: `WebSocket error: ${error.message}` };
      this.onChange(this.snapshot);
    });
    this.socket.on("close", (code, reason) => {
      console.warn(`[clob] close code=${code} reason=${reason.toString()}`);
      if (this.market) {
        this.snapshot = { ...this.snapshot, feedHealth: "DISCONNECTED", feedMessage: "WebSocket closed; retrying" };
        this.onChange(this.snapshot);
        this.retryTimer = setTimeout(() => void this.connect(this.requestedWindow), 2000);
      }
    });
  }

  private async compareRestBooks(): Promise<void> {
    if (!this.market) return;
    for (const tokenId of Object.values(this.market.tokens)) {
      const url = `https://clob.polymarket.com/book?token_id=${encodeURIComponent(tokenId)}`;
      try {
        console.log(`[rest-book] GET ${url}`);
        const response = await fetch(url);
        console.log(`[rest-book] token=${tokenId} status=${response.status}`);
        if (!response.ok) {
          console.warn(`[rest-book] token=${tokenId} failed HTTP ${response.status}`);
          continue;
        }
        const raw: unknown = await response.json();
        console.log(`[rest-book] token=${tokenId} ${JSON.stringify(this.summarizeBook(raw))}`);
      } catch (error) {
        console.warn(`[rest-book] token=${tokenId} failed: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
  }

  private summarizeBook(raw: unknown): { bestBid: PriceLevel | null; bestAsk: PriceLevel | null; bids: unknown[]; asks: unknown[] } {
    if (!raw || typeof raw !== "object") return { bestBid: null, bestAsk: null, bids: [], asks: [] };
    const book = raw as Record<string, unknown>;
    const bids = this.normalizeLevels(book.bids);
    const asks = this.normalizeLevels(book.asks);
    return {
      bestBid: this.bestLevel(bids, "bid"),
      bestAsk: this.bestLevel(asks, "ask"),
      bids: bids.slice(0, 10),
      asks: asks.slice(0, 10)
    };
  }

  private normalizeLevels(value: unknown): PriceLevel[] {
    if (!Array.isArray(value)) return [];
    return value.flatMap((entry) => {
      if (!entry || typeof entry !== "object") return [];
      const level = entry as Record<string, unknown>;
      const price = Number(level.price);
      const size = Number(level.size);
      return Number.isFinite(price) && Number.isFinite(size) ? [{ price, size }] : [];
    });
  }

  private bestLevel(levels: PriceLevel[], side: "bid" | "ask"): PriceLevel | null {
    if (!levels.length) return null;
    return levels.reduce((best, level) => side === "bid" ? (level.price > best.price ? level : best) : (level.price < best.price ? level : best));
  }

  private updateLevels(asset: string, side: "BUY" | "SELL", price: number, size: number): void {
    const book = this.levels.get(asset);
    if (!book || !Number.isFinite(price) || !Number.isFinite(size)) return;
    const levels = side === "BUY" ? book.bids : book.asks;
    if (size <= 0) levels.delete(String(price));
    else levels.set(String(price), size);
  }

  private setSnapshotForAsset(outcome: Outcome, asset: string, bestBid?: number, bestAsk?: number): void {
    const bookLevels = this.levels.get(asset);
    if (!bookLevels) return;
    const bids = [...bookLevels.bids.entries()].map(([price, size]) => ({ price: Number(price), size }));
    const asks = [...bookLevels.asks.entries()].map(([price, size]) => ({ price: Number(price), size }));
    const derivedBid = this.bestLevel(bids, "bid");
    const derivedAsk = this.bestLevel(asks, "ask");
    const current = outcome === "UP" ? this.snapshot.up : this.snapshot.down;
    const next = {
      ...current,
      bid: bestBid !== undefined ? bestBid : derivedBid?.price ?? 0,
      bidSize: bestBid !== undefined ? current.bidSize : derivedBid?.size ?? 0,
      ask: bestAsk !== undefined ? bestAsk : derivedAsk?.price ?? 0,
      askSize: bestAsk !== undefined ? current.askSize : derivedAsk?.size ?? 0,
      lastUpdateTs: Date.now()
    };
    const invalid = next.bid > 0 && next.ask > 0 && next.bid >= next.ask;
    const wide = next.bid > 0 && next.ask > 0 && next.ask - next.bid > 0.1;
    if (invalid || wide) {
      console.warn(`[clob] invalid book token=${asset} bid=${next.bid} ask=${next.ask} rawLevels=${JSON.stringify({ bids, asks })}`);
    }
    const up = outcome === "UP" ? next : this.snapshot.up;
    const down = outcome === "DOWN" ? next : this.snapshot.down;
    const upMid = (up.bid + up.ask) / 2;
    const downMid = (down.bid + down.ask) / 2;
    this.snapshot = {
      ...this.snapshot,
      ...(outcome === "UP" ? { up: next } : { down: next }),
      consistent: !invalid && !wide && upMid > 0 && downMid > 0 && Math.abs(upMid + downMid - 1) <= 0.03,
      feedHealth: "LIVE",
      feedMessage: invalid ? "Invalid crossed book; tick blocked" : wide ? "Spread over 10 cents; tick blocked" : "Live prices flowing"
    };
    this.onChange(this.snapshot);
  }

  private handleMessage(raw: string): void {
    let payload: unknown;
    try { payload = JSON.parse(raw); } catch { return; }
    const messages = Array.isArray(payload) ? payload : [payload];
    for (const item of messages) {
      if (!item || typeof item !== "object") continue;
      const message = item as Record<string, unknown>;
      if (Array.isArray(message.price_changes)) {
        for (const change of message.price_changes) if (change && typeof change === "object") this.handleMessage(JSON.stringify(change));
        continue;
      }
      const asset = String(message.asset_id ?? message.assetId ?? "");
      const outcome: Outcome | undefined = this.market && asset === this.market.tokens.UP ? "UP" : this.market && asset === this.market.tokens.DOWN ? "DOWN" : undefined;
      if (!outcome) continue;
      const eventType = String(message.event_type ?? message.type ?? "").toLowerCase();
      if (eventType === "book" || Array.isArray(message.bids) || Array.isArray(message.asks)) {
        const levels = this.levels.get(asset);
        if (!levels) continue;
        levels.bids.clear();
        levels.asks.clear();
        for (const level of this.normalizeLevels(message.bids)) levels.bids.set(String(level.price), level.size);
        for (const level of this.normalizeLevels(message.asks)) levels.asks.set(String(level.price), level.size);
        if (!this.loggedBookTokens.has(asset)) {
          this.loggedBookTokens.add(asset);
          console.log(`[clob] first book token=${asset} raw10=${JSON.stringify({ bids: this.normalizeLevels(message.bids).slice(0, 10), asks: this.normalizeLevels(message.asks).slice(0, 10) })}`);
        }
        this.setSnapshotForAsset(outcome, asset);
      } else if (eventType === "price_change" || message.price !== undefined || message.best_bid !== undefined || message.best_ask !== undefined) {
        const side = String(message.side ?? "").toUpperCase() === "BUY" ? "BUY" : "SELL";
        const price = Number(message.price);
        if (Number.isFinite(price)) this.updateLevels(asset, side, price, Number(message.size ?? 0));
        this.setSnapshotForAsset(outcome, asset, message.best_bid === undefined ? undefined : Number(message.best_bid), message.best_ask === undefined ? undefined : Number(message.best_ask));
      }
    }
  }
}
