import { describe, expect, it } from "vitest";
import { deriveRoundTrips, reconcilePaperAccount, stopPrice } from "./math.js";
import type { PaperAccount } from "./types.js";
describe("paper math", () => {
  it("calculates exact stop price", () => expect(stopPrice({ entryPrice: 0.91, shares: 10 / 0.91 } as never, 3)).toBeCloseTo(0.637));
  it("reconciles corrupted state", () => {
    const a: PaperAccount = { startingBalance: 100, cashBalance: 0, totalRealizedPnl: 99, openPosition: null, ledger: [{ id: "1", timestamp: 1, windowId: "w", side: "BUY", outcome: "UP", price: 0.91, shares: 10 / 0.91, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" }], version: 0, reconciliationStatus: "MISMATCH", reconciliationDiff: 0 };
    reconcilePaperAccount(a); expect(a.cashBalance).toBe(90); expect(a.reconciliationStatus).toBe("MISMATCH");
  });
  it("derives completed trades", () => expect(deriveRoundTrips([{ id: "b", timestamp: 1, windowId: "w", side: "BUY", outcome: "UP", price: .9, shares: 10, usd: 9, fee: 0, slippage: 0, reason: "ENTRY" }, { id: "s", timestamp: 2, windowId: "w", side: "SELL", outcome: "UP", price: 1, shares: 10, usd: 10, fee: 0, slippage: 0, reason: "TAKE_PROFIT" }]).length).toBe(1));
});
