import express from "express";
import cors from "cors";
import { createServer } from "node:http";
import { join } from "node:path";
import { config } from "./config.js";
import { loadAccount, saveAccount, freshAccount } from "./store.js";
import { calculatePortfolioMetrics, reconcilePaperAccount } from "./math.js";
import { MarketFeed } from "./marketFeed.js";
import type { MarketSnapshot, PaperAccount } from "./types.js";

const app = express();
app.use(cors());
app.use(express.json());
const server = createServer(app);
let account: PaperAccount;
let snapshot: MarketSnapshot = { windowId: "", windowStart: 0, windowEnd: 0, up: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, down: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, feedHealth: "DISCONNECTED", consistent: false, feedMessage: "No active market found" };
const clients = new Set<express.Response>();
const broadcast = (type: string, payload: unknown) => { for (const client of clients) client.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`); };
const full = () => ({ account, snapshot, metrics: calculatePortfolioMetrics(account, snapshot) });
app.get("/api/state", (_req, res) => res.json(full()));
app.post("/api/reset", async (req, res) => { if (req.body?.confirm !== true) return res.status(400).json({ error: "confirm=true required" }); account = freshAccount(); reconcilePaperAccount(account); await saveAccount(account); broadcast("momentum_account_update", full()); res.json(full()); });
app.get("/events", (req, res) => { res.setHeader("Content-Type", "text/event-stream"); res.setHeader("Cache-Control", "no-cache"); res.setHeader("Connection", "keep-alive"); res.flushHeaders(); clients.add(res); res.write(`event: momentum_account_update\ndata: ${JSON.stringify(full())}\n\n`); req.on("close", () => clients.delete(res)); });
const clientDist = join(process.cwd(), "client", "dist");
app.use(express.static(clientDist));
app.get("*", (_req, res) => res.sendFile(join(clientDist, "index.html")));
setInterval(() => {
  const stale = snapshot.feedHealth === "LIVE" && (Date.now() - Math.max(snapshot.up.lastUpdateTs, snapshot.down.lastUpdateTs) > 3000);
  if (stale) snapshot = { ...snapshot, feedHealth: "STALE", feedMessage: "WebSocket connected but no price update for 3 seconds" };
  broadcast("price_tick", { up: snapshot.up, down: snapshot.down, feedHealth: snapshot.feedHealth, feedMessage: snapshot.feedMessage, secondsRemaining: Math.max(0, snapshot.windowEnd - Date.now() / 1000), metrics: calculatePortfolioMetrics(account, snapshot) });
}, 500);
setInterval(() => { for (const client of clients) client.write(": keep-alive\n\n"); }, 15000);
const start = async (): Promise<void> => {
  account = await loadAccount();
  reconcilePaperAccount(account);
  await saveAccount(account);
  server.listen(config.port, () => console.log(`Paper terminal server listening on http://localhost:${config.port}`));
  const feed = new MarketFeed((next) => {
    snapshot = next;
    broadcast("price_tick", { up: snapshot.up, down: snapshot.down, feedHealth: snapshot.feedHealth, feedMessage: snapshot.feedMessage, secondsRemaining: Math.max(0, snapshot.windowEnd - Date.now() / 1000), metrics: calculatePortfolioMetrics(account, snapshot) });
  });
  void feed.connect();
};
void start();
