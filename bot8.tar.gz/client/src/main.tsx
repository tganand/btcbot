import React, { Component, useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

type Quote = { bid: number; ask: number; bidSize?: number; askSize?: number };
type Metrics = { realizedPnl: number; unrealizedPnl: number; equity: number; cash: number; trades: number; wins: number; losses: number; winRate: number; avgWin: number; avgLoss: number; profitFactor: number; maxDrawdown: number; bestTrade: number; worstTrade: number; exitReasons?: Record<string, number> };
type EntryStatus = { ask: number; trigger: number; msHeldAboveTrigger: number; secondsRemaining: number; feedHealth: string; consistent: boolean; positionOpen: boolean; askSize: number; decision: string };
type Position = { outcome: "UP" | "DOWN"; entryPrice: number; shares: number; cost: number; windowId: string; openedAt: number };
type Fill = { side: string; outcome: string; price: number; usd: number; reason: string; timestamp?: number };
type State = { circuitBreakerHalted: boolean; account: { cashBalance: number; totalRealizedPnl: number; reconciliationStatus: string; reconciliationDiff: number; openPosition: Position | null; ledger: Fill[] }; snapshot: { windowId: string; windowStart: number; windowEnd: number; up: Quote; down: Quote; feedHealth: string; feedMessage: string; consistent: boolean }; metrics: Metrics; entryStatus: { UP: EntryStatus | null; DOWN: EntryStatus | null } };

const emptyState = (): State => ({ circuitBreakerHalted: false, account: { cashBalance: 100, totalRealizedPnl: 0, reconciliationStatus: "WAITING", reconciliationDiff: 0, openPosition: null, ledger: [] }, snapshot: { windowId: "", windowStart: 0, windowEnd: 0, up: { bid: 0, ask: 0 }, down: { bid: 0, ask: 0 }, feedHealth: "DISCONNECTED", feedMessage: "Connecting...", consistent: false }, metrics: { realizedPnl: 0, unrealizedPnl: 0, equity: 100, cash: 100, trades: 0, wins: 0, losses: 0, winRate: 0, avgWin: 0, avgLoss: 0, profitFactor: 0, maxDrawdown: 0, bestTrade: 0, worstTrade: 0 }, entryStatus: { UP: null, DOWN: null } });
const money = (value: number | undefined) => `$${(value ?? 0).toFixed(2)}`;
const cents = (value: number | undefined) => `${((value ?? 0) * 100).toFixed(1)}¢`;
const secondsLeft = (state: State) => Math.max(0, state.snapshot.windowEnd - Date.now() / 1000);

class ErrorBoundary extends Component<React.PropsWithChildren, { error: Error | null }> {
  public state = { error: null as Error | null };
  public static getDerivedStateFromError(error: Error) { return { error }; }
  public render() {
    if (this.state.error) return <main className="mx-auto min-h-screen max-w-3xl p-6"><section className="panel border-rose-500"><h1 className="text-xl font-bold text-rose-300">Dashboard error</h1><p className="mt-3 whitespace-pre-wrap text-rose-100">{this.state.error.message}</p><p className="mt-4 muted">Reload the page after checking the server logs.</p></section></main>;
    return this.props.children;
  }
}

function App() {
  const [state, setState] = useState<State | null>(null);
  const [error, setError] = useState("");
  const [connected, setConnected] = useState(false);
  const lastEvent = useRef(0);
  const load = async () => {
    const response = await fetch("/api/state", { credentials: "same-origin" });
    if (!response.ok) throw new Error(`Unable to load dashboard state (${response.status})`);
    setState(await response.json() as State);
    setError("");
  };
  useEffect(() => {
    let active = true;
    void load().catch((reason: unknown) => { if (active) setError(reason instanceof Error ? reason.message : String(reason)); });
    const events = new EventSource("/events");
    const apply = (event: MessageEvent<string>) => { if (!active) return; lastEvent.current = Date.now(); setState(previous => { const next = JSON.parse(event.data) as State & { up?: Quote; down?: Quote; feedHealth?: string; feedMessage?: string }; if (event.type === "price_tick" && previous) return { ...previous, metrics: next.metrics, entryStatus: next.entryStatus, snapshot: { ...previous.snapshot, up: next.up ?? previous.snapshot.up, down: next.down ?? previous.snapshot.down, feedHealth: next.feedHealth ?? previous.snapshot.feedHealth, feedMessage: next.feedMessage ?? previous.snapshot.feedMessage } }; return next; }); };
    events.onopen = () => setConnected(true);
    events.onerror = () => setConnected(false);
    events.addEventListener("momentum_account_update", apply as EventListener);
    events.addEventListener("price_tick", apply as EventListener);
    const poll = window.setInterval(() => { if (Date.now() - lastEvent.current >= 3000) void load().catch(() => undefined); }, 1000);
    return () => { active = false; events.close(); window.clearInterval(poll); };
  }, [lastEvent]);
  if (!state) return <main className="grid min-h-screen place-items-center p-6"><section className="panel w-full max-w-lg text-center"><div className="eyebrow">BTC 15M PAPER TERMINAL</div><h1 className="mt-4 text-2xl font-bold">Connecting...</h1><p className="mt-3 muted">{error || "Waiting for /api/state"}</p></section></main>;
  const remaining = secondsLeft(state);
  const metrics = [["Balance", money(state.metrics.cash)], ["Equity", money(state.metrics.equity)], ["Realized PnL", money(state.metrics.realizedPnl)], ["Unrealized PnL", money(state.metrics.unrealizedPnl)], ["Win rate", `${(state.metrics.winRate * 100).toFixed(1)}%`], ["Trades", state.metrics.trades], ["Wins", state.metrics.wins], ["Losses", state.metrics.losses]];
  const quoteCard = (name: "UP" | "DOWN", quote: Quote) => <section className="panel"><div className="flex items-center justify-between"><span className="eyebrow">{name} CONTRACT</span><span className="text-xs text-slate-500">ask size {quote.askSize ?? 0}</span></div><div className="mt-5 text-5xl font-bold">{cents(quote.ask)}</div><div className="mt-2 muted">Bid {cents(quote.bid)} · Ask {cents(quote.ask)}</div></section>;
  const radar = (name: "UP" | "DOWN") => { const item = state.entryStatus[name]; return <div className="rounded-lg border border-slate-800 p-4"><div className="flex justify-between font-bold"><span>{name}</span><span className="text-amber-300">{item?.decision ?? "WAITING"}</span></div><div className="mt-2 grid gap-1 text-sm muted"><span>Ask {cents(item?.ask)} · trigger {cents(item?.trigger)} · size {item?.askSize ?? 0}</span><span>{item?.msHeldAboveTrigger ?? 0}ms held · {item?.secondsRemaining?.toFixed(1) ?? "0.0"}s remaining</span><span>Feed {item?.feedHealth ?? state.snapshot.feedHealth} · consistent {item?.consistent ? "YES" : "NO"}</span></div></div>; };
  const position = state.account.openPosition;
  const range = position ? Math.min(100, Math.max(0, ((state.snapshot[position.outcome.toLowerCase() as "up" | "down"].bid - ((position.cost - 3) / position.shares)) / (0.99 - ((position.cost - 3) / position.shares))) * 100)) : 0;
  const fills = state.account.ledger;
  return <main className="mx-auto min-h-screen max-w-7xl p-4 sm:p-6"><header className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5"><div><div className="eyebrow">BTC 15M PAPER TERMINAL</div><h1 className="mt-2 text-2xl font-bold">Market cockpit</h1></div><div className="flex flex-wrap gap-2 text-xs"><span className={`rounded-full px-3 py-1 ${connected ? "bg-emerald-400/10 text-emerald-300" : "bg-rose-400/10 text-rose-300"}`}>● {connected ? "SSE LIVE" : "SSE RECONNECTING"}</span><span className="rounded-full bg-slate-800 px-3 py-1">FEED {state.snapshot.feedHealth}</span><span className={`rounded-full px-3 py-1 ${state.circuitBreakerHalted ? "bg-rose-400/10 text-rose-300" : "bg-emerald-400/10 text-emerald-300"}`}>{state.circuitBreakerHalted ? "HALTED" : "ENGINE READY"}</span></div></header>
    <section className="mt-6 grid gap-4 lg:grid-cols-2">{quoteCard("UP", state.snapshot.up)}{quoteCard("DOWN", state.snapshot.down)}</section>
    <section className="panel grid gap-4 md:grid-cols-3"><div><div className="eyebrow">Window timer</div><div className="mt-2 text-3xl font-bold">{Math.floor(remaining / 60)}:{Math.floor(remaining % 60).toString().padStart(2, "0")}</div><div className="mt-1 muted">{state.snapshot.windowId || "No active market"}</div></div><div><div className="eyebrow">Market status</div><div className="mt-2 font-bold">{state.snapshot.feedHealth === "LIVE" ? "LIVE BOOK" : "FEED DISCONNECTED"}</div><div className="mt-1 muted">{state.snapshot.feedMessage}</div></div><div><div className="eyebrow">Binary consistency</div><div className="mt-2 font-bold">{state.snapshot.consistent ? "CONSISTENT" : "WAITING"}</div></div></section>
    <section className="mt-6 panel"><div className="eyebrow">Market radar</div><h2 className="mt-1 text-xl font-bold">Distance to 91c trigger</h2><div className="mt-4 grid gap-3 md:grid-cols-2">{radar("UP")}{radar("DOWN")}</div></section>
    <section className="mt-6"><div className="eyebrow">Portfolio metrics</div><div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">{metrics.map(([label, value]) => <div className="metric" key={label}><div className="eyebrow">{label}</div><div className="mt-2 text-lg font-bold">{value}</div></div>)}</div></section>
    <section className="mt-6 panel"><div className="eyebrow">Active position cockpit</div><h2 className="mt-1 text-xl font-bold">{position ? `${position.outcome} position open` : "No active position"}</h2>{position ? <><div className="mt-3 flex justify-between text-sm muted"><span>Stop loss {cents((position.cost - 3) / position.shares)}</span><span>Take profit 99.0¢</span></div><div className="mt-2 h-3 overflow-hidden rounded-full bg-slate-800"><div className="h-full rounded-full bg-gradient-to-r from-rose-400 via-amber-300 to-emerald-400" style={{ width: `${range}%` }} /></div><div className="mt-3 grid gap-1 text-sm muted"><span>Entry {cents(position.entryPrice)} · {position.shares.toFixed(3)} shares · current bid {cents(state.snapshot[position.outcome.toLowerCase() as "up" | "down"].bid)}</span><span>Cost {money(position.cost)} · seconds remaining {remaining.toFixed(1)}</span></div></> : <p className="mt-3 muted">Waiting for a server-authoritative entry.</p>}</section>
    <section className="mt-6 panel"><div className="flex flex-wrap gap-4 border-b border-slate-800 pb-3"><h2 className="font-bold">Completed Trades</h2><span className="muted">All Execution Fills</span></div><div className="mt-3 overflow-x-auto"><table className="w-full text-left text-sm"><thead className="muted"><tr><th className="p-2">Side</th><th className="p-2">Outcome</th><th className="p-2">Price</th><th className="p-2">USD</th><th className="p-2">Reason</th></tr></thead><tbody>{fills.filter(fill => fill.side === "SELL").map((fill, index) => <tr key={`${fill.timestamp ?? index}-completed`} className="border-t border-slate-800"><td className="p-2">{fill.side}</td><td className="p-2">{fill.outcome}</td><td className="p-2">{cents(fill.price)}</td><td className="p-2">{money(fill.usd)}</td><td className="p-2">{fill.reason}</td></tr>)}</tbody></table><div className="mt-4 border-t border-slate-800 pt-3 text-xs muted">All Execution Fills: {fills.length} · completed trades: {fills.filter(fill => fill.side === "SELL").length}</div></div></section>
    <footer className="mt-6 flex flex-wrap justify-between gap-2 border-t border-slate-800 pt-4 text-sm muted"><span>Reconciliation: {state.account.reconciliationStatus} · diff {money(state.account.reconciliationDiff)}</span><span>Window {state.snapshot.windowId || "none"}</span></footer>
  </main>;
}

createRoot(document.getElementById("root")!).render(<React.StrictMode><ErrorBoundary><App /></ErrorBoundary></React.StrictMode>);
