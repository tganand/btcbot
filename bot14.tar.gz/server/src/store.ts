import { copyFile, mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { dirname, join } from "node:path";
import type { AccountId, PaperAccount, PaperAccountsState } from "./types.js";
import { config } from "./config.js";
export const statePath = join(config.dataDir, "bot_state.json");
export const archiveDir = join(config.dataDir, "archive");
export const archiveAccountState = async (): Promise<string> => {
  await mkdir(archiveDir, { recursive: true });
  const archivePath = join(archiveDir, `bot_state-${new Date().toISOString().replace(/[:.]/g, "-")}.json`);
  await copyFile(statePath, archivePath);
  return archivePath;
};
export const resetAccountState = async (account: PaperAccount): Promise<PaperAccount> => {
  if (account.openPosition) throw new Error("Close the open trade first");
  await archiveAccountState();
  Object.assign(account, freshAccount());
  return account;
};
export const freshAccount = (): PaperAccount => ({ startingBalance: config.startingBalance, cashBalance: config.startingBalance, totalRealizedPnl: 0, openPosition: null, ledger: [], version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0, entriesThisWindow: {}, lastEntryExitByOutcome: {}, postExitTracking: {}, dailyPnl: {}, missedFillCount: 0, missedFillsByRulesVersion: {}, entryAttemptsThisWindow: {} });
const normalizeAccount = (input: Partial<PaperAccount> | undefined): PaperAccount => {
  const raw = input as (Partial<PaperAccount> & { pendingOrder?: unknown }) | undefined;
  if (raw?.pendingOrder) console.info("[store] dropping non-persistent pending order from saved account");
  const account = { ...freshAccount(), ...(input ?? {}) };
  delete (account as PaperAccount & { pendingOrder?: unknown }).pendingOrder;
  account.ledger = (input?.ledger ?? []).map((fill) => ({
    ...fill,
    id: fill.id ?? randomUUID(),
    timestamp: fill.timestamp ?? 0,
    windowId: fill.windowId ?? "",
    fee: fill.fee ?? 0,
    slippage: fill.slippage ?? 0
  }));
  account.entriesThisWindow = account.entriesThisWindow ?? {};
  account.lastEntryExitByOutcome = account.lastEntryExitByOutcome ?? {};
  account.postExitTracking = account.postExitTracking ?? {};
  account.missedFillCount = account.missedFillCount ?? 0;
  account.missedFillsByRulesVersion = account.missedFillsByRulesVersion ?? {};
  account.entryAttemptsThisWindow = account.entryAttemptsThisWindow ?? {};
  return account;
};
export const freshAccounts = (): PaperAccountsState => ({ accounts: { mine: freshAccount(), claude: freshAccount() } });
export const loadAccounts = async (): Promise<PaperAccountsState> => {
  try {
    const loaded = JSON.parse(await readFile(statePath, "utf8")) as Partial<PaperAccountsState> & Partial<PaperAccount>;
    if (loaded.accounts && typeof loaded.accounts === "object") {
      return { accounts: { mine: normalizeAccount(loaded.accounts.mine), claude: normalizeAccount(loaded.accounts.claude) } };
    }
    return { accounts: { mine: normalizeAccount(loaded), claude: freshAccount() } };
  } catch { return freshAccounts(); }
};
let saveQueue: Promise<void> = Promise.resolve();
export const saveAccounts = async (accounts: PaperAccountsState): Promise<void> => {
  saveQueue = saveQueue.then(async () => {
    try {
      await mkdir(dirname(statePath), { recursive: true });
      const temp = `${statePath}.${randomUUID()}.tmp`;
      await writeFile(temp, JSON.stringify(accounts, null, 2), "utf8");
      await rename(temp, statePath);
    } catch (error) {
      console.error(`[store] save failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  });
  await saveQueue;
};
export const loadAccount = async (): Promise<PaperAccount> => (await loadAccounts()).accounts.mine;
export const saveAccount = async (account: PaperAccount): Promise<void> => saveAccounts({ accounts: { mine: account, claude: freshAccount() } });

export const resetOneAccountState = async (accounts: PaperAccountsState, id: AccountId): Promise<void> => {
  const account = accounts.accounts[id];
  if (account.openPosition) throw new Error("Close the open trade first");
  await archiveAccountState();
  Object.assign(account, freshAccount());
};
