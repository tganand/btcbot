import { describe, expect, it } from "vitest";
import { defaultAccountRules, validateMineRules } from "./config.js";

describe("paper account rules", () => {
  it("uses the distinct Mine and Claude defaults", () => {
    expect(defaultAccountRules("mine")).toMatchObject({ entryMin: 0.91, entryMax: 0.95, stopLossUsd: 1.5, minSecondsRemaining: 90, maxSecondsRemaining: 480 });
    expect(defaultAccountRules("claude")).toMatchObject({ entryMin: 0.86, entryMax: 0.92, stopLossUsd: 0.1, minSecondsRemaining: 120, thinBookCheck: true, emptyBookSafety: true, dailyLossLimit: -5, dailyProfitLock: 20 });
  });

  it("accepts valid editable rules and rejects each invalid range", () => {
    const valid = { entryMin: 0.5, entryMax: 0.97, target: 0.99, stopLossUsd: 0.25, tradeSizeUsd: 25, maxSecondsRemaining: 840 };
    expect(validateMineRules(valid, 90, 25)).toEqual({ rules: valid });
    expect(validateMineRules({ ...valid, entryMin: 0.49 }, 90, 25)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, entryMin: 0.97 }, 90, 25)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, target: 0.97 }, 90, 25)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, stopLossUsd: 26 }, 90, 25)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, tradeSizeUsd: 26 }, 90, 25)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, maxSecondsRemaining: 90 }, 90, 25)).toHaveProperty("error");
    expect(validateMineRules({ ...valid, entryMin: Number.NaN }, 90, 25)).toHaveProperty("error");
  });
});
