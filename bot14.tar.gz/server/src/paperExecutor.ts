import { randomUUID } from "node:crypto";
import type { EngineConfig } from "./config.js";
import type { LedgerFill, Outcome, PaperAccount } from "./types.js";
import { feeForFill } from "./math.js";

export class PaperExecutor {
  public constructor(private readonly config: EngineConfig) {}
  public buy(account: PaperAccount, windowId: string, outcome: Outcome, ask: number, now: number, tradeSizeUsd = this.config.tradeSizeUsd): LedgerFill | null {
    if (!Number.isFinite(ask) || ask <= 0 || ask >= 1) return null;
    const fillPrice = ask * (1 + this.config.slippageBps / 10000);
    const shares = tradeSizeUsd / fillPrice;
    if (fillPrice < 0.01 || fillPrice > 0.99) return null;
    const fee = feeForFill(shares, fillPrice, this.config.feeRate);
    const fill: LedgerFill = { id: randomUUID(), timestamp: now, windowId, side: "BUY", outcome, price: fillPrice, fillPrice, decisionPrice: ask, shares, usd: shares * fillPrice, fee, slippage: fillPrice - ask, reason: "ENTRY" };
    account.ledger.push(fill);
    return fill;
  }
  public sell(account: PaperAccount, windowId: string, outcome: Outcome, shares: number, actualBid: number, reason: string, now: number, triggerPrice = actualBid, metadata: { decisionPrice?: number; delayMs?: number; windowSlug?: string } = {}): LedgerFill {
    const price = actualBid * (1 - this.config.slippageBps / 10000);
    const usd = shares * price;
    const fee = feeForFill(shares, price, this.config.feeRate);
    const fill: LedgerFill = { id: randomUUID(), timestamp: now, windowId, windowSlug: metadata.windowSlug, side: "SELL", outcome, price, fillPrice: price, decisionPrice: metadata.decisionPrice ?? actualBid, delayMs: metadata.delayMs, triggerPrice, shares, usd, fee, slippage: actualBid - price, extraSlippage: reason === "STOP_LOSS" ? Math.max(0, triggerPrice - actualBid) : 0, reason };
    account.ledger.push(fill);
    return fill;
  }
  public settle(account: PaperAccount, windowId: string, outcome: Outcome, shares: number, settlementPrice: number, reason: string, now: number, windowSlug?: string): LedgerFill {
    const usd = shares * settlementPrice;
    const fee = 0;
    const fill: LedgerFill = { id: randomUUID(), timestamp: now, windowId, windowSlug, side: "SELL", outcome, price: settlementPrice, decisionPrice: settlementPrice, fillPrice: settlementPrice, delayMs: 0, shares, usd, fee, slippage: 0, reason };
    account.ledger.push(fill);
    return fill;
  }
}
