import { describe, expect, it } from "vitest";
import { EntryEngine } from "./entryEngine.js";
import { config as baseConfig, defaultAccountRules } from "./config.js";
import { stopPrice } from "./math.js";
import { PaperExecutor } from "./paperExecutor.js";
import type { MarketSnapshot, PaperAccount } from "./types.js";

const config = { ...baseConfig, fillDelayMinMs: 0, fillDelayMaxMs: 0 };
const account = (): PaperAccount => ({ startingBalance: 100, cashBalance: 100, totalRealizedPnl: 0, openPosition: null, ledger: [], version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0, entriesThisWindow: {}, lastEntryExitByOutcome: {} });
const snapshot = (secondsRemaining: number): MarketSnapshot => ({
  windowId: "w",
  windowStart: 0,
  windowEnd: secondsRemaining,
  up: { bid: 0.94, ask: 0.94, bidSize: 10, askSize: 20, lastUpdateTs: 1000 },
  down: { bid: 0.04, ask: 0.05, bidSize: 20, askSize: 20, lastUpdateTs: 1000 },
  feedHealth: "LIVE",
  consistent: true,
  feedMessage: "Live prices flowing"
});

describe("entry visibility and decisions", () => {
  it("buys after a held trigger with time and liquidity", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(113), 0);
    engine.tick(snapshot(113), 1000);
    expect(paper.ledger).toHaveLength(1);
    expect(paper.ledger[0]?.outcome).toBe("UP");
  });
  it("stores the settings snapshot on the position and entry fill", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(113), 0);
    engine.tick(snapshot(113), 1000);
    const fill = paper.ledger[0]!;
    expect(fill.triggerPrice).toBe(config.entryTrigger);
    expect(fill.takeProfitPrice).toBe(config.takeProfit);
    expect(fill.stopLossUsd).toBe(1.5);
    expect(fill.maxEntryPrice).toBe(config.maxEntryPrice);
    expect(fill.stopLossPrice).toBeCloseTo(stopPrice({ entryPrice: fill.price, shares: fill.shares, cost: fill.usd + fill.fee, outcome: "UP", windowId: "w", openedAt: fill.timestamp }, 1.5, config.feeRate), 6);
    expect(paper.openPosition?.stopLossPrice).toBe(fill.stopLossPrice);
  });
  it("blocks an otherwise eligible entry when too late", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(80), 0);
    engine.tick(snapshot(80), 1000);
    expect(paper.ledger).toHaveLength(0);
    expect(engine.getStatuses().UP.decision).toBe("TOO_LATE");
  });
  it("takes profit from bid without ask liquidity or reconciliation", () => {
    const paper = account();
    paper.cashBalance = 90;
    paper.reconciliationStatus = "MISMATCH";
    paper.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.windowId = "old";
    current.down = { bid: 0.99, ask: 1, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 1000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("TAKE_PROFIT");
  });
  it("settles an older position at resolved 1.00 or 0.00", async () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    engine.tick({ ...snapshot(100), windowId: "new" }, 1000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.price).toBe(1);
    const second = account();
    second.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const secondEngine = new EntryEngine(config, second, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    secondEngine.tick({ ...snapshot(100), windowId: "new" }, 1000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(second.openPosition).toBeNull();
    expect(second.ledger.at(-1)?.price).toBe(0);
  });
  it("recovers a stale startup position", async () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "DOWN", price: 0 }), 0);
    await engine.recoverStalePosition(901000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("SETTLEMENT");
  });
  it("blocks an ask above the configured maximum", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(113);
    current.up.ask = 0.975;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(paper.openPosition).toBeNull();
    expect(engine.getStatuses().UP.decision).toBe("ABOVE_MAX_ENTRY");
  });
  it("blocks the failing empty-ask and 99c cases", () => {
    const empty = account();
    const emptyEngine = new EntryEngine(config, empty, new PaperExecutor(config), () => undefined, async () => null, 0);
    const emptySnapshot = snapshot(113);
    emptySnapshot.up.ask = 1;
    emptySnapshot.up.askSize = 0;
    emptyEngine.tick(emptySnapshot, 0);
    emptyEngine.tick(emptySnapshot, 1000);
    expect(empty.ledger).toHaveLength(0);
    expect(emptyEngine.getStatuses().UP.decision).toBe("INSUFFICIENT_LIQUIDITY");
    const high = account();
    const highEngine = new EntryEngine(config, high, new PaperExecutor(config), () => undefined, async () => null, 0);
    const highSnapshot = snapshot(113);
    highSnapshot.up.ask = 0.99;
    highEngine.tick(highSnapshot, 0);
    highEngine.tick(highSnapshot, 1000);
    expect(highEngine.getStatuses().UP.decision).toBe("ABOVE_MAX_ENTRY");
  });
  it("allows one entry, then blocks re-entry in the same window", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(113);
    current.up.ask = 0.93;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(paper.openPosition).not.toBeNull();
    current.up.bid = 0.99;
    engine.tick(current, 2000);
    expect(paper.openPosition).toBeNull();
    current.up.bid = 0.92;
    engine.tick(current, 3000);
    expect(engine.getStatuses().UP.decision).toBe("ALREADY_TRADED_THIS_WINDOW");
  });
  it("never creates a fill at or above one", () => {
    const paper = account();
    expect(new PaperExecutor(config).buy(paper, "w", "DOWN", 0.99, 1)).toBeNull();
  });
  it("does not charge a fee on settlement", () => {
    const fill = new PaperExecutor(config).settle(account(), "w", "UP", 10, 1, "SETTLEMENT", 1000);
    expect(fill.fee).toBe(0);
    expect(fill.delayMs).toBe(0);
  });
  it("halts after three losing round trips", () => {
    const paper = account();
    for (let index = 0; index < 3; index += 1) {
      paper.ledger.push({ id: `b${index}`, timestamp: index, windowId: `w${index}`, side: "BUY", outcome: "UP", price: 0.93, shares: 10, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" });
      paper.ledger.push({ id: `s${index}`, timestamp: index, windowId: `w${index}`, side: "SELL", outcome: "UP", price: 0.9, shares: 10, usd: 9, fee: 0, slippage: 0, reason: "STOP_LOSS" });
    }
    paper.totalRealizedPnl = -3;
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(113);
    current.up.ask = 0.93;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(engine.getStatuses().UP.decision).toBe("HALTED_BY_CIRCUIT_BREAKER");
  });
  it("keeps an unresolved stale position pending instead of settling at zero", async () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "old", windowStart: 0, entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    await engine.recoverStalePosition(901000);
    expect(paper.openPosition?.resolutionStatus).toBe("PENDING_RESOLUTION");
    expect(paper.ledger).toHaveLength(0);
  });
  it("stops at the computed $1.50 loss threshold", () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "w", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    const stop = stopPrice({ ...paper.openPosition, outcome: "DOWN", windowId: "w" }, 1.5, config.feeRate);
    current.down = { bid: stop - 0.01, ask: 0.80, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 2000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("STOP_LOSS");
    expect(paper.totalRealizedPnl).toBe(0);
    expect(paper.ledger.at(-1)?.triggerPrice).toBeCloseTo(stop, 4);
    expect(paper.ledger.at(-1)?.fillPrice).toBeCloseTo((stop - 0.01) * (1 - config.slippageBps / 10000), 5);
  });
  it("records a larger loss and gap when price jumps through stop", () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "w", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.down = { bid: 0.45, ask: 0.5, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 2000);
    const fill = paper.ledger.at(-1)!;
    expect(fill.reason).toBe("STOP_LOSS");
    expect(fill.fillPrice).toBeCloseTo(0.45 * (1 - config.slippageBps / 10000), 5);
    expect(fill.extraSlippage).toBeGreaterThan(0.2);
  });
  it("holds at a bid above the stop threshold", () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "w", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.down = { bid: 0.81, ask: 0.82, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    current.up.bid = 0.20;
    engine.tick(current, 2000);
    expect(paper.openPosition).not.toBeNull();
  });
  it("reverses independently at the opposite-contract threshold", () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "w", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.down = { bid: 0.9, ask: 0.91, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    current.up.bid = 0.35;
    engine.tick(current, 2000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("REVERSAL");
  });
  it("tracks a stopped trade that would have won without changing accounting", async () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "w", windowStart: 0, entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    const current = snapshot(100);
    current.up = { bid: 0.74, ask: 0.75, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 2000);
    expect(paper.ledger.at(-1)?.reason).toBe("STOP_LOSS");
    const before = paper.totalRealizedPnl;
    engine.tick({ ...current, windowId: "next", windowStart: 900, windowEnd: 1800 }, 901000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(paper.ledger.at(-1)?.outcomeAfterExit?.verdict).toBe("WOULD_HAVE_WON");
    expect(paper.totalRealizedPnl).toBe(before);
  });
  it("tracks a stopped trade that was right", async () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "w", windowStart: 0, entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "DOWN", price: 1 }), 0);
    const current = snapshot(100);
    current.up = { bid: 0.74, ask: 0.75, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 2000);
    engine.tick({ ...current, windowId: "next", windowStart: 900, windowEnd: 1800 }, 901000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(paper.ledger.at(-1)?.outcomeAfterExit?.verdict).toBe("STOP_WAS_RIGHT");
  });
  it("waits for the injected fill delay and records it", () => {
    const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 300 };
    const paper = account();
    let now = 0;
    const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => undefined, async () => null, 0, "mine", defaultAccountRules("mine"), () => 0.5, () => now);
    engine.tick(snapshot(113));
    now = 1000;
    engine.tick(snapshot(113));
    expect(paper.ledger).toHaveLength(0);
    now = 1199;
    engine.tick(snapshot(113));
    expect(paper.ledger).toHaveLength(0);
    now = 1200;
    engine.tick(snapshot(113));
    expect(paper.ledger[0]?.delayMs).toBe(200);
    expect(paper.ledger[0]?.decisionPrice).toBe(0.94);
  });
  it("marks an entry MISSED_FILL when the fill-time ask exceeds its max", () => {
    const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 100 };
    const paper = account();
    const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => undefined, async () => null, 0, "mine", defaultAccountRules("mine"), () => 0, () => 0);
    const current = snapshot(113);
    engine.tick(current, 0);
    engine.tick(current, 1000);
    current.up.ask = 0.96;
    engine.tick(current, 1100);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger).toHaveLength(0);
    expect(paper.missedFillCount).toBe(1);
    expect(paper.entryAttemptsThisWindow?.w).toBe(1);
  });
  it("allows three missed fills without consuming the one successful trade", () => {
    const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 100 };
    const paper = account();
    const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => undefined, async () => null, 0, "mine", defaultAccountRules("mine"), () => 0, () => 0);
    const current = snapshot(400);
    engine.tick(current, 0);
    engine.tick(current, 1000);
    for (const [decision, fill] of [[1000, 1100], [1101, 1201], [1202, 1302]]) {
      current.up.ask = 0.94;
      engine.tick(current, decision);
      current.up.ask = 0.96;
      engine.tick(current, fill);
    }
    current.up.ask = 0.94;
    engine.tick(current, 1303);
    expect(paper.missedFillCount).toBe(3);
    expect(paper.entriesThisWindow.w).toBeUndefined();
    expect(engine.getStatuses().UP.decision).toBe("MISSED_FILL_LIMIT");
  });
  it("counts fill-time price, price-range, and liquidity failures as missed fills", () => {
    const scenarios: Array<{ ask: number; decisionAsk?: number; askSize: number; slippageBps: number }> = [
      { ask: 0.96, askSize: 20, slippageBps: 50 },
      { ask: 0.005, askSize: 5000, slippageBps: 50 },
      { ask: 0.95, decisionAsk: 0.91, askSize: 20, slippageBps: 500 },
      { ask: 0.94, askSize: 1, slippageBps: 50 }
    ];
    for (const scenario of scenarios) {
      const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 100, slippageBps: scenario.slippageBps };
      const paper = account();
      const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => undefined, async () => null, 0, "mine", defaultAccountRules("mine"), () => 0, () => 0);
      const current = snapshot(113);
      current.up.ask = scenario.decisionAsk ?? 0.94;
      engine.tick(current, 0);
      engine.tick(current, 1000);
      current.up.ask = scenario.ask;
      current.up.askSize = scenario.askSize;
      engine.tick(current, 1100);
      expect(paper.missedFillCount).toBe(1);
      expect(paper.ledger).toHaveLength(0);
      expect(paper.entriesThisWindow.w).toBeUndefined();
    }
  });
  it("enforces Claude's thin-book limit again at fill time", () => {
    const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 100 };
    const paper = account();
    const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => undefined, async () => null, 0, "claude", defaultAccountRules("claude"), () => 0, () => 0);
    const current = snapshot(300);
    current.up.ask = 0.88;
    current.up.askSize = 100;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    current.up.askSize = 20;
    engine.tick(current, 1100);
    expect(paper.missedFillCount).toBe(1);
    expect(paper.openPosition).toBeNull();
  });
  it("retries a sell after an empty bid and fills once liquidity returns", () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "w", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.up = { bid: 0, ask: 0.5, bidSize: 0, askSize: 10, lastUpdateTs: 1 };
    engine.tick(current, 1000);
    expect(paper.openPosition).not.toBeNull();
    expect(paper.ledger).toHaveLength(0);
    current.up = { ...current.up, bid: 0.7, bidSize: 10 };
    engine.tick(current, 1099);
    expect(paper.ledger).toHaveLength(0);
    engine.tick(current, 1100);
    expect(paper.ledger).toHaveLength(1);
    expect(paper.ledger[0]?.reason).toBe("STOP_LOSS");
  });
  it("applies account-specific entry windows, thin-book checks, and entry maxima", () => {
    const mine = account();
    const mineEngine = new EntryEngine(config, mine, new PaperExecutor(config), () => undefined, async () => null, 0, "mine");
    mineEngine.tick(snapshot(501), 0);
    mineEngine.tick(snapshot(501), 1000);
    expect(mineEngine.getStatuses().UP.decision).toBe("TOO_EARLY");

    const claude = account();
    const claudeConfig = { ...config, fillDelayMinMs: 0, fillDelayMaxMs: 0 };
    const claudeEngine = new EntryEngine(claudeConfig, claude, new PaperExecutor(claudeConfig), () => undefined, async () => null, 0, "claude");
    const thin = snapshot(300);
    thin.up.ask = 0.88;
    claudeEngine.tick(thin, 0);
    claudeEngine.tick(thin, 1000);
    expect(claudeEngine.getStatuses().UP.decision).toBe("THIN_BOOK");

    const mineHigh = account();
    const mineHighEngine = new EntryEngine(config, mineHigh, new PaperExecutor(config), () => undefined, async () => null, 0, "mine");
    const expensiveMine = snapshot(300);
    expensiveMine.up.ask = 0.96;
    mineHighEngine.tick(expensiveMine, 0);
    mineHighEngine.tick(expensiveMine, 1000);
    expect(mineHighEngine.getStatuses().UP.decision).toBe("ABOVE_MAX_ENTRY");

    const claudeHigh = account();
    const claudeHighEngine = new EntryEngine(claudeConfig, claudeHigh, new PaperExecutor(claudeConfig), () => undefined, async () => null, 0, "claude");
    const expensiveClaude = snapshot(300);
    expensiveClaude.up.ask = 0.93;
    claudeHighEngine.tick(expensiveClaude, 0);
    claudeHighEngine.tick(expensiveClaude, 1000);
    expect(claudeHighEngine.getStatuses().UP.decision).toBe("ABOVE_MAX_ENTRY");
  });
  it("uses Claude's 45-second safety exit and keeps the opened rules snapshot", () => {
    const paper = account();
    const openedRules = defaultAccountRules("claude");
    paper.openPosition = { outcome: "UP", windowId: "w", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0, rules: { ...openedRules }, rulesVersion: 3 };
    const claudeConfig = { ...config, fillDelayMinMs: 0, fillDelayMaxMs: 0 };
    const engine = new EntryEngine(claudeConfig, paper, new PaperExecutor(claudeConfig), () => undefined, async () => null, 0, "claude", openedRules);
    const current = snapshot(46);
    current.up = { bid: 0.9, ask: 0.91, bidSize: 0, askSize: 10, lastUpdateTs: 1 };
    engine.tick(current, 1000);
    expect(paper.openPosition).not.toBeNull();
    current.up.bidSize = 10;
    engine.tick(current, 1100);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger[0]?.reason).toBe("EMPTY_BOOK");
    expect(paper.ledger[0]?.emptyBook).toBe(true);
    expect(paper.ledger[0]?.exitContext?.length).toBeGreaterThan(0);
    expect(paper.ledger[0]?.rulesVersion).toBe(3);
    expect(paper.openPosition).toBeNull();
  });
  it("uses the position's rules snapshot after active rules change", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(300);
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(paper.openPosition?.rules?.target).toBe(0.99);
    engine.rules = { ...engine.rules, target: 0.8 };
    current.up.bid = 0.9;
    engine.tick(current, 2000);
    expect(paper.openPosition).not.toBeNull();
  });
  it("blocks Claude entries at the persisted daily loss limit and profit lock", () => {
    const now = Date.now();
    const makeWithPnl = (pnl: number) => {
      const paper = account();
      paper.ledger.push(
        { id: "b", timestamp: now - 1000, windowId: "prior", side: "BUY", outcome: "UP", price: 0.9, shares: 10, usd: 9, fee: 0, slippage: 0, reason: "ENTRY" },
        { id: "s", timestamp: now, windowId: "prior", side: "SELL", outcome: "UP", price: (9 + pnl) / 10, shares: 10, usd: 9 + pnl, fee: 0, slippage: 0, reason: "TAKE_PROFIT" }
      );
      return paper;
    };
    const claudeConfig = { ...config, fillDelayMinMs: 0, fillDelayMaxMs: 0 };
    for (const [pnl, reason] of [[-6, "DAILY_LOSS_LIMIT"], [21, "DAILY_TARGET_REACHED"]] as const) {
      const paper = makeWithPnl(pnl);
      const engine = new EntryEngine(claudeConfig, paper, new PaperExecutor(claudeConfig), () => undefined, async () => null, now - 1000, "claude");
      const current = snapshot(300);
      current.up.ask = 0.88;
      current.up.askSize = 100;
      engine.tick(current, now - 1);
      engine.tick(current, now);
      expect(engine.getStatuses().UP.decision).toBe(reason);
    }
  });
});
