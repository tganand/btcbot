import { describe, expect, it } from "vitest";
import { formatEtWindow } from "./window.js";

describe("Polymarket window labels", () => {
  it("formats a 15-minute window in Eastern time", () => {
    const start = Date.UTC(2026, 0, 1, 1, 15) / 1000;
    const end = start + 15 * 60;
    expect(formatEtWindow(start, end)).toBe("8:15 PM - 8:30 PM ET");
    expect(end - start).toBe(900);
  });

  it("waits instead of showing an invalid same-time window", () => {
    expect(formatEtWindow(0, 0)).toBe("Waiting for next window");
    expect(formatEtWindow(100, 100)).toBe("Waiting for next window");
  });
});
