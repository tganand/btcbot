import { describe, expect, it } from "vitest";
import { freshAccount, resetAccountState, saveAccount } from "./store.js";

describe("serialized persistence", () => {
  it("handles concurrent saves without rename races", async () => {
    await expect(Promise.all(Array.from({ length: 20 }, (_, index) => {
      const account = freshAccount();
      account.version = index;
      return saveAccount(account);
    }))).resolves.toHaveLength(20);
  });
  it("archives and refuses reset while a position is open", async () => {
    const account = freshAccount();
    await saveAccount(account);
    account.openPosition = { outcome: "UP", windowId: "w", entryPrice: 0.9, shares: 10, cost: 9, openedAt: Date.now() };
    await expect(resetAccountState(account)).rejects.toThrow("Close the open trade first");
    account.openPosition = null;
    await expect(resetAccountState(account)).resolves.toBe(account);
    expect(account.ledger).toHaveLength(0);
    expect(account.cashBalance).toBe(100);
  });
});
