import "dotenv/config";

const num = (name: string, fallback: number): number => {
  const value = Number(process.env[name]);
  return Number.isFinite(value) ? value : fallback;
};

export const config = {
  port: num("PORT", 3001),
  startingBalance: num("STARTING_BALANCE", 100),
  entryTrigger: num("ENTRY_TRIGGER_PRICE", 0.91),
  maxEntryPrice: num("MAX_ENTRY_PRICE", 0.95),
  circuitBreakerLossLimit: num("CIRCUIT_BREAKER_LOSS_LIMIT", 15),
  entryHoldMs: num("ENTRY_HOLD_MS", 400),
  minSecondsRemaining: num("MIN_SECONDS_REMAINING", 90),
  tradeSizeUsd: num("TRADE_SIZE_USD", 10),
  takeProfit: num("TAKE_PROFIT_PRICE", 0.99),
  stopLossUsd: num("STOP_LOSS_USD", 1.5),
  reversalPrice: num("REVERSAL_OPPOSITE_PRICE", 0.35),
  slippageBps: num("SLIPPAGE_BPS", 50),
  feeBps: num("FEE_BPS", 0),
  maxOpenPositions: num("MAX_OPEN_POSITIONS", 1),
  tickMs: num("ENGINE_TICK_MS", 25),
  dashboardUser: process.env.DASH_USER || "admin",
  dashboardPassword: process.env.DASH_PASSWORD || ""
} as const;

export type EngineConfig = typeof config;
