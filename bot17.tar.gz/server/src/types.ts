export type Outcome = "UP" | "DOWN";
export type Side = "BUY" | "SELL";
export type ExitReason = "TAKE_PROFIT" | "STOP_LOSS" | "REVERSAL" | "SETTLEMENT";
export type AccountId = "mine";

export interface Book {
  bid: number;
  ask: number;
  bidSize: number;
  askSize: number;
  lastUpdateTs: number;
  lastTrade?: number;
}
export type EntryDecision = "NONE" | "BELOW_TRIGGER" | "ABOVE_MAX_ENTRY" | "HOLD_TIMER" | "TOO_LATE" | "TOO_EARLY" | "THIN_BOOK" | "DAILY_LOSS_LIMIT" | "DAILY_TARGET_REACHED" | "MISSED_FILL_LIMIT" | "FEED_STALE" | "INCONSISTENT" | "POSITION_OPEN" | "WARMUP" | "INSUFFICIENT_LIQUIDITY" | "PRICE_OUT_OF_RANGE" | "NO_UPSIDE" | "ALREADY_TRADED_THIS_WINDOW" | "HALTED_BY_CIRCUIT_BREAKER";
export interface EntryStatus {
  ask: number;
  trigger: number;
  msHeldAboveTrigger: number;
  secondsRemaining: number;
  feedHealth: string;
  consistent: boolean;
  positionOpen: boolean;
  askSize: number;
  decision: EntryDecision;
}
export interface MarketSnapshot {
  windowId: string;
  windowSlug?: string;
  windowStart: number;
  windowEnd: number;
  windowTitle?: string;
  serverNow?: number;
  priceToBeat?: number | null;
  priceToBeatSource?: "polymarket" | "approx" | null;
  btcPrice?: number | null;
  btcPriceSource?: "polymarket" | "coinbase" | "kraken" | null;
  up: Book;
  down: Book;
  feedHealth: "LIVE" | "STALE" | "DISCONNECTED";
  consistent: boolean;
  feedMessage: string;
}
export interface LedgerFill {
  id: string;
  timestamp: number;
  windowId: string;
  windowSlug?: string;
  side: Side;
  outcome: Outcome;
  price: number;
  shares: number;
  usd: number;
  fee: number;
  slippage: number;
  decisionPrice?: number;
  reason: string;
  delayMs?: number;
  secondsRemainingAtEntry?: number;
  emptyBook?: boolean;
  rulesVersion?: number;
  exitContext?: Array<{ timestamp: number; up: Book; down: Book; secondsRemaining: number }>;
  triggerPrice?: number;
  fillPrice?: number;
  extraSlippage?: number;
  takeProfitPrice?: number;
  stopLossPrice?: number;
  stopLossUsd?: number;
  maxEntryPrice?: number;
  outcomeAfterExit?: PostExitTracking;
  priceToBeat?: number;
  btcAtEntry?: number;
  btcAtExit?: number;
}
export interface PostExitTracking {
  outcome: Outcome;
  bestBidAfterExit: number;
  finalResult: "pending" | Outcome;
  verdict: "PENDING" | "WOULD_HAVE_WON" | "STOP_WAS_RIGHT";
  windowStart?: number;
  updatedAt: number;
}
export interface PaperPosition {
  outcome: Outcome;
  windowId: string;
  windowSlug?: string;
  entryPrice: number;
  shares: number;
  cost: number;
  openedAt: number;
  windowStart?: number;
  resolutionStatus?: "PENDING_RESOLUTION";
  triggerPrice?: number;
  takeProfitPrice?: number;
  stopLossPrice?: number;
  stopLossUsd?: number;
  maxEntryPrice?: number;
  rules?: AccountRules;
  rulesVersion?: number;
  stopLossPriceOffset?: number;
  priceToBeat?: number;
  btcAtEntry?: number;
}
export interface AccountRules {
  entryMin: number;
  entryMax: number;
  holdMs: number;
  target: number;
  stopLossUsd: number;
  reversalPrice: number;
  tradeSizeUsd: number;
  maxSecondsRemaining: number;
  minSecondsRemaining: number;
  oneTradePerWindow: boolean;
  thinBookCheck?: boolean;
  emptyBookSafety?: boolean;
  dailyLossLimit?: number;
  dailyProfitLock?: number;
}
export interface PendingOrder {
  side: Side;
  outcome: Outcome;
  windowId: string;
  decisionPrice: number;
  decisionTime: number;
  fillAt: number;
  shares?: number;
  reason: string;
  triggerPrice: number;
  secondsRemaining: number;
  attempts?: number;
  fillDelayMs?: number;
  emptyBook?: boolean;
}
export interface Resolution {
  outcome: Outcome;
  price: number;
}
export interface PaperAccount {
  startingBalance: number;
  cashBalance: number;
  totalRealizedPnl: number;
  openPosition: PaperPosition | null;
  ledger: LedgerFill[];
  version: number;
  reconciliationStatus: "RECONCILED" | "MISMATCH";
  reconciliationDiff: number;
  entriesThisWindow: Record<string, boolean>;
  lastEntryExitByOutcome: Partial<Record<Outcome, number>>;
  postExitTracking?: Record<string, PostExitTracking>;
  dailyPnl?: Record<string, number>;
  rulesVersion?: number;
  rulesHistory?: Array<{ version: number; timestamp: number; rules: Record<string, number | boolean | undefined> }>;
  missedFillCount?: number;
  missedFillsByRulesVersion?: Record<string, number>;
  entryAttemptsThisWindow?: Record<string, number>;
  rules?: AccountRules;
}
export interface PaperAccountsState {
  accounts: { mine: PaperAccount };
}
export interface PortfolioMetrics {
  realizedPnl: number;
  unrealizedPnl: number;
  equity: number;
  cash: number;
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  maxDrawdown: number;
  bestTrade: number;
  worstTrade: number;
  exitReasons: Record<string, number>;
  expectancy: number;
  grossPnl: number;
  totalFees: number;
  missedFills: number;
  todayPnl: number;
  breakEvenWinRate: number;
}
