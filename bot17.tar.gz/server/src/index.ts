import express from "express";
import cors from "cors";
import { createServer } from "node:http";
import { join } from "node:path";
import { config, configSources, defaultAccountRules, validateMineRules } from "./config.js";
import { freshAccount, loadAccounts, saveAccounts, resetOneAccountState } from "./store.js";
import { buildTradesCsv, calculatePortfolioMetrics, reconcilePaperAccount } from "./math.js";
import { MarketFeed } from "./marketFeed.js";
import { EntryEngine } from "./entryEngine.js";
import { PaperExecutor } from "./paperExecutor.js";
import { lookupResolution } from "./settlement.js";
import type { AccountRules, MarketSnapshot, PaperAccount, PaperAccountsState } from "./types.js";
import { createBasicAuth, requireProductionPassword } from "./auth.js";
import { PriceRecorder } from "./priceRecorder.js";
import { BtcReferencePrice } from "./referencePrice.js";

requireProductionPassword();
const app = express();
app.use(cors());
app.use(express.json());
app.use(createBasicAuth(config.dashboardUser, config.dashboardPassword));
const server = createServer(app);
let state: PaperAccountsState = { accounts: { mine: freshAccount() } };
let snapshot: MarketSnapshot = { windowId: "", windowStart: 0, windowEnd: 0, windowTitle: "Waiting for next window", serverNow: Date.now(), up: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, down: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, feedHealth: "DISCONNECTED", consistent: false, feedMessage: "No active market found" };
const clients = new Set<express.Response>();
const btcReference = new BtcReferencePrice();
const priceRecorder = new PriceRecorder({
  directory: config.pricesDir,
  enabled: config.priceRecording,
  maxBytes: config.maxPricesMb * 1024 * 1024,
  resolveWindow: lookupResolution
});
let engine: EntryEngine | undefined;
const broadcast = (type: string, payload: unknown) => { for (const client of clients) client.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`); };
const full = () => {
  const account = state.accounts.mine;
  const metrics = calculatePortfolioMetrics(account, snapshot, config.feeRate);
  const entryStatus = engine?.getStatuses() ?? { UP: null, DOWN: null };
  return {
    account: {
      id: "mine",
      name: "My rules",
      ...account,
      rules: engine?.rules ?? account.rules ?? defaultAccountRules("mine"),
      circuitBreakerHalted: engine?.isCircuitBreakerHalted() ?? false,
      entryStatus,
      pendingOrder: engine?.getPendingOrder() ?? null
    },
    snapshot,
    metrics,
    config: { entryTrigger: config.entryTrigger, takeProfit: config.takeProfit, stopLossUsd: config.stopLossUsd, maxEntryPrice: config.maxEntryPrice, tradeSizeUsd: config.tradeSizeUsd, maxTradeSizeUsd: config.maxTradeSizeUsd, slippageBps: config.slippageBps, feeRate: config.feeRate, sources: configSources },
    circuitBreakerHalted: engine?.isCircuitBreakerHalted() ?? false,
    entryStatus
  };
};
app.get("/api/state", (_req, res) => res.json(full()));
app.get("/api/recording/status", async (_req, res) => res.json(await priceRecorder.getStatus()));
app.get("/api/accounts/mine/rules", (_req, res) => {
  res.json({ rules: engine?.rules ?? state.accounts.mine.rules ?? defaultAccountRules("mine"), rulesVersion: state.accounts.mine.rulesVersion ?? 1, history: state.accounts.mine.rulesHistory ?? [] });
});
app.put("/api/accounts/mine/rules", async (req, res) => {
  if (req.body?.confirm !== true) { res.status(400).json({ error: "confirm=true required" }); return; }
  const validation = validateMineRules(req.body, defaultAccountRules("mine").minSecondsRemaining, config.maxTradeSizeUsd);
  if ("error" in validation) { res.status(400).json({ error: validation.error }); return; }
  const rules: AccountRules = { ...(engine?.rules ?? defaultAccountRules("mine")), ...validation.rules };
  const account = state.accounts.mine;
  const version = (account.rulesVersion ?? 1) + 1;
  account.rules = { ...rules };
  account.rulesVersion = version;
  account.rulesHistory = [...(account.rulesHistory ?? []), { version, timestamp: Date.now(), rules: { ...rules } }].slice(-50);
  if (engine) engine.rules = { ...rules };
  reconcilePaperAccount(account);
  await saveAccounts(state);
  broadcast("momentum_account_update", full());
  res.json({ rules: account.rules, rulesVersion: version, history: account.rulesHistory });
});
app.get("/api/trades.csv", (_req, res) => {
  const csv = buildTradesCsv(state.accounts.mine.ledger);
  res.type("text/csv").setHeader("Content-Disposition", "attachment; filename=\"mine-trades.csv\"");
  res.send(csv);
});
const resetAccount = async (res: express.Response): Promise<void> => {
  try {
    await resetOneAccountState(state);
    engine?.cancelPendingOrder("account reset");
    state.accounts.mine.rules = defaultAccountRules("mine");
    state.accounts.mine.rulesVersion = 1;
    state.accounts.mine.rulesHistory = [];
    if (engine) engine.rules = defaultAccountRules("mine");
    reconcilePaperAccount(state.accounts.mine);
    await saveAccounts(state);
    broadcast("momentum_account_update", full());
    res.json(full());
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message === "Close the open trade first") { res.status(409).json({ error: message }); return; }
    console.error(`[mine][store] reset archive failed: ${message}`);
    res.status(500).json({ error: "Unable to archive current account" });
  }
};
app.post("/api/reset", async (req, res) => {
  if (req.body?.confirm !== true) { res.status(400).json({ error: "confirm=true required" }); return; }
  await resetAccount(res);
});
app.get("/events", (req, res) => { res.setHeader("Content-Type", "text/event-stream"); res.setHeader("Cache-Control", "no-cache"); res.setHeader("Connection", "keep-alive"); res.flushHeaders(); clients.add(res); res.write(`event: momentum_account_update\ndata: ${JSON.stringify(full())}\n\n`); req.on("close", () => clients.delete(res)); });
const clientDist = join(process.cwd(), "client", "dist");
app.use(express.static(clientDist, { setHeaders: (res, filePath) => { if (filePath.endsWith("\\index.html") || filePath.endsWith("/index.html")) res.setHeader("Cache-Control", "no-store"); else if (filePath.includes("\\assets\\") || filePath.includes("/assets/")) res.setHeader("Cache-Control", "public, max-age=31536000, immutable"); } }));
app.get("*", (_req, res) => { res.setHeader("Cache-Control", "no-store"); res.sendFile(join(clientDist, "index.html")); });
setInterval(() => {
  try { engine?.tick(snapshot); }
  catch (error) { console.error(`[engine] tick loop error: ${error instanceof Error ? error.stack ?? error.message : String(error)}`); }
}, config.tickMs);
const priceTick = () => {
  snapshot = { ...snapshot, serverNow: Date.now() };
  priceRecorder.tick(snapshot);
  const stale = snapshot.feedHealth === "LIVE" && (Date.now() - Math.max(snapshot.up.lastUpdateTs, snapshot.down.lastUpdateTs) > 3000);
  if (stale) snapshot = { ...snapshot, feedHealth: "STALE", feedMessage: "WebSocket connected but no price update for 3 seconds" };
  const metrics = calculatePortfolioMetrics(state.accounts.mine, snapshot, config.feeRate);
  broadcast("price_tick", {
    up: snapshot.up, down: snapshot.down, feedHealth: snapshot.feedHealth, feedMessage: snapshot.feedMessage,
    windowId: snapshot.windowId, windowStart: snapshot.windowStart, windowEnd: snapshot.windowEnd,
    windowTitle: snapshot.windowTitle, serverNow: snapshot.serverNow,
    priceToBeat: snapshot.priceToBeat, priceToBeatSource: snapshot.priceToBeatSource,
    btcPrice: snapshot.btcPrice, btcPriceSource: snapshot.btcPriceSource,
    secondsRemaining: Math.max(0, snapshot.windowEnd - Date.now() / 1000),
    metrics, entryStatus: engine?.getStatuses()
  });
};
setInterval(priceTick, 500);
setInterval(() => {
  void btcReference.refresh(snapshot).then((prices) => {
    snapshot = { ...snapshot, ...prices };
    priceTick();
  }).catch(() => {
    snapshot = { ...snapshot, btcPrice: null, btcPriceSource: null };
    priceTick();
  });
}, 1000);
setInterval(() => { for (const client of clients) client.write(": keep-alive\n\n"); }, 15000);
const resolverFor = (account: PaperAccount) => async (position: NonNullable<PaperAccount["openPosition"]>) => {
  const windowStart = position.windowStart ?? Math.floor(position.openedAt / 1000 / 3600) * 3600;
  return lookupResolution(windowStart);
};
const start = async (): Promise<void> => {
  void priceRecorder.start();
  btcReference.start();
  state = await loadAccounts();
  const account = state.accounts.mine;
  console.info("[mine][engine] pending orders are memory-only; none restored");
  const rules = account.rules ?? defaultAccountRules("mine");
  account.rules = rules;
  account.rulesVersion ??= 1;
  engine = new EntryEngine(config, account, new PaperExecutor(config), () => {
    reconcilePaperAccount(account);
    void saveAccounts(state);
    broadcast("momentum_account_update", full());
  }, resolverFor(account), Date.now(), "mine", rules);
  await engine.recoverStalePosition();
  reconcilePaperAccount(account);
  await saveAccounts(state);
  server.listen(config.port, () => {
    console.log(`[config] trigger=${config.entryTrigger} (${configSources.entryTrigger}) takeProfit=${config.takeProfit} (${configSources.takeProfit}) stopLossUsd=${config.stopLossUsd} (${configSources.stopLossUsd}) maxEntryPrice=${config.maxEntryPrice} (${configSources.maxEntryPrice}) tradeSizeUsd=${config.tradeSizeUsd} (${configSources.tradeSizeUsd}) slippageBps=${config.slippageBps} (${configSources.slippageBps}) feeRate=${config.feeRate}`);
    console.log(`Paper terminal server listening on http://localhost:${config.port}`);
  });
  const feed = new MarketFeed((next) => {
    btcReference.setWindow(next.windowStart, next.priceToBeat, next.priceToBeatSource);
    snapshot = btcReference.attach(next);
    priceTick();
  });
  void feed.connect();
};
void start();
