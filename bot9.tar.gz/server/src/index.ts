import express from "express";
import cors from "cors";
import { createServer } from "node:http";
import { join } from "node:path";
import { config } from "./config.js";
import { loadAccount, saveAccount, freshAccount } from "./store.js";
import { calculatePortfolioMetrics, reconcilePaperAccount } from "./math.js";
import { MarketFeed } from "./marketFeed.js";
import { EntryEngine } from "./entryEngine.js";
import { PaperExecutor } from "./paperExecutor.js";
import { lookupResolution } from "./settlement.js";
import type { MarketSnapshot, PaperAccount } from "./types.js";
import { createBasicAuth, requireProductionPassword } from "./auth.js";

requireProductionPassword();
const app = express();
app.use(cors());
app.use(express.json());
app.use(createBasicAuth(config.dashboardUser, config.dashboardPassword));
const server = createServer(app);
let account: PaperAccount;
let snapshot: MarketSnapshot = { windowId: "", windowStart: 0, windowEnd: 0, up: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, down: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, feedHealth: "DISCONNECTED", consistent: false, feedMessage: "No active market found" };
const clients = new Set<express.Response>();
let entryEngine: EntryEngine | undefined;
const broadcast = (type: string, payload: unknown) => { for (const client of clients) client.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`); };
const full = () => ({ account, snapshot, metrics: calculatePortfolioMetrics(account, snapshot), circuitBreakerHalted: entryEngine?.isCircuitBreakerHalted() ?? false, entryStatus: entryEngine?.getStatuses() ?? { UP: null, DOWN: null } });
app.get("/api/state", (_req, res) => res.json(full()));
app.post("/api/reset", async (req, res) => {
  const remote = req.ip?.replace("::ffff:", "");
  if (remote !== "127.0.0.1" && remote !== "::1") return res.status(403).json({ error: "local-only endpoint" });
  if (req.body?.confirm !== true) return res.status(400).json({ error: "confirm=true required" });
  account = freshAccount();
  reconcilePaperAccount(account);
  await saveAccount(account);
  broadcast("momentum_account_update", full());
  res.json(full());
});
app.get("/events", (req, res) => { res.setHeader("Content-Type", "text/event-stream"); res.setHeader("Cache-Control", "no-cache"); res.setHeader("Connection", "keep-alive"); res.flushHeaders(); clients.add(res); res.write(`event: momentum_account_update\ndata: ${JSON.stringify(full())}\n\n`); req.on("close", () => clients.delete(res)); });
const clientDist = join(process.cwd(), "client", "dist");
app.use(express.static(clientDist));
app.get("*", (_req, res) => res.sendFile(join(clientDist, "index.html")));
setInterval(() => {
  try { entryEngine?.tick(snapshot); }
  catch (error) { console.error(`[engine] tick loop error: ${error instanceof Error ? error.stack ?? error.message : String(error)}`); }
}, config.tickMs);
setInterval(() => {
  const stale = snapshot.feedHealth === "LIVE" && (Date.now() - Math.max(snapshot.up.lastUpdateTs, snapshot.down.lastUpdateTs) > 3000);
  if (stale) snapshot = { ...snapshot, feedHealth: "STALE", feedMessage: "WebSocket connected but no price update for 3 seconds" };
  broadcast("price_tick", { up: snapshot.up, down: snapshot.down, feedHealth: snapshot.feedHealth, feedMessage: snapshot.feedMessage, secondsRemaining: Math.max(0, snapshot.windowEnd - Date.now() / 1000), metrics: calculatePortfolioMetrics(account, snapshot), entryStatus: entryEngine?.getStatuses() });
}, 500);
setInterval(() => { for (const client of clients) client.write(": keep-alive\n\n"); }, 15000);
const start = async (): Promise<void> => {
  account = await loadAccount();
  const executor = new PaperExecutor(config);
  entryEngine = new EntryEngine(config, account, executor, () => {
    reconcilePaperAccount(account);
    void saveAccount(account);
    broadcast("momentum_account_update", full());
  }, async (position) => {
    const windowStart = position.windowStart ?? (position.windowId.startsWith("btc-updown-15m-") ? Number(position.windowId.slice("btc-updown-15m-".length)) : Math.floor(position.openedAt / 1000 / 900) * 900);
    return lookupResolution(windowStart);
  });
  await entryEngine.recoverStalePosition();
  reconcilePaperAccount(account);
  await saveAccount(account);
  server.listen(config.port, () => console.log(`Paper terminal server listening on http://localhost:${config.port}`));
  const feed = new MarketFeed((next) => {
    snapshot = next;
    broadcast("price_tick", { up: snapshot.up, down: snapshot.down, feedHealth: snapshot.feedHealth, feedMessage: snapshot.feedMessage, secondsRemaining: Math.max(0, snapshot.windowEnd - Date.now() / 1000), metrics: calculatePortfolioMetrics(account, snapshot), entryStatus: entryEngine?.getStatuses() });
  });
  void feed.connect();
};
void start();
