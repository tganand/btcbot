import { describe, expect, it } from "vitest";
import { freshAccount, saveAccount } from "./store.js";

describe("serialized persistence", () => {
  it("handles concurrent saves without rename races", async () => {
    await expect(Promise.all(Array.from({ length: 20 }, (_, index) => {
      const account = freshAccount();
      account.version = index;
      return saveAccount(account);
    }))).resolves.toHaveLength(20);
  });
});
