import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { dirname, join } from "node:path";
import type { PaperAccount } from "./types.js";
import { config } from "./config.js";
const statePath = join(process.cwd(), "data", "bot_state.json");
export const freshAccount = (): PaperAccount => ({ startingBalance: config.startingBalance, cashBalance: config.startingBalance, totalRealizedPnl: 0, openPosition: null, ledger: [], version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0, entriesThisWindow: {}, lastEntryExitByOutcome: {} });
export const loadAccount = async (): Promise<PaperAccount> => {
  try {
    const loaded = JSON.parse(await readFile(statePath, "utf8")) as Partial<PaperAccount>;
    return { ...freshAccount(), ...loaded, entriesThisWindow: loaded.entriesThisWindow ?? {}, lastEntryExitByOutcome: loaded.lastEntryExitByOutcome ?? {} };
  } catch { return freshAccount(); }
};
let saveQueue: Promise<void> = Promise.resolve();
export const saveAccount = async (account: PaperAccount): Promise<void> => {
  saveQueue = saveQueue.then(async () => {
    try {
      await mkdir(dirname(statePath), { recursive: true });
      const temp = `${statePath}.${randomUUID()}.tmp`;
      await writeFile(temp, JSON.stringify(account, null, 2), "utf8");
      await rename(temp, statePath);
    } catch (error) {
      console.error(`[store] save failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  });
  await saveQueue;
};
