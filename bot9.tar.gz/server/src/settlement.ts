import type { Outcome, Resolution } from "./types.js";

interface GammaMarket {
  outcomes?: string | string[];
  outcomePrices?: string | string[];
  closed?: boolean;
  resolved?: boolean;
}
interface GammaEvent {
  markets?: GammaMarket[];
  closed?: boolean;
  resolved?: boolean;
}

export const parseResolution = (payload: unknown): Resolution | null => {
  const event = Array.isArray(payload) ? payload[0] as GammaEvent | undefined : undefined;
  const market = event?.markets?.[0];
  if (!market || (market.closed !== true && market.resolved !== true && event?.closed !== true && event?.resolved !== true)) return null;
  const outcomes = parseList(market.outcomes);
  const prices = parseList(market.outcomePrices).map(Number);
  if (prices.length < 2 || !((prices[0] === 1 && prices[1] === 0) || (prices[0] === 0 && prices[1] === 1))) return null;
  const resolvedIndex = prices.findIndex((price) => price === 1);
  const label = outcomes[resolvedIndex]?.trim().toUpperCase();
  return label === "UP" || label === "DOWN" ? { outcome: label, price: 1 } : null;
};

const parseList = (value: string | string[] | undefined): string[] => {
  if (Array.isArray(value)) return value;
  if (!value) return [];
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
};

export const lookupResolution = async (windowStart: number): Promise<Resolution | null> => {
  const slug = `btc-updown-15m-${windowStart}`;
  const response = await fetch(`https://gamma-api.polymarket.com/events?slug=${encodeURIComponent(slug)}`);
  if (!response.ok) throw new Error(`Gamma resolution HTTP ${response.status}`);
  const payload: unknown = await response.json();
  return parseResolution(payload);
};
