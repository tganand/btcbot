# Polymarket BTC 15-minute Paper Terminal

This project is **paper-trading only**. It does not create real orders or use wallets or keys. One market feed drives two independent simulated accounts: **My rules** and **Claude's rules**. Each account keeps its own balance, ledger, position, entry rules, and paper-trading state. The state file is stored atomically under `DATA_DIR` (default: `data`); legacy single-account state is migrated into `accounts.mine`.

Paper fills include taker fees and simulated slippage. The fee is calculated per fill as:

```text
shares × FEE_RATE × price × (1 - price)
```

`FEE_RATE` defaults to `0.07`; fills also use a randomized 300–600 ms delay (`FILL_DELAY_MIN_MS` and `FILL_DELAY_MAX_MS`). `SLIPPAGE_BPS` controls simulated adverse slippage. Settlement is not charged a taker fee. **Verify the current fee model at [docs.polymarket.com/trading/fees](https://docs.polymarket.com/trading/fees)** before using the simulator to model costs.

## Run

```bash
npm install
copy .env.example .env
npm run build
npm start
```

Production serves the website, API, and SSE endpoint from one port (`PORT`, default `3001`). `npm run dev` starts the server and Vite client separately. `npm test` runs offline tests; persistence tests direct all reads and writes to a temporary directory rather than the real `data` folder.

The website, API, reset endpoints, and SSE stream use HTTP Basic Auth. Set `DASH_USER` and `DASH_PASSWORD` in `.env`. In production (`NODE_ENV=production`), the server refuses to start unless `DASH_PASSWORD` is set:

```env
DASH_USER=admin
DASH_PASSWORD=use-a-long-random-password
PORT=3001
FEE_RATE=0.07
SLIPPAGE_BPS=50
FILL_DELAY_MIN_MS=300
FILL_DELAY_MAX_MS=600
MAX_TRADE_SIZE_USD=25
```

The Mine rules can be edited in the dashboard and apply only to new entries. Claude's rules are read-only. CSV exports and account resets are available per paper account.
