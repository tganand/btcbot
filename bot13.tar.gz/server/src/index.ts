import express from "express";
import cors from "cors";
import { createServer } from "node:http";
import { join } from "node:path";
import { config, configSources, defaultAccountRules, validateMineRules } from "./config.js";
import { freshAccount, loadAccounts, saveAccounts, resetOneAccountState } from "./store.js";
import { buildTradesCsv, calculatePortfolioMetrics, reconcilePaperAccount } from "./math.js";
import { MarketFeed } from "./marketFeed.js";
import { EntryEngine } from "./entryEngine.js";
import { PaperExecutor } from "./paperExecutor.js";
import { lookupResolution } from "./settlement.js";
import type { AccountId, AccountRules, MarketSnapshot, PaperAccount, PaperAccountsState } from "./types.js";
import { createBasicAuth, requireProductionPassword } from "./auth.js";

requireProductionPassword();
const app = express();
app.use(cors());
app.use(express.json());
app.use(createBasicAuth(config.dashboardUser, config.dashboardPassword));
const server = createServer(app);
let state: PaperAccountsState = { accounts: { mine: freshAccount(), claude: freshAccount() } };
let snapshot: MarketSnapshot = { windowId: "", windowStart: 0, windowEnd: 0, windowTitle: "Waiting for next window", serverNow: Date.now(), up: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, down: { bid: 0, ask: 0, bidSize: 0, askSize: 0, lastUpdateTs: 0 }, feedHealth: "DISCONNECTED", consistent: false, feedMessage: "No active market found" };
const clients = new Set<express.Response>();
const ids: AccountId[] = ["mine", "claude"];
const engines: Partial<Record<AccountId, EntryEngine>> = {};
const names: Record<AccountId, string> = { mine: "My rules", claude: "Claude's rules" };
const broadcast = (type: string, payload: unknown) => { for (const client of clients) client.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`); };
const metricsByAccount = () => Object.fromEntries(ids.map((id) => [id, calculatePortfolioMetrics(state.accounts[id], snapshot, config.feeRate)]));
const entryStatusByAccount = () => Object.fromEntries(ids.map((id) => [id, engines[id]?.getStatuses() ?? { UP: null, DOWN: null }]));
const liveUnrealizedPnlByAccount = () => Object.fromEntries(ids.map((id) => [id, calculatePortfolioMetrics(state.accounts[id], snapshot, config.feeRate).unrealizedPnl]));
const full = () => {
  const metrics = metricsByAccount();
  const entryStatuses = entryStatusByAccount();
  const accounts = Object.fromEntries(ids.map((id) => [id, { id, name: names[id], ...state.accounts[id], rules: engines[id]?.rules ?? state.accounts[id].rules ?? defaultAccountRules(id), circuitBreakerHalted: engines[id]?.isCircuitBreakerHalted() ?? false, entryStatus: entryStatuses[id], pendingOrder: engines[id]?.getPendingOrder() ?? null }]));
  return {
    accounts,
    metricsByAccount: metrics,
    account: state.accounts.mine,
    snapshot,
    metrics: metrics.mine,
    config: { entryTrigger: config.entryTrigger, takeProfit: config.takeProfit, stopLossUsd: config.stopLossUsd, maxEntryPrice: config.maxEntryPrice, tradeSizeUsd: config.tradeSizeUsd, maxTradeSizeUsd: config.maxTradeSizeUsd, slippageBps: config.slippageBps, feeRate: config.feeRate, sources: configSources },
    circuitBreakerHalted: engines.mine?.isCircuitBreakerHalted() ?? false,
    entryStatus: entryStatuses.mine
  };
};
app.get("/api/state", (_req, res) => res.json(full()));
app.get("/api/accounts/:id/rules", (req, res) => {
  if (req.params.id !== "mine") { res.status(404).json({ error: "Rules are only editable for mine" }); return; }
  res.json({ rules: engines.mine?.rules ?? state.accounts.mine.rules ?? defaultAccountRules("mine"), rulesVersion: state.accounts.mine.rulesVersion ?? 1, history: state.accounts.mine.rulesHistory ?? [] });
});
app.put("/api/accounts/mine/rules", async (req, res) => {
  if (req.body?.confirm !== true) { res.status(400).json({ error: "confirm=true required" }); return; }
  const validation = validateMineRules(req.body, defaultAccountRules("mine").minSecondsRemaining, config.maxTradeSizeUsd);
  if ("error" in validation) { res.status(400).json({ error: validation.error }); return; }
  const rules: AccountRules = { ...(engines.mine?.rules ?? defaultAccountRules("mine")), ...validation.rules };
  const account = state.accounts.mine;
  const version = (account.rulesVersion ?? 1) + 1;
  account.rules = { ...rules };
  account.rulesVersion = version;
  account.rulesHistory = [...(account.rulesHistory ?? []), { version, timestamp: Date.now(), rules: { ...rules } }].slice(-50);
  if (engines.mine) engines.mine.rules = { ...rules };
  reconcilePaperAccount(account);
  await saveAccounts(state);
  broadcast("momentum_account_update", full());
  res.json({ rules: account.rules, rulesVersion: version, history: account.rulesHistory });
});
app.get("/api/accounts/:id/trades.csv", (req, res) => {
  if (!ids.includes(req.params.id as AccountId)) { res.status(404).json({ error: "Unknown account" }); return; }
  const account = state.accounts[req.params.id as AccountId];
  const csv = buildTradesCsv(account.ledger);
  res.type("text/csv").setHeader("Content-Disposition", `attachment; filename="${req.params.id}-trades.csv"`);
  res.send(csv);
});
const resetAccount = async (id: AccountId, res: express.Response): Promise<void> => {
  try {
    await resetOneAccountState(state, id);
    engines[id]?.cancelPendingOrder("account reset");
    state.accounts[id].rules = defaultAccountRules(id);
    state.accounts[id].rulesVersion = 1;
    state.accounts[id].rulesHistory = [];
    if (engines[id]) engines[id]!.rules = defaultAccountRules(id);
    for (const accountId of ids) reconcilePaperAccount(state.accounts[accountId]);
    await saveAccounts(state);
    broadcast("momentum_account_update", full());
    res.json(full());
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message === "Close the open trade first") { res.status(409).json({ error: message }); return; }
    console.error(`[${id}][store] reset archive failed: ${message}`);
    res.status(500).json({ error: "Unable to archive current account" });
  }
};
app.post("/api/reset", async (req, res) => {
  if (req.body?.confirm !== true) { res.status(400).json({ error: "confirm=true required" }); return; }
  await resetAccount("mine", res);
});
app.post("/api/accounts/:id/reset", async (req, res) => {
  if (req.body?.confirm !== true) { res.status(400).json({ error: "confirm=true required" }); return; }
  if (!ids.includes(req.params.id as AccountId)) { res.status(404).json({ error: "Unknown account" }); return; }
  await resetAccount(req.params.id as AccountId, res);
});
app.get("/events", (req, res) => { res.setHeader("Content-Type", "text/event-stream"); res.setHeader("Cache-Control", "no-cache"); res.setHeader("Connection", "keep-alive"); res.flushHeaders(); clients.add(res); res.write(`event: momentum_account_update\ndata: ${JSON.stringify(full())}\n\n`); req.on("close", () => clients.delete(res)); });
const clientDist = join(process.cwd(), "client", "dist");
app.use(express.static(clientDist, { setHeaders: (res, filePath) => { if (filePath.endsWith("\\index.html") || filePath.endsWith("/index.html")) res.setHeader("Cache-Control", "no-store"); else if (filePath.includes("\\assets\\") || filePath.includes("/assets/")) res.setHeader("Cache-Control", "public, max-age=31536000, immutable"); } }));
app.get("*", (_req, res) => { res.setHeader("Cache-Control", "no-store"); res.sendFile(join(clientDist, "index.html")); });
setInterval(() => {
  try { for (const id of ids) engines[id]?.tick(snapshot); }
  catch (error) { console.error(`[engine] tick loop error: ${error instanceof Error ? error.stack ?? error.message : String(error)}`); }
}, config.tickMs);
const priceTick = () => {
  snapshot = { ...snapshot, serverNow: Date.now() };
  const stale = snapshot.feedHealth === "LIVE" && (Date.now() - Math.max(snapshot.up.lastUpdateTs, snapshot.down.lastUpdateTs) > 3000);
  if (stale) snapshot = { ...snapshot, feedHealth: "STALE", feedMessage: "WebSocket connected but no price update for 3 seconds" };
  const metrics = metricsByAccount();
  const entryStatuses = entryStatusByAccount();
  broadcast("price_tick", {
    up: snapshot.up, down: snapshot.down, feedHealth: snapshot.feedHealth, feedMessage: snapshot.feedMessage,
    windowId: snapshot.windowId, windowStart: snapshot.windowStart, windowEnd: snapshot.windowEnd,
    windowTitle: snapshot.windowTitle, serverNow: snapshot.serverNow,
    secondsRemaining: Math.max(0, snapshot.windowEnd - Date.now() / 1000),
    metrics: metrics.mine, entryStatus: entryStatuses.mine,
    entryStatusByAccount: entryStatuses, liveUnrealizedPnlByAccount: liveUnrealizedPnlByAccount(), metricsByAccount: metrics
  });
};
setInterval(priceTick, 500);
setInterval(() => { for (const client of clients) client.write(": keep-alive\n\n"); }, 15000);
const resolverFor = (account: PaperAccount) => async (position: NonNullable<PaperAccount["openPosition"]>) => {
  const windowStart = position.windowStart ?? (position.windowId.startsWith("btc-updown-15m-") ? Number(position.windowId.slice("btc-updown-15m-".length)) : Math.floor(position.openedAt / 1000 / 900) * 900);
  return lookupResolution(windowStart);
};
const start = async (): Promise<void> => {
  state = await loadAccounts();
  for (const id of ids) {
    const account = state.accounts[id];
    console.info(`[${id}][engine] pending orders are memory-only; none restored`);
    const rules = account.rules ?? defaultAccountRules(id);
    account.rules = rules;
    account.rulesVersion ??= 1;
    engines[id] = new EntryEngine(config, account, new PaperExecutor(config), () => {
      reconcilePaperAccount(account);
      void saveAccounts(state);
      broadcast("momentum_account_update", full());
    }, resolverFor(account), Date.now(), id, rules);
    await engines[id]?.recoverStalePosition();
    reconcilePaperAccount(account);
  }
  await saveAccounts(state);
  server.listen(config.port, () => {
    console.log(`[config] trigger=${config.entryTrigger} (${configSources.entryTrigger}) takeProfit=${config.takeProfit} (${configSources.takeProfit}) stopLossUsd=${config.stopLossUsd} (${configSources.stopLossUsd}) maxEntryPrice=${config.maxEntryPrice} (${configSources.maxEntryPrice}) tradeSizeUsd=${config.tradeSizeUsd} (${configSources.tradeSizeUsd}) slippageBps=${config.slippageBps} (${configSources.slippageBps}) feeRate=${config.feeRate}`);
    console.log(`Paper terminal server listening on http://localhost:${config.port}`);
  });
  const feed = new MarketFeed((next) => {
    snapshot = next;
    priceTick();
  });
  void feed.connect();
};
void start();
