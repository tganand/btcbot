import "dotenv/config";
import { join } from "node:path";
import type { AccountId, AccountRules } from "./types.js";

const num = (name: string, fallback: number): number => {
  const value = Number(process.env[name]);
  return Number.isFinite(value) ? value : fallback;
};
const source = (name: string): "env" | "default" => process.env[name] !== undefined && process.env[name] !== "" ? "env" : "default";

export const config = {
  dataDir: process.env.DATA_DIR || join(process.cwd(), "data"),
  port: num("PORT", 3001),
  startingBalance: num("STARTING_BALANCE", 100),
  entryTrigger: num("ENTRY_TRIGGER_PRICE", 0.91),
  maxEntryPrice: num("MAX_ENTRY_PRICE", 0.95),
  circuitBreakerLossLimit: num("CIRCUIT_BREAKER_LOSS_LIMIT", 15),
  entryHoldMs: num("ENTRY_HOLD_MS", 400),
  minSecondsRemaining: num("MIN_SECONDS_REMAINING", 90),
  tradeSizeUsd: num("TRADE_SIZE_USD", 10),
  takeProfit: num("TAKE_PROFIT_PRICE", 0.99),
  stopLossUsd: num("STOP_LOSS_USD", 1.5),
  reversalPrice: num("REVERSAL_OPPOSITE_PRICE", 0.35),
  slippageBps: num("SLIPPAGE_BPS", 50),
  feeRate: num("FEE_RATE", 0.07),
  fillDelayMinMs: num("FILL_DELAY_MIN_MS", 300),
  fillDelayMaxMs: num("FILL_DELAY_MAX_MS", 600),
  maxTradeSizeUsd: num("MAX_TRADE_SIZE_USD", 25),
  maxOpenPositions: num("MAX_OPEN_POSITIONS", 1),
  tickMs: num("ENGINE_TICK_MS", 25),
  dashboardUser: process.env.DASH_USER || "admin",
  dashboardPassword: process.env.DASH_PASSWORD || ""
} as const;
export const configSources = {
  entryTrigger: source("ENTRY_TRIGGER_PRICE"),
  takeProfit: source("TAKE_PROFIT_PRICE"),
  stopLossUsd: source("STOP_LOSS_USD"),
  maxEntryPrice: source("MAX_ENTRY_PRICE"),
  tradeSizeUsd: source("TRADE_SIZE_USD"),
  slippageBps: source("SLIPPAGE_BPS")
} as const;

export type EngineConfig = typeof config;

export const defaultAccountRules = (id: AccountId): AccountRules => id === "mine" ? {
  entryMin: 0.91, entryMax: 0.95, holdMs: 400, target: 0.99, stopLossUsd: 1.5,
  reversalPrice: 0.35, tradeSizeUsd: 10, maxSecondsRemaining: 480,
  minSecondsRemaining: 90, oneTradePerWindow: true
} : {
  entryMin: 0.86, entryMax: 0.92, holdMs: 400, target: 0.98, stopLossUsd: 0.1,
  reversalPrice: 0.35, tradeSizeUsd: 10, maxSecondsRemaining: 480,
  minSecondsRemaining: 120, oneTradePerWindow: true, thinBookCheck: true,
  emptyBookSafety: true, dailyLossLimit: -5, dailyProfitLock: 20
};

export type EditableMineRules = Pick<AccountRules, "entryMin" | "entryMax" | "target" | "stopLossUsd" | "tradeSizeUsd" | "maxSecondsRemaining">;
export const validateMineRules = (input: unknown, minSecondsRemaining: number, maxTradeSizeUsd: number): { rules: EditableMineRules } | { error: string } => {
  if (!input || typeof input !== "object" || Array.isArray(input)) return { error: "Rules must be an object" };
  const values = input as Record<string, unknown>;
  const { entryMin, entryMax, target, stopLossUsd, tradeSizeUsd, maxSecondsRemaining } = values;
  const isFiniteNumber = (value: unknown): value is number => typeof value === "number" && Number.isFinite(value);
  if (!isFiniteNumber(entryMin) || !isFiniteNumber(entryMax) || !isFiniteNumber(target) || !isFiniteNumber(stopLossUsd) || !isFiniteNumber(tradeSizeUsd) || !isFiniteNumber(maxSecondsRemaining)) {
    return { error: "All editable rule fields must be finite numbers" };
  }
  const rules: EditableMineRules = {
    entryMin, entryMax, target, stopLossUsd, tradeSizeUsd, maxSecondsRemaining
  };
  if (rules.entryMin < 0.5 || rules.entryMin >= rules.entryMax || rules.entryMax > 0.97) return { error: "Require 0.50 <= entryMin < entryMax <= 0.97" };
  if (rules.entryMax >= rules.target || rules.target > 0.99) return { error: "Require entryMax < target <= 0.99" };
  if (rules.tradeSizeUsd < 1 || rules.tradeSizeUsd > maxTradeSizeUsd || rules.stopLossUsd < 0.25 || rules.stopLossUsd > rules.tradeSizeUsd) {
    return { error: `Require 1 <= tradeSizeUsd <= ${maxTradeSizeUsd} and 0.25 <= stopLossUsd <= tradeSizeUsd` };
  }
  if (rules.maxSecondsRemaining < 60 || rules.maxSecondsRemaining > 840 || rules.maxSecondsRemaining <= minSecondsRemaining) return { error: `Require ${minSecondsRemaining} < maxSecondsRemaining <= 840` };
  return { rules };
};
