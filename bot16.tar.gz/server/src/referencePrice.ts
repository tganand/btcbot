import type { MarketSnapshot } from "./types.js";

export type SpotSource = "coinbase" | "kraken";
export type BeatSource = "polymarket" | "approx";

export interface ReferencePrices {
  btcPrice: number | null;
  btcPriceSource: SpotSource | null;
  priceToBeat: number | null;
  priceToBeatSource: BeatSource | null;
}

type Fetcher = (url: string, init?: RequestInit) => Promise<Response>;

const coinbaseUrl = "https://api.exchange.coinbase.com/products/BTC-USD/ticker";
const krakenUrl = "https://api.kraken.com/0/public/Ticker?pair=XBTUSD";

const validPrice = (value: unknown): number | null => {
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
};

export const parseCoinbaseSpot = (payload: unknown): number | null => {
  if (!payload || typeof payload !== "object") return null;
  return validPrice((payload as Record<string, unknown>).price);
};

export const parseKrakenSpot = (payload: unknown): number | null => {
  if (!payload || typeof payload !== "object") return null;
  const result = (payload as Record<string, unknown>).result;
  if (!result || typeof result !== "object") return null;
  const ticker = Object.values(result).find((value) => value && typeof value === "object");
  if (!ticker || typeof ticker !== "object") return null;
  const close = (ticker as Record<string, unknown>).c;
  return Array.isArray(close) ? validPrice(close[0]) : null;
};

export class BtcReferencePrice {
  private readonly now: () => number;
  private readonly fetcher: Fetcher;
  private readonly log: (message: string) => void;
  private inFlight = false;
  private lastUnavailableLogAt = 0;
  private windowStart = 0;
  private approxRecordedForWindow = 0;
  private values: ReferencePrices = {
    btcPrice: null,
    btcPriceSource: null,
    priceToBeat: null,
    priceToBeatSource: null
  };

  public constructor(options: { now?: () => number; fetcher?: Fetcher; log?: (message: string) => void } = {}) {
    this.now = options.now ?? Date.now;
    this.fetcher = options.fetcher ?? fetch;
    this.log = options.log ?? console.warn;
  }

  public setWindow(windowStart: number, priceToBeat?: number | null, source?: BeatSource | null): void {
    if (windowStart !== this.windowStart) {
      this.windowStart = windowStart;
      this.approxRecordedForWindow = 0;
      this.values.priceToBeat = null;
      this.values.priceToBeatSource = null;
    }
    if (source === "polymarket" && validPrice(priceToBeat) !== null) {
      this.values.priceToBeat = priceToBeat!;
      this.values.priceToBeatSource = "polymarket";
      this.approxRecordedForWindow = windowStart;
    }
  }

  public getValues(): ReferencePrices {
    return { ...this.values };
  }

  public attach(snapshot: MarketSnapshot): MarketSnapshot {
    return { ...snapshot, ...this.values };
  }

  public async refresh(snapshot: MarketSnapshot): Promise<ReferencePrices> {
    try {
      this.setWindow(snapshot.windowStart, snapshot.priceToBeat, snapshot.priceToBeatSource);
    } catch (error) {
      try { this.log(`[reference] window update failed: ${error instanceof Error ? error.message : String(error)}`); } catch { /* display-only failure */ }
    }
    if (this.inFlight) return this.getValues();
    this.inFlight = true;
    try {
      let price: number | null;
      let source: SpotSource | null;
      try {
        price = await this.fetchSpot(coinbaseUrl, parseCoinbaseSpot);
        if (price === null) throw new Error("invalid Coinbase ticker");
        source = "coinbase";
      } catch {
        try {
          price = await this.fetchSpot(krakenUrl, parseKrakenSpot);
          source = price === null ? null : "kraken";
        } catch {
          price = null;
          source = null;
        }
      }
      this.values.btcPrice = price;
      this.values.btcPriceSource = source;
      const now = this.now();
      if (price === null && now - this.lastUnavailableLogAt >= 60_000) {
        this.lastUnavailableLogAt = now;
        try { this.log("[reference] BTC spot unavailable from Coinbase and Kraken"); } catch { /* display-only failure */ }
      }
      if (
        price !== null && this.windowStart > 0 &&
        now >= this.windowStart * 1000 && now < (this.windowStart + 3600) * 1000 &&
        this.approxRecordedForWindow !== this.windowStart &&
        this.values.priceToBeatSource !== "polymarket"
      ) {
        this.values.priceToBeat = price;
        this.values.priceToBeatSource = "approx";
        this.approxRecordedForWindow = this.windowStart;
      }
      return this.getValues();
    } catch (error) {
      this.values.btcPrice = null;
      this.values.btcPriceSource = null;
      try { this.log(`[reference] BTC price unavailable: ${error instanceof Error ? error.message : String(error)}`); } catch { /* display-only failure */ }
      return this.getValues();
    } finally {
      this.inFlight = false;
    }
  }

  private async fetchSpot(url: string, parse: (payload: unknown) => number | null): Promise<number | null> {
    const response = await this.fetcher(url, { signal: AbortSignal.timeout(2500) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return parse(await response.json());
  }
}
