import { copyFile, mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { dirname, join } from "node:path";
import type { AccountRules, PaperAccount, PaperAccountsState } from "./types.js";
import { config, defaultAccountRules } from "./config.js";
export const statePath = join(config.dataDir, "bot_state.json");
export const archiveDir = join(config.dataDir, "archive");
export const archiveAccountState = async (): Promise<string> => {
  await mkdir(archiveDir, { recursive: true });
  const archivePath = join(archiveDir, `bot_state-${new Date().toISOString().replace(/[:.]/g, "-")}.json`);
  await copyFile(statePath, archivePath);
  return archivePath;
};
export const resetAccountState = async (account: PaperAccount): Promise<PaperAccount> => {
  if (account.openPosition) throw new Error("Close the open trade first");
  await archiveAccountState();
  Object.assign(account, freshAccount());
  return account;
};
export const freshAccount = (): PaperAccount => ({ startingBalance: config.startingBalance, cashBalance: config.startingBalance, totalRealizedPnl: 0, openPosition: null, ledger: [], version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0, entriesThisWindow: {}, lastEntryExitByOutcome: {}, postExitTracking: {}, dailyPnl: {}, missedFillCount: 0, missedFillsByRulesVersion: {}, entryAttemptsThisWindow: {} });
const normalizeAccount = (input: Partial<PaperAccount> | undefined): PaperAccount => {
  const raw = input as (Partial<PaperAccount> & { pendingOrder?: unknown }) | undefined;
  if (raw?.pendingOrder) console.info("[store] dropping non-persistent pending order from saved account");
  const account = { ...freshAccount(), ...(input ?? {}) };
  delete (account as PaperAccount & { pendingOrder?: unknown }).pendingOrder;
  account.ledger = (input?.ledger ?? []).map((fill) => ({
    ...fill,
    id: fill.id ?? randomUUID(),
    timestamp: fill.timestamp ?? 0,
    windowId: fill.windowId ?? "",
    fee: fill.fee ?? 0,
    slippage: fill.slippage ?? 0
  }));
  account.entriesThisWindow = account.entriesThisWindow ?? {};
  account.lastEntryExitByOutcome = account.lastEntryExitByOutcome ?? {};
  account.postExitTracking = account.postExitTracking ?? {};
  account.missedFillCount = account.missedFillCount ?? 0;
  account.missedFillsByRulesVersion = account.missedFillsByRulesVersion ?? {};
  account.entryAttemptsThisWindow = account.entryAttemptsThisWindow ?? {};
  if (account.rules) {
    const previousDefaults = {
      entryMin: 0.91,
      entryMax: 0.95,
      holdMs: 400,
      target: 0.99,
      stopLossUsd: 1.5,
      reversalPrice: 0.35,
      tradeSizeUsd: 10,
      maxSecondsRemaining: 480,
      minSecondsRemaining: 90,
      oneTradePerWindow: true
    };
    const updated: AccountRules = {
      ...account.rules,
      entryMin: account.rules.entryMin === previousDefaults.entryMin ? 0.93 : account.rules.entryMin,
      stopLossUsd: account.rules.stopLossUsd === previousDefaults.stopLossUsd ? 10 : account.rules.stopLossUsd,
      tradeSizeUsd: account.rules.tradeSizeUsd === previousDefaults.tradeSizeUsd ? 100 : account.rules.tradeSizeUsd,
      maxSecondsRemaining: account.rules.maxSecondsRemaining === previousDefaults.maxSecondsRemaining
        ? 3600
        : account.rules.maxSecondsRemaining
    };
    const changed = updated.entryMin !== account.rules.entryMin
      || updated.stopLossUsd !== account.rules.stopLossUsd
      || updated.tradeSizeUsd !== account.rules.tradeSizeUsd
      || updated.maxSecondsRemaining !== account.rules.maxSecondsRemaining;
    if (changed) {
      account.rules = updated;
      account.rulesVersion = (account.rulesVersion ?? 1) + 1;
      account.rulesHistory = [...(account.rulesHistory ?? []), {
        version: account.rulesVersion,
        timestamp: Date.now(),
        rules: { ...updated }
      }].slice(-50);
    }
  }
  return account;
};
export const freshAccounts = (): PaperAccountsState => ({ accounts: { mine: freshAccount() } });
export const loadAccounts = async (): Promise<PaperAccountsState> => {
  try {
    const loaded = JSON.parse(await readFile(statePath, "utf8")) as Partial<PaperAccountsState> & Partial<PaperAccount>;
    if (loaded.accounts && typeof loaded.accounts === "object") {
      return { accounts: { mine: normalizeAccount(loaded.accounts.mine) } };
    }
    return { accounts: { mine: normalizeAccount(loaded) } };
  } catch { return freshAccounts(); }
};
let saveQueue: Promise<void> = Promise.resolve();
export const saveAccounts = async (accounts: PaperAccountsState): Promise<void> => {
  saveQueue = saveQueue.then(async () => {
    try {
      await mkdir(dirname(statePath), { recursive: true });
      const temp = `${statePath}.${randomUUID()}.tmp`;
      await writeFile(temp, JSON.stringify(accounts, null, 2), "utf8");
      await rename(temp, statePath);
    } catch (error) {
      console.error(`[store] save failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  });
  await saveQueue;
};
export const loadAccount = async (): Promise<PaperAccount> => (await loadAccounts()).accounts.mine;
export const saveAccount = async (account: PaperAccount): Promise<void> => saveAccounts({ accounts: { mine: account } });

export const resetOneAccountState = async (accounts: PaperAccountsState): Promise<void> => {
  const account = accounts.accounts.mine;
  if (account.openPosition) throw new Error("Close the open trade first");
  await archiveAccountState();
  Object.assign(account, freshAccount());
};
