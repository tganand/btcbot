# Polymarket Bitcoin Hourly + 4-Hour Paper Terminal

This project is **paper-trading only**. It does not create real orders or use wallets or keys. It runs independent hourly (**My rules**) and 4-hour paper accounts, each with its own position, ledger, and metrics. The state file is stored atomically under `DATA_DIR` (default: `data`). Legacy single-account state and Mine from the previous multi-account format are migrated with the Mine ledger preserved; any old Claude account is discarded.

The hourly bot uses Polymarket's Bitcoin hourly Up/Down market and a 3,600-second `America/New_York` window. Mine starts with $100 and defaults to entry range 93¢–95¢, a 99¢ target, a $10 stop loss, and a $100 trade budget. `MAX_TRADE_SIZE_USD` caps editable Mine trade size (default $100).

The independent 4-hour bot uses the `btc-updown-4h-<window-start-unix>` Gamma market and ET clock boundaries at midnight, 4 AM, 8 AM, noon, 4 PM, and 8 PM. Its default rules require either side to remain in the 91¢–93¢ band for more than five minutes, then paper-buy $150 worth and hold to resolution (or sell at 1.00). It has no stop loss and starts with $200 to cover the stake and fees. Both accounts include fees and simulated slippage in their own accounting; an undersized ask is skipped rather than partially filled.

Paper fills include taker fees and simulated slippage. The fee is calculated per fill as:

```text
shares × FEE_RATE × price × (1 - price)
```

`FEE_RATE` defaults to `0.07`; fills also use a randomized 300–600 ms delay (`FILL_DELAY_MIN_MS` and `FILL_DELAY_MAX_MS`). `SLIPPAGE_BPS` controls simulated adverse slippage. Settlement is not charged a taker fee. **Verify the current fee model at [docs.polymarket.com/trading/fees](https://docs.polymarket.com/trading/fees)** before using the simulator to model costs.

## Run

```bash
npm install
copy .env.example .env
npm run build
npm start
```

Production serves the website, API, and SSE endpoint from one port (`PORT`, default `3001`). `npm run dev` starts the server and Vite client separately. `npm test` runs offline tests; persistence tests direct all reads and writes to a temporary directory rather than the real `data` folder.

The website, API, reset endpoints, and SSE stream use HTTP Basic Auth. Set `DASH_USER` and `DASH_PASSWORD` in `.env`. In production (`NODE_ENV=production`), the server refuses to start unless `DASH_PASSWORD` is set:

```env
DASH_USER=admin
DASH_PASSWORD=use-a-long-random-password
PORT=3001
FEE_RATE=0.07
SLIPPAGE_BPS=50
FILL_DELAY_MIN_MS=300
FILL_DELAY_MAX_MS=600
MAX_TRADE_SIZE_USD=100
```

Mine's editable rules apply only to new entries; the 4-hour rules are fixed in server configuration. Each account has its own CSV export and reset.

## BTC reference price

The display-only BTC reference uses Polymarket's `crypto_prices_chainlink` live-data WebSocket (`btc/usd`) when its timestamp is within five seconds. Stale or unavailable stream data falls back to Coinbase BTC-USD, then Kraken XBT/USD. The source appears beside the current price; none of these prices affect paper trading decisions.

## Price recorder

The optional price recorders watch the same active market snapshots as their respective paper accounts and write one NDJSON quote line per second, plus a result line after Gamma reports the settled winner. Hourly records include `"marketType":"1h"` and 4-hour records include `"marketType":"4h"`. The 4-hour recorder writes under `PRICES_DIR/4h`; the hourly recorder uses `PRICES_DIR` directly. Files are organized by UTC hour and completed hours are gzip-compressed. Existing hourly and 15-minute files are not moved or modified by the 4-hour recorder. Recording never places orders or changes account state.

```env
PRICE_RECORDING=true
PRICES_DIR=data/prices
MAX_PRICES_MB=500
FEE_RATE=0.07
ENTRY_TRIGGER_PRICE=0.93
TRADE_SIZE_USD=100
STOP_LOSS_USD=10
MAX_TRADE_SIZE_USD=100
SLIPPAGE_BPS=50
FILL_DELAY_MIN_MS=300
FILL_DELAY_MAX_MS=600
```

Set `PRICE_RECORDING=false` to disable both recorders. `PRICES_DIR` selects the parent output folder, and recording stops if a recorder's files exceed `MAX_PRICES_MB`. The authenticated `GET /api/recording/status` and `GET /api/four-hour/recording/status` endpoints report each recorder's health and storage usage.
