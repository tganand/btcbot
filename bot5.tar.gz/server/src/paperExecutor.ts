import { randomUUID } from "node:crypto";
import type { EngineConfig } from "./config.js";
import type { LedgerFill, Outcome, PaperAccount } from "./types.js";

export class PaperExecutor {
  public constructor(private readonly config: EngineConfig) {}
  public buy(account: PaperAccount, windowId: string, outcome: Outcome, ask: number, now: number): LedgerFill | null {
    if (!Number.isFinite(ask) || ask <= 0 || ask >= 1) return null;
    const shares = this.config.tradeSizeUsd / (ask * (1 + this.config.slippageBps / 10000));
    const fillPrice = this.config.tradeSizeUsd / shares;
    if (fillPrice < 0.01 || fillPrice > 0.99) return null;
    const fee = this.config.tradeSizeUsd * this.config.feeBps / 10000;
    const fill: LedgerFill = { id: randomUUID(), timestamp: now, windowId, side: "BUY", outcome, price: fillPrice, shares, usd: this.config.tradeSizeUsd, fee, slippage: fillPrice - ask, reason: "ENTRY" };
    account.ledger.push(fill);
    return fill;
  }
  public sell(account: PaperAccount, windowId: string, outcome: Outcome, shares: number, intendedPrice: number, reason: string, now: number): LedgerFill {
    const price = intendedPrice * (1 - this.config.slippageBps / 10000);
    const usd = shares * price;
    const fee = usd * this.config.feeBps / 10000;
    const fill: LedgerFill = { id: randomUUID(), timestamp: now, windowId, side: "SELL", outcome, price, shares, usd, fee, slippage: intendedPrice - price, reason };
    account.ledger.push(fill);
    return fill;
  }
  public settle(account: PaperAccount, windowId: string, outcome: Outcome, shares: number, settlementPrice: number, reason: string, now: number): LedgerFill {
    const usd = shares * settlementPrice;
    const fee = usd * this.config.feeBps / 10000;
    const fill: LedgerFill = { id: randomUUID(), timestamp: now, windowId, side: "SELL", outcome, price: settlementPrice, shares, usd, fee, slippage: 0, reason };
    account.ledger.push(fill);
    return fill;
  }
}
