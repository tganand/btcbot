import { describe, expect, it } from "vitest";
import { EntryEngine } from "./entryEngine.js";
import { config } from "./config.js";
import { PaperExecutor } from "./paperExecutor.js";
import type { MarketSnapshot, PaperAccount } from "./types.js";

const account = (): PaperAccount => ({ startingBalance: 100, cashBalance: 100, totalRealizedPnl: 0, openPosition: null, ledger: [], version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0, entriesThisWindow: {}, lastEntryExitByOutcome: {} });
const snapshot = (secondsRemaining: number): MarketSnapshot => ({
  windowId: "w",
  windowStart: 0,
  windowEnd: secondsRemaining,
  up: { bid: 0.94, ask: 0.94, bidSize: 10, askSize: 20, lastUpdateTs: 1000 },
  down: { bid: 0.04, ask: 0.05, bidSize: 20, askSize: 20, lastUpdateTs: 1000 },
  feedHealth: "LIVE",
  consistent: true,
  feedMessage: "Live prices flowing"
});

describe("entry visibility and decisions", () => {
  it("buys after a held trigger with time and liquidity", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(113), 0);
    engine.tick(snapshot(113), 1000);
    expect(paper.ledger).toHaveLength(1);
    expect(paper.ledger[0]?.outcome).toBe("UP");
  });
  it("blocks an otherwise eligible entry when too late", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(80), 0);
    engine.tick(snapshot(80), 1000);
    expect(paper.ledger).toHaveLength(0);
    expect(engine.getStatuses().UP.decision).toBe("TOO_LATE");
  });
  it("takes profit from bid without ask liquidity or reconciliation", () => {
    const paper = account();
    paper.cashBalance = 90;
    paper.reconciliationStatus = "MISMATCH";
    paper.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.windowId = "old";
    current.down = { bid: 0.99, ask: 1, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 1000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("TAKE_PROFIT");
  });
  it("settles an older position at resolved 1.00 or 0.00", async () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    engine.tick({ ...snapshot(100), windowId: "new" }, 1000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.price).toBe(1);
    const second = account();
    second.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const secondEngine = new EntryEngine(config, second, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    secondEngine.tick({ ...snapshot(100), windowId: "new" }, 1000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(second.openPosition).toBeNull();
    expect(second.ledger.at(-1)?.price).toBe(0);
  });
  it("recovers a stale startup position", async () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "DOWN", price: 0 }), 0);
    await engine.recoverStalePosition(1000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("SETTLEMENT");
  });
  it("blocks an ask above the configured maximum", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(113);
    current.up.ask = 0.975;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(paper.openPosition).toBeNull();
    expect(engine.getStatuses().UP.decision).toBe("ABOVE_MAX_ENTRY");
  });
  it("blocks the failing empty-ask and 99c cases", () => {
    const empty = account();
    const emptyEngine = new EntryEngine(config, empty, new PaperExecutor(config), () => undefined, async () => null, 0);
    const emptySnapshot = snapshot(113);
    emptySnapshot.up.ask = 1;
    emptySnapshot.up.askSize = 0;
    emptyEngine.tick(emptySnapshot, 0);
    emptyEngine.tick(emptySnapshot, 1000);
    expect(empty.ledger).toHaveLength(0);
    expect(emptyEngine.getStatuses().UP.decision).toBe("INSUFFICIENT_LIQUIDITY");
    const high = account();
    const highEngine = new EntryEngine(config, high, new PaperExecutor(config), () => undefined, async () => null, 0);
    const highSnapshot = snapshot(113);
    highSnapshot.up.ask = 0.99;
    highEngine.tick(highSnapshot, 0);
    highEngine.tick(highSnapshot, 1000);
    expect(highEngine.getStatuses().UP.decision).toBe("ABOVE_MAX_ENTRY");
  });
  it("allows one entry, then blocks re-entry in the same window", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(113);
    current.up.ask = 0.93;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(paper.openPosition).not.toBeNull();
    current.up.bid = 0.99;
    engine.tick(current, 2000);
    expect(paper.openPosition).toBeNull();
    current.up.bid = 0.92;
    engine.tick(current, 3000);
    expect(engine.getStatuses().UP.decision).toBe("ALREADY_TRADED_THIS_WINDOW");
  });
  it("never creates a fill at or above one", () => {
    const paper = account();
    expect(new PaperExecutor(config).buy(paper, "w", "DOWN", 0.99, 1)).toBeNull();
  });
  it("halts after three losing round trips", () => {
    const paper = account();
    for (let index = 0; index < 3; index += 1) {
      paper.ledger.push({ id: `b${index}`, timestamp: index, windowId: `w${index}`, side: "BUY", outcome: "UP", price: 0.93, shares: 10, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" });
      paper.ledger.push({ id: `s${index}`, timestamp: index, windowId: `w${index}`, side: "SELL", outcome: "UP", price: 0.9, shares: 10, usd: 9, fee: 0, slippage: 0, reason: "STOP_LOSS" });
    }
    paper.totalRealizedPnl = -3;
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(113);
    current.up.ask = 0.93;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(engine.getStatuses().UP.decision).toBe("HALTED_BY_CIRCUIT_BREAKER");
  });
  it("keeps an unresolved stale position pending instead of settling at zero", async () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "old", windowStart: 0, entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    await engine.recoverStalePosition(1000);
    expect(paper.openPosition?.resolutionStatus).toBe("PENDING_RESOLUTION");
    expect(paper.ledger).toHaveLength(0);
  });
});
