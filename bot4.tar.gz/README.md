# Polymarket BTC 15-minute Paper Terminal

This project is paper-trading only: it contains no wallet, private-key, or real-order code. The current scaffold provides a strict TypeScript server/client split, append-only paper ledger primitives, reconciliation, atomic persistence, SSE state delivery, and focused math tests. Live Polymarket discovery and CLOB feed integration should be added behind the server's authoritative snapshot before enabling entries; until then the UI correctly remains disconnected and does not trade.

## Run

```bash
npm install
copy .env.example .env
npm run build
npm start
```

Production runs the website, API, and SSE endpoint from one server port. Set `PORT` in `.env` (the default is 3001). `npm run dev` remains available for development with Vite's separate frontend port. `npm test` runs math tests and `npm run simulate` exercises the stop-loss calculation offline.
