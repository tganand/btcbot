export type Outcome = "UP" | "DOWN";
export type Side = "BUY" | "SELL";
export type ExitReason = "TAKE_PROFIT" | "STOP_LOSS" | "REVERSAL" | "SETTLEMENT";

export interface Book {
  bid: number;
  ask: number;
  bidSize: number;
  askSize: number;
  lastUpdateTs: number;
  lastTrade?: number;
}
export type EntryDecision = "NONE" | "BELOW_TRIGGER" | "ABOVE_MAX_ENTRY" | "HOLD_TIMER" | "TOO_LATE" | "FEED_STALE" | "INCONSISTENT" | "POSITION_OPEN" | "WARMUP" | "INSUFFICIENT_LIQUIDITY";
export interface EntryStatus {
  ask: number;
  trigger: number;
  msHeldAboveTrigger: number;
  secondsRemaining: number;
  feedHealth: string;
  consistent: boolean;
  positionOpen: boolean;
  askSize: number;
  decision: EntryDecision;
}
export interface MarketSnapshot {
  windowId: string;
  windowStart: number;
  windowEnd: number;
  up: Book;
  down: Book;
  feedHealth: "LIVE" | "STALE" | "DISCONNECTED";
  consistent: boolean;
  feedMessage: string;
}
export interface LedgerFill {
  id: string;
  timestamp: number;
  windowId: string;
  side: Side;
  outcome: Outcome;
  price: number;
  shares: number;
  usd: number;
  fee: number;
  slippage: number;
  reason: string;
}
export interface PaperPosition {
  outcome: Outcome;
  windowId: string;
  entryPrice: number;
  shares: number;
  cost: number;
  openedAt: number;
  windowStart?: number;
  resolutionStatus?: "PENDING_RESOLUTION";
}
export interface Resolution {
  outcome: Outcome;
  price: number;
}
export interface PaperAccount {
  startingBalance: number;
  cashBalance: number;
  totalRealizedPnl: number;
  openPosition: PaperPosition | null;
  ledger: LedgerFill[];
  version: number;
  reconciliationStatus: "RECONCILED" | "MISMATCH";
  reconciliationDiff: number;
}
export interface PortfolioMetrics {
  realizedPnl: number;
  unrealizedPnl: number;
  equity: number;
  cash: number;
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  maxDrawdown: number;
  bestTrade: number;
  worstTrade: number;
  exitReasons: Record<string, number>;
}
