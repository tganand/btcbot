import { PaperExecutor, sharesForBudget } from "./paperExecutor.js";
import { deriveRoundTrips, feeForFill, stopPrice } from "./math.js";
import { defaultAccountRules, type EngineConfig } from "./config.js";
import type { AccountId, AccountRules, EntryDecision, EntryStatus, LedgerFill, MarketSnapshot, Outcome, PaperAccount, PaperPosition, PendingOrder, PostExitTracking, Resolution } from "./types.js";

interface SideState { aboveSince: number | null; lastLoggedSecond: number; lastLoggedDecision: string; }
type ResolvePosition = (position: NonNullable<PaperAccount["openPosition"]>) => Promise<Resolution | null>;

export class EntryEngine {
  private readonly state: Record<Outcome, SideState> = { UP: { aboveSince: null, lastLoggedSecond: -1, lastLoggedDecision: "" }, DOWN: { aboveSince: null, lastLoggedSecond: -1, lastLoggedDecision: "" } };
  private readonly statuses: Record<Outcome, EntryStatus>;
  private readonly warmupUntil: number;
  private enteredWindow = "";
  private exitInFlight = false;
  private pendingSince = 0;
  private nextResolutionPollAt = 0;
  private lastExitLogSecond = -1;
  private postExitPollInFlight = false;
  private pendingOrder: PendingOrder | null = null;
  private readonly exitContext: NonNullable<LedgerFill["exitContext"]> = [];
  public constructor(
    private readonly config: EngineConfig,
    private readonly account: PaperAccount,
    private readonly executor: PaperExecutor,
    private readonly onAccountChange: () => void,
    private readonly resolvePosition: ResolvePosition,
    private readonly startedAt = Date.now(),
    private readonly accountId: AccountId = "mine",
    public rules: AccountRules = defaultAccountRules(accountId),
    private readonly random: () => number = Math.random,
    private readonly clock: () => number = Date.now
  ) {
    this.warmupUntil = startedAt + 1000;
    this.statuses = { UP: this.emptyStatus(), DOWN: this.emptyStatus() };
  }

  private recordExitContext(snapshot: MarketSnapshot, now: number): void {
    const secondsRemaining = Math.max(0, snapshot.windowEnd - now / 1000);
    this.exitContext.push({ timestamp: now, up: { ...snapshot.up }, down: { ...snapshot.down }, secondsRemaining });
    while (this.exitContext.length && now - this.exitContext[0]!.timestamp > 10000) this.exitContext.shift();
  }
  private emptyStatus(): EntryStatus {
    return { ask: 0, trigger: this.rules.entryMin, msHeldAboveTrigger: 0, secondsRemaining: 0, feedHealth: "DISCONNECTED", consistent: false, positionOpen: false, askSize: 0, decision: "FEED_STALE" };
  }
  public getStatuses(): Record<Outcome, EntryStatus> { return { UP: { ...this.statuses.UP }, DOWN: { ...this.statuses.DOWN } }; }
  public getPendingOrder(): PendingOrder | null { return this.pendingOrder ? { ...this.pendingOrder } : null; }
  public cancelPendingOrder(reason: string): void {
    if (!this.pendingOrder) return;
    console.info(`[${this.accountId}][engine] dropped pending ${this.pendingOrder.side} order: ${reason}`);
    this.pendingOrder = null;
  }
  public isCircuitBreakerHalted(): boolean {
    const trades = deriveRoundTrips(this.account.ledger);
    return this.account.totalRealizedPnl <= -this.config.circuitBreakerLossLimit || (trades.length >= 3 && trades.slice(-3).every((trade) => trade.pnl < 0));
  }
  public async recoverStalePosition(now = Date.now()): Promise<void> {
    const position = this.account.openPosition;
    if (!position) return;
    const windowStart = position.windowStart ?? Math.floor(position.openedAt / 1000 / 3600) * 3600;
    if (now >= (windowStart + 3600) * 1000) await this.settle(position, 0, now);
    else console.info(`[${this.accountId}][engine] recovered open ${position.outcome} position; continuing paper management`);
  }

  public tick(snapshot: MarketSnapshot, now = this.clock()): void {
    try {
      if (this.pendingOrder) {
        if (this.pendingOrder.side === "SELL" && this.account.openPosition) {
          this.recordExitContext(snapshot, now);
          const second = Math.floor(now / 1000);
          if (second !== this.lastExitLogSecond) {
            this.lastExitLogSecond = second;
            console.log(`[${this.accountId}][exit] ${this.pendingOrder.outcome} bid=${(this.pendingOrder.outcome === "UP" ? snapshot.up.bid : snapshot.down.bid).toFixed(5)} decision=PENDING_${this.pendingOrder.reason} secondsRemaining=${Math.max(0, snapshot.windowEnd - now / 1000).toFixed(1)}`);
          }
        }
        this.processPendingOrder(snapshot, now);
        return;
      }
      if (this.account.openPosition) {
        this.evaluateExit(snapshot, now);
        this.processDuePending(snapshot, now);
        return;
      }
      void this.updatePostExitTracking(snapshot, now);
      if (snapshot.windowId !== this.enteredWindow) {
        this.enteredWindow = snapshot.windowId;
        this.state.UP.aboveSince = null;
        this.state.DOWN.aboveSince = null;
        this.state.UP.lastLoggedSecond = -1;
        this.state.DOWN.lastLoggedSecond = -1;
        this.state.UP.lastLoggedDecision = "";
        this.state.DOWN.lastLoggedDecision = "";
      }
      for (const outcome of ["UP", "DOWN"] as const) {
        this.evaluateEntry(snapshot, outcome, now);
        if (this.pendingOrder) {
          this.processDuePending(snapshot, now);
          return;
        }
      }
    } catch (error) {
      console.error(`[${this.accountId}][engine] tick error: ${error instanceof Error ? error.stack ?? error.message : String(error)}`);
    }
  }

  private evaluateExit(snapshot: MarketSnapshot, now: number): void {
    const position = this.account.openPosition;
    if (!position || this.exitInFlight) return;
    const book = position.outcome === "UP" ? snapshot.up : snapshot.down;
    const opposite = position.outcome === "UP" ? snapshot.down.bid : snapshot.up.bid;
    const secondsRemaining = snapshot.windowEnd - now / 1000;
    this.recordExitContext(snapshot, now);
    const rules = position.rules ?? this.rules;
    const sl = position.stopLossPrice ?? (position.stopLossPriceOffset !== undefined ? Math.max(0, position.entryPrice - position.stopLossPriceOffset) : stopPrice(position, position.stopLossUsd ?? rules.stopLossUsd, this.config.feeRate));
    const tp = position.takeProfitPrice ?? rules.target;
    let decision = "HOLD";
    const lastTradeAt = this.account.lastEntryExitByOutcome[position.outcome];
    if (lastTradeAt !== undefined && Math.floor(lastTradeAt / 1000) === Math.floor(now / 1000)) {
      decision = "HOLD";
    } else if (book.bid >= tp - 1e-9) decision = "TAKE_PROFIT";
    else if (position.windowId !== snapshot.windowId || secondsRemaining <= 0) decision = "WINDOW_END";
    else if (rules.emptyBookSafety && secondsRemaining <= 45) decision = "EMPTY_BOOK";
    else if (book.bid <= sl + 1e-4) decision = "STOP_LOSS";
    else if (opposite >= rules.reversalPrice) decision = "REVERSAL";
    const second = Math.floor(now / 1000);
    if (second !== this.lastExitLogSecond) {
      this.lastExitLogSecond = second;
      const pnl = book.bid * position.shares - feeForFill(position.shares, book.bid, this.config.feeRate) - position.cost;
      console.log(`[${this.accountId}][exit] ${position.outcome} bid=${book.bid.toFixed(5)} tp=${tp.toFixed(5)} sl=${sl.toFixed(5)} unrealizedPnl=${pnl.toFixed(4)} secondsRemaining=${secondsRemaining.toFixed(1)} decision=${decision}`);
    }
    if (decision === "TAKE_PROFIT" || decision === "STOP_LOSS" || decision === "REVERSAL" || decision === "EMPTY_BOOK") {
      this.closeAtPrice(decision, book.bid, now, decision === "STOP_LOSS" ? sl : decision === "REVERSAL" ? rules.reversalPrice : decision === "TAKE_PROFIT" ? tp : book.bid, book.bid <= 0 || book.bidSize <= 0);
    } else if (decision === "WINDOW_END") {
      void this.settle(position, book.bid, now);
    }
  }

  private closeAtPrice(reason: string, price: number, now: number, triggerPrice: number, emptyBook = false): void {
    const position = this.account.openPosition;
    if (!position) return;
    this.exitInFlight = true;
    const delayMs = this.delay();
    this.pendingOrder = { side: "SELL", outcome: position.outcome, windowId: position.windowId, decisionPrice: price, decisionTime: now, fillAt: now + delayMs, fillDelayMs: delayMs, reason, triggerPrice, secondsRemaining: 0, emptyBook };
    this.exitInFlight = false;
    this.onAccountChange();
  }

  private delay(): number {
    const range = this.config.fillDelayMaxMs - this.config.fillDelayMinMs;
    return this.config.fillDelayMinMs + Math.max(0, Math.min(1, this.random())) * range;
  }

  private processDuePending(snapshot: MarketSnapshot, now: number): void {
    const pending = this.pendingOrder;
    if (pending && now >= pending.fillAt) this.processPendingOrder(snapshot, now);
  }

  private processPendingOrder(snapshot: MarketSnapshot, now: number): void {
    const order = this.pendingOrder;
    if (!order || now < order.fillAt) return;
    if (order.side === "BUY") {
      if (snapshot.windowId !== order.windowId) {
        this.pendingOrder = null;
        this.recordMissedFill();
        this.account.entryAttemptsThisWindow ??= {};
        this.account.entryAttemptsThisWindow[order.windowId] = (order.attempts ?? 0) + 1;
        console.log(`[${this.accountId}][entry] MISSED_FILL ${order.outcome} reason=WINDOW_ROLLOVER`);
        this.onAccountChange();
        return;
      }
      const book = order.outcome === "UP" ? snapshot.up : snapshot.down;
      const fillPrice = book.ask * (1 + this.config.slippageBps / 10000);
      const fillShares = sharesForBudget(fillPrice, this.rules.tradeSizeUsd, this.account.cashBalance, this.config.feeRate);
      const attempts = order.attempts ?? 0;
      const missed = book.ask > this.rules.entryMax || fillPrice < 0.01 || fillPrice > 0.99 ||
        fillShares <= 0 || book.askSize < fillShares ||
        (this.rules.thinBookCheck && fillShares > book.askSize * 0.25);
      this.pendingOrder = null;
      if (missed) {
        this.recordMissedFill();
        this.account.entryAttemptsThisWindow ??= {};
        this.account.entryAttemptsThisWindow[order.windowId] = attempts + 1;
        console.log(`[${this.accountId}][entry] MISSED_FILL ${order.outcome} decisionPrice=${order.decisionPrice.toFixed(4)} fillAsk=${book.ask.toFixed(4)} askSize=${book.askSize.toFixed(4)} requiredShares=${fillShares.toFixed(4)} attempts=${attempts + 1}`);
        this.onAccountChange();
        return;
      }

      const fill = this.executor.buy(this.account, order.windowId, order.outcome, book.ask, now, this.rules.tradeSizeUsd);
      if (!fill) {
        this.recordMissedFill();
        this.account.entryAttemptsThisWindow ??= {};
        this.account.entryAttemptsThisWindow[order.windowId] = attempts + 1;
        this.onAccountChange();
        return;
      }
      fill.decisionPrice = order.decisionPrice;
      fill.delayMs = now - order.decisionTime;
      fill.secondsRemainingAtEntry = order.secondsRemaining;
      fill.rulesVersion = this.account.rulesVersion ?? 1;
      fill.windowSlug = snapshot.windowSlug ?? order.windowId;
      const cost = fill.usd + fill.fee;
      const stopLossPrice = stopPrice({ entryPrice: fill.price, shares: fill.shares, cost, outcome: order.outcome, windowId: order.windowId, openedAt: now }, this.rules.stopLossUsd, this.config.feeRate);
      const settings = { triggerPrice: this.rules.entryMin, takeProfitPrice: this.rules.target, stopLossPrice, stopLossUsd: this.rules.stopLossUsd, maxEntryPrice: this.rules.entryMax };
      Object.assign(fill, settings);
      this.account.openPosition = { outcome: order.outcome, windowId: order.windowId, windowSlug: snapshot.windowSlug ?? order.windowId, windowStart: snapshot.windowStart, entryPrice: fill.price, shares: fill.shares, cost, openedAt: now, ...settings, rules: { ...this.rules }, rulesVersion: this.account.rulesVersion ?? 1 };
      this.account.entriesThisWindow[order.windowId] = true;
      this.account.lastEntryExitByOutcome[order.outcome] = now;
      this.onAccountChange();
      return;
    }

    const position = this.account.openPosition;
    if (!position) { this.pendingOrder = null; return; }
    const book = order.outcome === "UP" ? snapshot.up : snapshot.down;
    if (snapshot.windowId !== position.windowId || snapshot.windowEnd <= now / 1000) {
      this.pendingOrder = null;
      void this.settle(position, book.bid, now);
      return;
    }
    if (book.bid <= 0 || book.bidSize <= 0) {
      order.fillAt = now + 100;
      return;
    }
    this.pendingOrder = null;
    const fill = this.executor.sell(this.account, position.windowId, position.outcome, position.shares, book.bid, order.reason, now, order.triggerPrice, { decisionPrice: order.decisionPrice, delayMs: now - order.decisionTime, windowSlug: position.windowSlug });
    fill.emptyBook = order.emptyBook || book.bid <= 0 || book.bidSize <= 0;
    fill.rulesVersion = position.rulesVersion ?? this.account.rulesVersion ?? 1;
    if (order.reason === "STOP_LOSS" || order.reason === "REVERSAL" || order.reason === "EMPTY_BOOK") fill.exitContext = [...this.exitContext];
    if (order.reason === "STOP_LOSS" || order.reason === "REVERSAL") this.startPostExitTracking(fill, position, now);
    this.account.openPosition = null;
    this.account.lastEntryExitByOutcome[position.outcome] = now;
    this.dailyPnlFor(now);
    this.onAccountChange();
  }

  private recordMissedFill(): void {
    this.account.missedFillCount = (this.account.missedFillCount ?? 0) + 1;
    this.account.missedFillsByRulesVersion ??= {};
    const version = String(this.account.rulesVersion ?? 1);
    this.account.missedFillsByRulesVersion[version] = (this.account.missedFillsByRulesVersion[version] ?? 0) + 1;
  }

  private dailyPnlFor(now: number): number {
    const date = new Date(now).toISOString().slice(0, 10);
    const value = deriveRoundTrips(this.account.ledger)
      .filter((trade) => new Date(trade.sell.timestamp).toISOString().slice(0, 10) === date)
      .reduce((sum, trade) => sum + trade.pnl, 0);
    this.account.dailyPnl ??= {};
    if (this.account.dailyPnl[date] !== value) {
      this.account.dailyPnl[date] = value;
      this.onAccountChange();
    }
    return value;
  }

  private startPostExitTracking(fill: LedgerFill, position: PaperPosition, now: number): void {
    const tracking: PostExitTracking = { outcome: position.outcome, bestBidAfterExit: 0, finalResult: "pending", verdict: "PENDING", windowStart: position.windowStart, updatedAt: now };
    fill.outcomeAfterExit = tracking;
    this.account.postExitTracking ??= {};
    this.account.postExitTracking[fill.id] = tracking;
  }

  private async updatePostExitTracking(snapshot: MarketSnapshot, now: number): Promise<void> {
    const trackingMap = this.account.postExitTracking;
    if (!trackingMap || this.postExitPollInFlight) return;
    const entries = Object.entries(trackingMap);
    if (!entries.length) return;
    for (const [fillId, tracking] of entries) {
      const sideBid = tracking.outcome === "UP" ? snapshot.up.bid : snapshot.down.bid;
      if (snapshot.windowId === this.findFill(fillId)?.windowId && sideBid > tracking.bestBidAfterExit) tracking.bestBidAfterExit = sideBid;
      const windowStart = tracking.windowStart ?? Math.floor(now / 1000 / 3600) * 3600;
      const ended = now >= (windowStart + 3600) * 1000;
      if (tracking.finalResult !== "pending" || (!ended && snapshot.windowId === this.findFill(fillId)?.windowId)) continue;
      if (ended && now - tracking.updatedAt < 5000) continue;
      this.postExitPollInFlight = true;
      try {
        const resolution = await this.resolvePosition({ outcome: tracking.outcome, windowId: this.findFill(fillId)?.windowId ?? "", windowStart, entryPrice: 0, shares: 1, cost: 0, openedAt: now });
        if (resolution) {
          tracking.finalResult = resolution.outcome;
          tracking.verdict = resolution.outcome === tracking.outcome ? "WOULD_HAVE_WON" : "STOP_WAS_RIGHT";
          tracking.updatedAt = now;
          const fill = this.findFill(fillId);
          if (fill) fill.outcomeAfterExit = tracking;
          this.onAccountChange();
        } else if (ended) {
          tracking.updatedAt = now;
          this.onAccountChange();
        }
      } catch (error) {
        console.error(`[${this.accountId}][engine] post-exit tracking error: ${error instanceof Error ? error.message : String(error)}`);
      } finally {
        this.postExitPollInFlight = false;
      }
    }
  }

  private findFill(id: string): LedgerFill | undefined {
    return this.account.ledger.find((fill) => fill.id === id);
  }

  private async settle(position: NonNullable<PaperAccount["openPosition"]>, lastBid: number, now: number): Promise<void> {
    if (this.exitInFlight) return;
    if (now < this.nextResolutionPollAt) return;
    this.exitInFlight = true;
    this.nextResolutionPollAt = now + 5000;
    try {
      if (!this.pendingSince) this.pendingSince = now;
      const wasPending = position.resolutionStatus === "PENDING_RESOLUTION";
      position.resolutionStatus = "PENDING_RESOLUTION";
      if (!wasPending) this.onAccountChange();
      const windowStart = position.windowStart ?? Math.floor(position.openedAt / 1000 / 3600) * 3600;
      const estimatedAt = (windowStart + 3600 + 600) * 1000;
      const resolution = await this.resolvePosition(position);
      if (resolution) {
        const settlementPrice = resolution.outcome === position.outcome ? 1 : 0;
        const fill = this.executor.settle(this.account, position.windowId, position.outcome, position.shares, settlementPrice, "SETTLEMENT", now, position.windowSlug);
        fill.rulesVersion = position.rulesVersion ?? this.account.rulesVersion ?? 1;
        this.account.openPosition = null;
        this.pendingSince = 0;
        this.dailyPnlFor(now);
        this.onAccountChange();
      } else if (now >= estimatedAt) {
        const fill = this.executor.sell(this.account, position.windowId, position.outcome, position.shares, lastBid, "SETTLEMENT_ESTIMATED", now, lastBid, { decisionPrice: lastBid, delayMs: 0, windowSlug: position.windowSlug });
        fill.rulesVersion = position.rulesVersion ?? this.account.rulesVersion ?? 1;
        this.account.openPosition = null;
        this.pendingSince = 0;
        this.dailyPnlFor(now);
        this.onAccountChange();
      }
    } catch (error) {
      console.error(`[${this.accountId}][engine] settlement error: ${error instanceof Error ? error.message : String(error)}`);
    } finally { this.exitInFlight = false; }
  }

  private evaluateEntry(snapshot: MarketSnapshot, outcome: Outcome, now: number): void {
    const book = outcome === "UP" ? snapshot.up : snapshot.down;
    const secondsRemaining = Math.max(0, snapshot.windowEnd - now / 1000);
    if (book.ask >= this.rules.entryMin) this.state[outcome].aboveSince ??= now;
    else this.state[outcome].aboveSince = null;
    const held = this.state[outcome].aboveSince === null ? 0 : now - this.state[outcome].aboveSince;
    const decision = this.openPositionIfEligible(snapshot, outcome, book.ask, book.askSize, held, secondsRemaining, now);
    const status = this.statuses[outcome] = { ask: book.ask, trigger: this.rules.entryMin, msHeldAboveTrigger: held, secondsRemaining, feedHealth: snapshot.feedHealth, consistent: snapshot.consistent, positionOpen: false, askSize: book.askSize, decision };
    const second = Math.floor(now / 1000);
    if (decision !== this.state[outcome].lastLoggedDecision || second - this.state[outcome].lastLoggedSecond >= 10) {
      this.state[outcome].lastLoggedSecond = second;
      this.state[outcome].lastLoggedDecision = decision;
      console.log(`[${this.accountId}][entry] ${outcome} ask=${book.ask.toFixed(4)} trigger=${this.rules.entryMin.toFixed(4)} heldMs=${held} secondsRemaining=${secondsRemaining.toFixed(1)} feed=${snapshot.feedHealth} consistent=${snapshot.consistent} positionOpen=false askSize=${book.askSize} decision=${status.decision}`);
    }
  }
  private openPositionIfEligible(snapshot: MarketSnapshot, outcome: Outcome, ask: number, askSize: number, held: number, secondsRemaining: number, now: number): EntryDecision {
    if (this.account.openPosition) return "POSITION_OPEN";
    if (now < this.warmupUntil) return "WARMUP";
    if (snapshot.feedHealth !== "LIVE") return "FEED_STALE";
    if (ask < this.rules.entryMin || ask <= 0) return "BELOW_TRIGGER";
    if (askSize < this.rules.tradeSizeUsd / ask) return "INSUFFICIENT_LIQUIDITY";
    if (ask > this.rules.entryMax) return "ABOVE_MAX_ENTRY";
    if (this.rules.thinBookCheck && this.rules.tradeSizeUsd / ask > askSize * 0.25) return "THIN_BOOK";
    if (this.account.entriesThisWindow[snapshot.windowId]) return "ALREADY_TRADED_THIS_WINDOW";
    this.account.entryAttemptsThisWindow ??= {};
    if ((this.account.entryAttemptsThisWindow[snapshot.windowId] ?? 0) >= 3) return "MISSED_FILL_LIMIT";
    const todayPnl = this.dailyPnlFor(now);
    if (this.rules.dailyLossLimit !== undefined && todayPnl <= this.rules.dailyLossLimit) return "DAILY_LOSS_LIMIT";
    if (this.rules.dailyProfitLock !== undefined && todayPnl >= this.rules.dailyProfitLock) return "DAILY_TARGET_REACHED";
    if (this.isCircuitBreakerHalted()) return "HALTED_BY_CIRCUIT_BREAKER";
    if (!snapshot.consistent) return "INCONSISTENT";
    if (held < this.rules.holdMs) return "HOLD_TIMER";
    if (secondsRemaining > this.rules.maxSecondsRemaining) return "TOO_EARLY";
    if (secondsRemaining < this.rules.minSecondsRemaining) return "TOO_LATE";
    const simulatedFill = ask * (1 + this.config.slippageBps / 10000);
    if (simulatedFill < 0.01 || simulatedFill > 0.99) return "PRICE_OUT_OF_RANGE";
    if (simulatedFill >= this.rules.target - 0.02) return "NO_UPSIDE";
    const lastTradeAt = this.account.lastEntryExitByOutcome[outcome];
    if (lastTradeAt !== undefined && Math.floor(lastTradeAt / 1000) === Math.floor(now / 1000)) return "ALREADY_TRADED_THIS_WINDOW";
    const delayMs = this.delay();
    this.pendingOrder = { side: "BUY", outcome, windowId: snapshot.windowId, decisionPrice: ask, decisionTime: now, fillAt: now + delayMs, fillDelayMs: delayMs, shares: this.rules.tradeSizeUsd / simulatedFill, attempts: this.account.entryAttemptsThisWindow[snapshot.windowId] ?? 0, reason: "ENTRY", triggerPrice: this.rules.entryMin, secondsRemaining };
    this.onAccountChange();
    return "NONE";
  }
}
