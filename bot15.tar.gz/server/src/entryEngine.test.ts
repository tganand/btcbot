import { describe, expect, it } from "vitest";
import { EntryEngine } from "./entryEngine.js";
import { config as baseConfig, defaultAccountRules } from "./config.js";
import { reconcilePaperAccount, stopPrice } from "./math.js";
import { PaperExecutor } from "./paperExecutor.js";
import type { MarketSnapshot, PaperAccount } from "./types.js";

const config = { ...baseConfig, fillDelayMinMs: 0, fillDelayMaxMs: 0 };
const account = (): PaperAccount => ({ startingBalance: 100, cashBalance: 100, totalRealizedPnl: 0, openPosition: null, ledger: [], version: 0, reconciliationStatus: "RECONCILED", reconciliationDiff: 0, entriesThisWindow: {}, lastEntryExitByOutcome: {} });
const snapshot = (secondsRemaining: number): MarketSnapshot => ({
  windowId: "w",
  windowStart: 0,
  windowEnd: secondsRemaining,
  up: { bid: 0.94, ask: 0.94, bidSize: 200, askSize: 200, lastUpdateTs: 1000 },
  down: { bid: 0.04, ask: 0.05, bidSize: 200, askSize: 200, lastUpdateTs: 1000 },
  feedHealth: "LIVE",
  consistent: true,
  feedMessage: "Live prices flowing"
});

describe("entry visibility and decisions", () => {
  it("buys after a held trigger with time and liquidity", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(113), 0);
    engine.tick(snapshot(113), 1000);
    expect(paper.ledger).toHaveLength(1);
    expect(paper.ledger[0]?.outcome).toBe("UP");
  });
  it("stores the settings snapshot on the position and entry fill", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(113), 0);
    engine.tick(snapshot(113), 1000);
    const fill = paper.ledger[0]!;
    expect(fill.triggerPrice).toBe(config.entryTrigger);
    expect(fill.takeProfitPrice).toBe(config.takeProfit);
    expect(fill.stopLossUsd).toBe(10);
    expect(fill.maxEntryPrice).toBe(config.maxEntryPrice);
    expect(fill.stopLossPrice).toBeCloseTo(stopPrice({ entryPrice: fill.price, shares: fill.shares, cost: fill.usd + fill.fee, outcome: "UP", windowId: "w", openedAt: fill.timestamp }, 10, config.feeRate), 6);
    expect(paper.openPosition?.stopLossPrice).toBe(fill.stopLossPrice);
  });
  it("blocks an otherwise eligible entry when too late", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    engine.tick(snapshot(80), 0);
    engine.tick(snapshot(80), 1000);
    expect(paper.ledger).toHaveLength(0);
    expect(engine.getStatuses().UP.decision).toBe("TOO_LATE");
  });
  it("takes profit from bid without ask liquidity or reconciliation", () => {
    const paper = account();
    paper.cashBalance = 90;
    paper.reconciliationStatus = "MISMATCH";
    paper.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.windowId = "old";
    current.down = { bid: 0.99, ask: 1, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 1000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("TAKE_PROFIT");
  });
  it("settles an older position at resolved 1.00 or 0.00", async () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    engine.tick({ ...snapshot(100), windowId: "new" }, 1000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.price).toBe(1);
    const second = account();
    second.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const secondEngine = new EntryEngine(config, second, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    secondEngine.tick({ ...snapshot(100), windowId: "new" }, 1000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(second.openPosition).toBeNull();
    expect(second.ledger.at(-1)?.price).toBe(0);
  });
  it("recovers a stale startup position", async () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "old", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "DOWN", price: 0 }), 0);
    await engine.recoverStalePosition(3601000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("SETTLEMENT");
  });
  it("blocks an ask above the configured maximum", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(113);
    current.up.ask = 0.975;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(paper.openPosition).toBeNull();
    expect(engine.getStatuses().UP.decision).toBe("ABOVE_MAX_ENTRY");
  });
  it("blocks the failing empty-ask and 99c cases", () => {
    const empty = account();
    const emptyEngine = new EntryEngine(config, empty, new PaperExecutor(config), () => undefined, async () => null, 0);
    const emptySnapshot = snapshot(113);
    emptySnapshot.up.ask = 1;
    emptySnapshot.up.askSize = 0;
    emptyEngine.tick(emptySnapshot, 0);
    emptyEngine.tick(emptySnapshot, 1000);
    expect(empty.ledger).toHaveLength(0);
    expect(emptyEngine.getStatuses().UP.decision).toBe("INSUFFICIENT_LIQUIDITY");
    const high = account();
    const highEngine = new EntryEngine(config, high, new PaperExecutor(config), () => undefined, async () => null, 0);
    const highSnapshot = snapshot(113);
    highSnapshot.up.ask = 0.99;
    highEngine.tick(highSnapshot, 0);
    highEngine.tick(highSnapshot, 1000);
    expect(highEngine.getStatuses().UP.decision).toBe("ABOVE_MAX_ENTRY");
  });
  it("allows one entry, then blocks re-entry in the same window", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(113);
    current.up.ask = 0.93;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(paper.openPosition).not.toBeNull();
    current.up.bid = 0.99;
    engine.tick(current, 2000);
    expect(paper.openPosition).toBeNull();
    current.up.bid = 0.92;
    engine.tick(current, 3000);
    expect(engine.getStatuses().UP.decision).toBe("ALREADY_TRADED_THIS_WINDOW");
  });
  it("never creates a fill at or above one", () => {
    const paper = account();
    expect(new PaperExecutor(config).buy(paper, "w", "DOWN", 0.99, 1)).toBeNull();
  });
  it("does not charge a fee on settlement", () => {
    const fill = new PaperExecutor(config).settle(account(), "w", "UP", 10, 1, "SETTLEMENT", 1000);
    expect(fill.fee).toBe(0);
    expect(fill.delayMs).toBe(0);
  });
  it("halts after three losing round trips", () => {
    const paper = account();
    for (let index = 0; index < 3; index += 1) {
      paper.ledger.push({ id: `b${index}`, timestamp: index, windowId: `w${index}`, side: "BUY", outcome: "UP", price: 0.93, shares: 10, usd: 10, fee: 0, slippage: 0, reason: "ENTRY" });
      paper.ledger.push({ id: `s${index}`, timestamp: index, windowId: `w${index}`, side: "SELL", outcome: "UP", price: 0.9, shares: 10, usd: 9, fee: 0, slippage: 0, reason: "STOP_LOSS" });
    }
    paper.totalRealizedPnl = -3;
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(113);
    current.up.ask = 0.93;
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(engine.getStatuses().UP.decision).toBe("HALTED_BY_CIRCUIT_BREAKER");
  });
  it("keeps an unresolved stale position pending instead of settling at zero", async () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "old", windowStart: 0, entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    await engine.recoverStalePosition(3601000);
    expect(paper.openPosition?.resolutionStatus).toBe("PENDING_RESOLUTION");
    expect(paper.ledger).toHaveLength(0);
  });
  it("stops at the computed $1.50 loss threshold", () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "w", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0, stopLossUsd: 1.5 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    const stop = stopPrice({ ...paper.openPosition, outcome: "DOWN", windowId: "w" }, 1.5, config.feeRate);
    current.down = { bid: stop - 0.01, ask: 0.80, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 2000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("STOP_LOSS");
    expect(paper.totalRealizedPnl).toBe(0);
    expect(paper.ledger.at(-1)?.triggerPrice).toBeCloseTo(stop, 4);
    expect(paper.ledger.at(-1)?.fillPrice).toBeCloseTo((stop - 0.01) * (1 - config.slippageBps / 10000), 5);
  });
  it("records a larger loss and gap when price jumps through stop", () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "w", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0, stopLossUsd: 1.5 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.down = { bid: 0.45, ask: 0.5, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 2000);
    const fill = paper.ledger.at(-1)!;
    expect(fill.reason).toBe("STOP_LOSS");
    expect(fill.fillPrice).toBeCloseTo(0.45 * (1 - config.slippageBps / 10000), 5);
    expect(fill.extraSlippage).toBeGreaterThan(0.2);
  });
  it("holds at a bid above the stop threshold", () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "w", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0, stopLossUsd: 1.5 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.down = { bid: 0.81, ask: 0.82, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    current.up.bid = 0.20;
    engine.tick(current, 2000);
    expect(paper.openPosition).not.toBeNull();
  });
  it("reverses independently at the opposite-contract threshold", () => {
    const paper = account();
    paper.openPosition = { outcome: "DOWN", windowId: "w", entryPrice: 0.93465, shares: 10.699, cost: 10, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.down = { bid: 0.9, ask: 0.91, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    current.up.bid = 0.35;
    engine.tick(current, 2000);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger.at(-1)?.reason).toBe("REVERSAL");
  });
  it("tracks a stopped trade that would have won without changing accounting", async () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "w", windowStart: 0, entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0, stopLossUsd: 1.5 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "UP", price: 1 }), 0);
    const current = snapshot(100);
    current.up = { bid: 0.74, ask: 0.75, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 2000);
    expect(paper.ledger.at(-1)?.reason).toBe("STOP_LOSS");
    const before = paper.totalRealizedPnl;
    engine.tick({ ...current, windowId: "next", windowStart: 3600, windowEnd: 7200 }, 3601000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(paper.ledger.at(-1)?.outcomeAfterExit?.verdict).toBe("WOULD_HAVE_WON");
    expect(paper.totalRealizedPnl).toBe(before);
  });
  it("tracks a stopped trade that was right", async () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "w", windowStart: 0, entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0, stopLossUsd: 1.5 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => ({ outcome: "DOWN", price: 1 }), 0);
    const current = snapshot(100);
    current.up = { bid: 0.74, ask: 0.75, bidSize: 10, askSize: 0, lastUpdateTs: 1 };
    engine.tick(current, 2000);
    engine.tick({ ...current, windowId: "next", windowStart: 3600, windowEnd: 7200 }, 3601000);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(paper.ledger.at(-1)?.outcomeAfterExit?.verdict).toBe("STOP_WAS_RIGHT");
  });
  it("waits for the injected fill delay and records it", () => {
    const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 300 };
    const paper = account();
    let now = 0;
    const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => undefined, async () => null, 0, "mine", defaultAccountRules("mine"), () => 0.5, () => now);
    engine.tick(snapshot(113));
    now = 1000;
    engine.tick(snapshot(113));
    expect(paper.ledger).toHaveLength(0);
    now = 1199;
    engine.tick(snapshot(113));
    expect(paper.ledger).toHaveLength(0);
    now = 1200;
    engine.tick(snapshot(113));
    expect(paper.ledger[0]?.delayMs).toBe(200);
    expect(paper.ledger[0]?.decisionPrice).toBe(0.94);
  });
  it("marks an entry MISSED_FILL when the fill-time ask exceeds its max", () => {
    const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 100 };
    const paper = account();
    const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => undefined, async () => null, 0, "mine", defaultAccountRules("mine"), () => 0, () => 0);
    const current = snapshot(113);
    engine.tick(current, 0);
    engine.tick(current, 1000);
    current.up.ask = 0.96;
    engine.tick(current, 1100);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger).toHaveLength(0);
    expect(paper.missedFillCount).toBe(1);
    expect(paper.entryAttemptsThisWindow?.w).toBe(1);
  });
  it("allows three missed fills without consuming the one successful trade", () => {
    const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 100 };
    const paper = account();
    const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => undefined, async () => null, 0, "mine", defaultAccountRules("mine"), () => 0, () => 0);
    const current = snapshot(400);
    engine.tick(current, 0);
    engine.tick(current, 1000);
    for (const [decision, fill] of [[1000, 1100], [1101, 1201], [1202, 1302]]) {
      current.up.ask = 0.94;
      engine.tick(current, decision);
      current.up.ask = 0.96;
      engine.tick(current, fill);
    }
    current.up.ask = 0.94;
    engine.tick(current, 1303);
    expect(paper.missedFillCount).toBe(3);
    expect(paper.entriesThisWindow.w).toBeUndefined();
    expect(engine.getStatuses().UP.decision).toBe("MISSED_FILL_LIMIT");
  });
  it("counts fill-time price, price-range, and liquidity failures as missed fills", () => {
    const scenarios: Array<{ ask: number; decisionAsk?: number; askSize: number; decisionSlippageBps: number; fillSlippageBps: number }> = [
      { ask: 0.96, askSize: 20, decisionSlippageBps: 50, fillSlippageBps: 50 },
      { ask: 0.005, askSize: 5000, decisionSlippageBps: 50, fillSlippageBps: 50 },
      { ask: 0.95, decisionAsk: 0.93, askSize: 20, decisionSlippageBps: 0, fillSlippageBps: 500 },
      { ask: 0.94, askSize: 1, decisionSlippageBps: 50, fillSlippageBps: 50 }
    ];
    for (const scenario of scenarios) {
      const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 100, slippageBps: scenario.decisionSlippageBps };
      const paper = account();
      const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => undefined, async () => null, 0, "mine", defaultAccountRules("mine"), () => 0, () => 0);
      const current = snapshot(113);
      current.up.ask = scenario.decisionAsk ?? 0.94;
      engine.tick(current, 0);
      engine.tick(current, 1000);
      delayedConfig.slippageBps = scenario.fillSlippageBps;
      current.up.ask = scenario.ask;
      current.up.askSize = scenario.askSize;
      engine.tick(current, 1100);
      expect(paper.missedFillCount).toBe(1);
      expect(paper.ledger).toHaveLength(0);
      expect(paper.entriesThisWindow.w).toBeUndefined();
    }
  });
  it("marks a $100 buy as MISSED_FILL when the fill-time ask size is short", () => {
    const delayedConfig = { ...config, fillDelayMinMs: 100, fillDelayMaxMs: 100 };
    const paper = account();
    const engine = new EntryEngine(delayedConfig, paper, new PaperExecutor(delayedConfig), () => reconcilePaperAccount(paper), async () => null, 0, "mine", defaultAccountRules("mine"), () => 0, () => 0);
    const current = snapshot(300);
    engine.tick(current, 0);
    engine.tick(current, 1000);
    current.up.askSize = 100;
    engine.tick(current, 1100);
    expect(paper.missedFillCount).toBe(1);
    expect(paper.openPosition).toBeNull();
    expect(paper.ledger).toHaveLength(0);
    expect(paper.cashBalance).toBe(100);
  });
  it("fits a $100 entry inside cash after fees", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => reconcilePaperAccount(paper), async () => null, 0);
    engine.tick(snapshot(300), 0);
    engine.tick(snapshot(300), 1000);
    expect(paper.ledger[0]?.shares).toBeGreaterThan(100);
    expect(paper.ledger[0]?.shares).toBeLessThan(110);
    expect(paper.cashBalance).toBeGreaterThanOrEqual(0);
    expect(paper.ledger[0]!.usd + paper.ledger[0]!.fee).toBeLessThanOrEqual(100);
  });
  it("retries a sell after an empty bid and fills once liquidity returns", () => {
    const paper = account();
    paper.openPosition = { outcome: "UP", windowId: "w", entryPrice: 0.9, shares: 10, cost: 9, openedAt: 0 };
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(100);
    current.up = { bid: 0, ask: 0.5, bidSize: 0, askSize: 10, lastUpdateTs: 1 };
    engine.tick(current, 1000);
    expect(paper.openPosition).not.toBeNull();
    expect(paper.ledger).toHaveLength(0);
    current.up = { ...current.up, bid: 0.7, bidSize: 10 };
    engine.tick(current, 1099);
    expect(paper.ledger).toHaveLength(0);
    engine.tick(current, 1100);
    expect(paper.ledger).toHaveLength(1);
    expect(paper.ledger[0]?.reason).toBe("STOP_LOSS");
  });
  it("applies the hourly entry window and Mine entry maximum", () => {
    const mine = account();
    const mineEngine = new EntryEngine(config, mine, new PaperExecutor(config), () => undefined, async () => null, 0, "mine");
    mineEngine.tick(snapshot(3602), 0);
    mineEngine.tick(snapshot(3602), 1000);
    expect(mineEngine.getStatuses().UP.decision).toBe("TOO_EARLY");

    const mineHigh = account();
    const mineHighEngine = new EntryEngine(config, mineHigh, new PaperExecutor(config), () => undefined, async () => null, 0, "mine");
    const expensiveMine = snapshot(300);
    expensiveMine.up.ask = 0.96;
    mineHighEngine.tick(expensiveMine, 0);
    mineHighEngine.tick(expensiveMine, 1000);
    expect(mineHighEngine.getStatuses().UP.decision).toBe("ABOVE_MAX_ENTRY");

  });
  it("uses the position's rules snapshot after active rules change", () => {
    const paper = account();
    const engine = new EntryEngine(config, paper, new PaperExecutor(config), () => undefined, async () => null, 0);
    const current = snapshot(300);
    engine.tick(current, 0);
    engine.tick(current, 1000);
    expect(paper.openPosition?.rules?.target).toBe(0.99);
    engine.rules = { ...engine.rules, target: 0.8 };
    current.up.bid = 0.9;
    engine.tick(current, 2000);
    expect(paper.openPosition).not.toBeNull();
  });
});
