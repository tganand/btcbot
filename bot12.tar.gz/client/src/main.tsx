import React, { Component, useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

type Outcome = "UP" | "DOWN";
type Quote = { bid: number | null; ask: number | null; bidSize?: number | null; askSize?: number | null; lastUpdateTs?: number | null };
type Metrics = { realizedPnl: number | null; unrealizedPnl: number | null; equity: number | null; cash: number | null; trades: number | null; wins: number | null; losses: number | null; winRate: number | null; avgWin: number | null; avgLoss: number | null; profitFactor: number | null; maxDrawdown: number | null; bestTrade: number | null; worstTrade: number | null; exitReasons?: Record<string, number> };
type EntryStatus = { ask: number; trigger: number; msHeldAboveTrigger: number; secondsRemaining: number; feedHealth: string; consistent: boolean; positionOpen: boolean; askSize: number; decision: string };
type Position = { outcome: Outcome; entryPrice: number | null; shares: number | null; cost: number | null; windowId: string; openedAt: number | null; triggerPrice?: number | null; takeProfitPrice?: number | null; stopLossPrice?: number | null; stopLossUsd?: number | null; maxEntryPrice?: number | null };
type Tracking = { outcome: Outcome; bestBidAfterExit: number; finalResult: "pending" | Outcome; verdict: "PENDING" | "WOULD_HAVE_WON" | "STOP_WAS_RIGHT"; windowStart?: number; updatedAt: number };
type Fill = { id?: string; side: string; outcome: string; price: number | null; fillPrice?: number | null; shares: number | null; usd: number | null; fee?: number | null; slippage?: number | null; reason: string; timestamp?: number | null; windowId?: string; triggerPrice?: number | null; takeProfitPrice?: number | null; stopLossPrice?: number | null; stopLossUsd?: number | null; maxEntryPrice?: number | null; outcomeAfterExit?: Tracking };
type State = { circuitBreakerHalted: boolean; account: { cashBalance: number | null; totalRealizedPnl: number | null; reconciliationStatus: string; reconciliationDiff: number | null; openPosition: Position | null; ledger: Fill[]; postExitTracking?: Record<string, Tracking> }; snapshot: { windowId: string; windowStart: number; windowEnd: number; up: Quote; down: Quote; feedHealth: string; feedMessage: string; consistent: boolean }; metrics: Metrics; config?: { entryTrigger: number; takeProfit: number; stopLossUsd: number; maxEntryPrice: number }; entryStatus: { UP: EntryStatus | null; DOWN: EntryStatus | null } };
type RoundTrip = { buy: Fill; sell: Fill; pnl: number; percent: number; duration: number };

export const fmt = (value: unknown, digits = 2): string => typeof value !== "number" || !Number.isFinite(value) ? "--" : value.toFixed(digits);
const money = (value: unknown) => { const numeric = typeof value === "number" && Number.isFinite(value) ? value : null; return numeric === null ? "--" : `${numeric >= 0 ? "+" : "-"}$${fmt(Math.abs(numeric), 2)}`; };
const cents = (value: unknown) => typeof value === "number" && Number.isFinite(value) ? `${fmt(value * 100, 1)}¢` : "--";
const plainMoney = (value: unknown) => typeof value === "number" && Number.isFinite(value) ? `$${fmt(value, 2)}` : "--";
const settingCents = (value: unknown) => value === undefined || value === null ? "n/a" : cents(value);
const clamp = (value: unknown, min: number, max: number) => typeof value !== "number" || !Number.isFinite(value) ? min : Math.min(max, Math.max(min, value));
const formatClock = (timestamp: unknown) => typeof timestamp === "number" && Number.isFinite(timestamp) && timestamp > 0 ? new Date(timestamp).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : "--:--";
const formatDuration = (seconds: unknown) => typeof seconds !== "number" || !Number.isFinite(seconds) ? "--" : seconds < 60 ? `${Math.round(seconds)}s` : `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`;
const decisionCopy: Record<string, string> = { BELOW_TRIGGER: "Waiting for 91¢", ABOVE_MAX_ENTRY: "Too expensive, skipped", INSUFFICIENT_LIQUIDITY: "Not enough size", TOO_LATE: "Too late in the window", ALREADY_TRADED_THIS_WINDOW: "Already traded this window", POSITION_OPEN: "Trade in progress", FEED_STALE: "Feed stale", INCONSISTENT: "Prices inconsistent", HALTED_BY_CIRCUIT_BREAKER: "Halted after losses", WARMUP: "Warming up", NONE: "Eligible setup", HOLD_TIMER: "Holding above trigger" };

const quoteFor = (state: State, outcome: Outcome) => outcome === "UP" ? state.snapshot.up : state.snapshot.down;
const secondsRemaining = (state: State) => Math.max(0, state.snapshot.windowEnd - Date.now() / 1000);
const emptyState = (): State => ({ circuitBreakerHalted: false, account: { cashBalance: 100, totalRealizedPnl: 0, reconciliationStatus: "WAITING", reconciliationDiff: 0, openPosition: null, ledger: [] }, snapshot: { windowId: "", windowStart: 0, windowEnd: 0, up: { bid: 0, ask: 0 }, down: { bid: 0, ask: 0 }, feedHealth: "DISCONNECTED", feedMessage: "Connecting...", consistent: false }, metrics: { realizedPnl: 0, unrealizedPnl: 0, equity: 100, cash: 100, trades: 0, wins: 0, losses: 0, winRate: 0, avgWin: 0, avgLoss: 0, profitFactor: 0, maxDrawdown: 0, bestTrade: 0, worstTrade: 0 }, entryStatus: { UP: null, DOWN: null } });

class ErrorBoundary extends Component<React.PropsWithChildren, { error: Error | null }> {
  public state = { error: null as Error | null };
  public static getDerivedStateFromError(error: Error) { return { error }; }
  public render() {
    if (this.state.error) return <main className="error-screen"><section className="panel error-panel"><span className="eyebrow">BTC 15M / SYSTEM ERROR</span><h1>Dashboard error</h1><p>{this.state.error.message}</p><small>{this.state.error.stack}</small></section></main>;
    return this.props.children;
  }
}

class CardBoundary extends Component<React.PropsWithChildren<{ name: string }>, { error: Error | null }> {
  public state = { error: null as Error | null };
  public static getDerivedStateFromError(error: Error) { return { error }; }
  public render() {
    return this.state.error ? <section className="panel error-panel"><div className="section-kicker">{this.props.name}</div><h2>Unavailable</h2><small>{this.state.error.message}</small></section> : this.props.children;
  }
}

function Sparkline({ values }: { values: number[] }) {
  const points = values.length > 1 ? values.map((value, index) => `${(index / (values.length - 1)) * 100},${100 - clamp(value, 0, 1) * 100}`).join(" ") : "0,100 100,100";
  return <svg className="sparkline" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><polyline points={points} /></svg>;
}

function Ring({ progress }: { progress: number }) {
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  return <svg className="timer-ring" viewBox="0 0 100 100"><circle className="ring-track" cx="50" cy="50" r={radius} /><circle className="ring-value" cx="50" cy="50" r={radius} strokeDasharray={circumference} strokeDashoffset={circumference * (1 - clamp(progress, 0, 1))} /></svg>;
}

function PriceHero({ outcome, quote, history, maxEntry }: { outcome: Outcome; quote: Quote; history: number[]; maxEntry: number }) {
  const ask = typeof quote.ask === "number" ? quote.ask : null;
  const bid = typeof quote.bid === "number" ? quote.bid : null;
  const previous = history.length > 1 ? history[history.length - 2] ?? ask : ask;
  const direction = ask !== null && previous !== null ? ask > previous ? "rising" : ask < previous ? "falling" : "" : "";
  const spread = ask !== null && bid !== null ? Math.max(0, ask - bid) : null;
  const distance = ask !== null && maxEntry > ask ? Math.max(0, 0.91 - ask) : null;
  const tooHigh = ask !== null && ask > maxEntry;
  const progress = ask === null || ask <= 0 ? 0 : clamp(ask / 0.91, 0, 1);
  return <section className={`price-key ${outcome.toLowerCase()} ${direction} ${ask === null || ask <= 0 ? "stale-price" : ""}`}>
    <div className="key-top"><span className="key-label">{outcome}</span><span className="key-size">ASK SIZE {quote.askSize ?? 0}</span></div>
    <div className="key-price">{cents(ask)}</div>
    <div className="key-stats"><span>Bid <b>{cents(bid)}</b></span><span>Ask <b>{cents(ask)}</b></span><span>Spread <b>{cents(spread)}</b></span></div>
    <div className="trigger-line"><span style={{ width: `${tooHigh ? 100 : progress * 100}%` }} /><em>{tooHigh ? "TOO HIGH (above max entry)" : distance === null ? "--" : `${fmt(distance * 100, 1)}¢ to trigger`}</em></div>
    <Sparkline values={history} />
  </section>;
}

function WindowCard({ state, remaining }: { state: State; remaining: number }) {
  const duration = Math.max(1, state.snapshot.windowEnd - state.snapshot.windowStart);
  const progress = state.snapshot.windowStart ? clamp((Date.now() / 1000 - state.snapshot.windowStart) / duration, 0, 1) : 0;
  const locked = remaining > 0 && remaining <= 90;
  const start = formatClock(state.snapshot.windowStart);
  const end = formatClock(state.snapshot.windowEnd);
  return <section className={`panel window-card ${locked ? "window-locked" : ""}`}><div className="window-visual"><Ring progress={progress} /><div className="ring-center"><b>{Math.floor(remaining / 60)}:{Math.floor(remaining % 60).toString().padStart(2, "0")}</b><small>LEFT</small></div></div><div className="window-info"><div className="section-kicker">CURRENT WINDOW {locked && <span className="badge amber">ENTRY LOCKED</span>}</div><h2>{start} - {end}</h2><p className="market-status">{state.snapshot.feedMessage || "Live prices flowing"}</p><div className="window-details"><span title={state.snapshot.windowId}>{state.snapshot.windowId || "No active market"}</span><button type="button" onClick={() => void navigator.clipboard?.writeText(state.snapshot.windowId || "")}>COPY</button></div></div></section>;
}

function Radar({ state }: { state: State }) {
  return <section className="panel radar-panel"><div className="section-heading"><div><div className="section-kicker">MARKET RADAR</div><h2>Distance to 91¢ trigger</h2></div><span className="binary-chip">{state.snapshot.consistent ? "UP + DOWN = 100¢ OK" : "BINARY CHECK WAITING"}</span></div><div className="radar-list">{(["UP", "DOWN"] as Outcome[]).map(outcome => { const item = state.entryStatus[outcome]; const ask = item?.ask ?? quoteFor(state, outcome).ask; const trigger = item?.trigger ?? 0.91; const held = item?.msHeldAboveTrigger ?? 0; const decision = item?.decision ?? "WAITING"; const delta = typeof ask === "number" && typeof trigger === "number" ? Math.abs(ask - trigger) * 100 : null; return <div className="radar-row" key={outcome}><div className="radar-name">{outcome}</div><div className="radar-quote">{cents(ask)} <small>{delta === null ? "--" : typeof ask === "number" && ask >= trigger ? `${fmt(delta, 1)}¢ above` : `${fmt(delta, 1)}¢ to go`}</small></div><div className="hold-wrap"><div className="hold-track"><span style={{ width: `${clamp(typeof held === "number" ? held / 400 : null, 0, 1) * 100}%` }} /></div><small>{fmt(held, 0)}/{400} ms</small></div><div className={`decision ${decision.toLowerCase()}`}><b>{decisionCopy[decision] || decision}</b><small>{decision}</small></div></div>; })}</div></section>;
}

function PositionCockpit({ state, remaining }: { state: State; remaining: number }) {
  const position = state.account.openPosition;
  if (!position) return <section className="panel empty-cockpit"><span className="empty-icon">◎</span><h2>Waiting for a trade</h2><p>Clean setup: 91¢ to 95¢, enough liquidity, one trade per window.</p></section>;
  const bid = quoteFor(state, position.outcome).bid;
  const stop = position.stopLossPrice ?? ((Number(position.cost) - Number(position.stopLossUsd ?? 1.5)) / Number(position.shares));
  const take = 0.99;
  const marker = clamp((Number(bid) - Number(stop)) / (take - Number(stop)), 0, 1) * 100;
  const entryMarker = clamp((Number(position.entryPrice) - Number(stop)) / (take - Number(stop)), 0, 1) * 100;
  const pnl = Number(bid) * Number(position.shares) - Number(position.cost);
  const positive = pnl >= 0;
  return <section className={`panel position-card ${positive ? "position-profit" : "position-loss"}`}><div className="position-head"><span className="badge live-badge">● LIVE TRADE</span><span className="position-side">{position.outcome}</span></div><div className="position-grid"><div><small>ENTRY</small><b>{cents(position.entryPrice)}</b></div><div><small>SHARES</small><b>{fmt(position.shares, 3)}</b></div><div><small>COST</small><b>{plainMoney(position.cost)}</b></div><div><small>CURRENT BID</small><b>{cents(bid)}</b></div><div><small>TIME HELD</small><b>{formatDuration(typeof position.openedAt === "number" ? Math.max(0, Date.now() / 1000 - position.openedAt / 1000) : null)}</b></div></div><div className={`floating-pnl ${positive ? "profit" : "loss"}`}>{money(pnl)} <small>({position.cost ? `${fmt(pnl / position.cost * 100, 1)}%` : "--"})</small></div><div className="range-wrap"><div className="range-labels"><span>STOP {cents(stop)} <small>- {plainMoney(position.stopLossUsd ?? 1.5)}</small></span><span>TAKE {cents(take)} <small>+{plainMoney((take - Number(position.entryPrice)) * Number(position.shares))}</small></span></div><div className="range-track"><span className="range-fill" /><i className="range-entry" style={{ left: `${entryMarker}%` }} /><i className="range-current" style={{ left: `${marker}%` }} /></div></div><div className="position-foot"><span>Window {position.windowId}</span><span>{fmt(remaining, 0)}s remaining</span></div></section>;
}

function Metrics({ state }: { state: State }) {
  const values = [["Balance", plainMoney(state.metrics.cash), ""], ["Equity", plainMoney(state.metrics.equity), (state.metrics.equity ?? 0) >= 100 ? "profit" : "loss"], ["Realized PnL", money(state.metrics.realizedPnl), (state.metrics.realizedPnl ?? 0) >= 0 ? "profit" : "loss"], ["Unrealized PnL", money(state.metrics.unrealizedPnl), (state.metrics.unrealizedPnl ?? 0) >= 0 ? "profit" : "loss"], ["Win rate", state.metrics.winRate === null ? "--" : `${fmt(state.metrics.winRate * 100, 1)}%`, ""], ["Trades", fmt(state.metrics.trades, 0), ""], ["Wins", fmt(state.metrics.wins, 0), "profit"], ["Losses", fmt(state.metrics.losses, 0), "loss"], ...(state.metrics.profitFactor !== undefined ? [["Profit factor", fmt(state.metrics.profitFactor, 2), ""]] : []), ...(state.metrics.maxDrawdown !== undefined ? [["Max drawdown", plainMoney(state.metrics.maxDrawdown), "loss"]] : [])];
  return <section className="metrics-section"><div className="section-heading"><div><div className="section-kicker">ACCOUNT</div><h2>Performance</h2></div><span className={`recon-badge ${state.account.reconciliationStatus === "RECONCILED" ? "good" : "bad"}`}>{state.account.reconciliationStatus}</span></div><div className="metrics-grid">{values.map(([label, value, tone]) => <div className="metric-card" key={label}><small>{label}</small><strong className={tone}>{value}</strong>{label === "Win rate" && <span className="mini-bar"><i style={{ width: `${clamp(typeof state.metrics.winRate === "number" ? state.metrics.winRate * 100 : null, 0, 100)}%` }} /></span>}</div>)}</div></section>;
}

function EquityCurve({ state }: { state: State }) {
  const points = useMemo(() => { let equity = 100; const values = [equity, ...state.account.ledger.map(fill => { equity += fill.side === "BUY" ? -Number(fill.usd) - Number(fill.fee ?? 0) : Number(fill.usd) - Number(fill.fee ?? 0); return equity; })]; const min = Math.min(...values, 100); const max = Math.max(...values, 100); return values.map((value, index) => `${(index / Math.max(1, values.length - 1)) * 100},${92 - ((value - min) / Math.max(0.01, max - min)) * 76}`); }, [state.account.ledger]); 
  return <section className="panel equity-card"><div className="section-heading"><div><div className="section-kicker">EQUITY CURVE</div><h2>Account trajectory</h2></div><span className="muted mono">START $100.00</span></div><svg viewBox="0 0 100 100" preserveAspectRatio="none" className="equity-chart"><defs><linearGradient id="equity-fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#35e08a" stopOpacity=".35" /><stop offset="1" stopColor="#35e08a" stopOpacity="0" /></linearGradient></defs><line x1="0" y1="20" x2="100" y2="20" className="start-line" /><polygon points={`0,92 ${points.join(" ")} 100,92`} fill="url(#equity-fill)" /><polyline points={points.join(" ")} className="equity-line" /></svg></section>;
}

function ResetControl({ onReset }: { onReset: (message: string) => void }) {
  const [open, setOpen] = useState(false);
  const [typed, setTyped] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      const response = await fetch("/api/reset", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "same-origin", body: JSON.stringify({ confirm: true }) });
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? "Reset failed");
      onReset("Account reset successfully.");
      setOpen(false);
      setTyped("");
    } catch (error) { onReset(error instanceof Error ? error.message : String(error)); }
    finally { setBusy(false); }
  };
  return <div className="reset-control"><button className="reset-button" type="button" onClick={() => setOpen(true)}>Reset account to $100</button>{open && <div className="reset-dialog"><div className="reset-dialog-card"><h3>Erase all trades?</h3><p>This will erase all trades and start again from $100. An archive backup is created first.</p><input autoFocus value={typed} onChange={(event) => setTyped(event.target.value)} placeholder="Type RESET" /><div><button type="button" onClick={() => setOpen(false)}>Cancel</button><button type="button" disabled={typed !== "RESET" || busy} onClick={() => void submit()}>Confirm reset</button></div></div></div>}</div>;
}

function TradeTabs({ state }: { state: State }) {
  const [tab, setTab] = useState<"trades" | "fills">("trades");
  const trips = useMemo(() => {
    const open = new Map<string, Fill[]>();
    const output: RoundTrip[] = [];
    for (const fill of state.account.ledger) {
      const key = `${fill.windowId ?? ""}:${fill.outcome}`;
      if (fill.side === "BUY") {
        const queue = open.get(key) ?? [];
        queue.push(fill);
        open.set(key, queue);
      } else {
        const queue = open.get(key);
        const buy = queue?.shift();
        if (buy) {
          const pnl = Number(fill.usd) - Number(fill.fee ?? 0) - Number(buy.usd) - Number(buy.fee ?? 0);
          output.push({ buy, sell: fill, pnl, percent: buy.usd ? pnl / Number(buy.usd) * 100 : 0, duration: Math.min(900, Math.max(0, (Number(fill.timestamp) - Number(buy.timestamp)) / 1000)) });
        }
      }
    }
    return output.reverse();
  }, [state.account.ledger]);
  const stopped = trips.filter((trade) => trade.sell.reason === "STOP_LOSS" || trade.sell.reason === "REVERSAL");
  const wouldHaveWon = stopped.filter((trade) => trade.sell.outcomeAfterExit?.verdict === "WOULD_HAVE_WON").length;
  const rightToStop = stopped.filter((trade) => trade.sell.outcomeAfterExit?.verdict === "STOP_WAS_RIGHT").length;
  const hypotheticalProfit = stopped.reduce((sum, trade) => sum + (Number(trade.sell.outcomeAfterExit?.bestBidAfterExit ?? trade.sell.price) * Number(trade.buy.shares) - Number(trade.buy.usd) - Number(trade.buy.fee ?? 0)), 0);
  const verdict = (tracking?: Tracking) => tracking?.verdict === "WOULD_HAVE_WON" ? <span className="verdict-chip amber">Reversed after stop: would have WON</span> : tracking?.verdict === "STOP_WAS_RIGHT" ? <span className="verdict-chip grey">Stop was right</span> : <span className="verdict-chip pending">Checking...</span>;
  const content = tab === "trades" ? trips.map((trade, index) => <div className="trade-item" key={`${trade.sell.id ?? index}-trip`}><div className="trade-time">{formatClock(trade.sell.timestamp ?? 0)}</div><div className={`side-chip ${trade.buy.outcome.toLowerCase()}`}>{trade.buy.outcome}</div><div><b>{cents(trade.buy.price)} → {cents(trade.sell.price)}</b><small>{fmt(trade.buy.shares, 3)} shares · {formatDuration(trade.duration)}</small><small>Settings: trigger {settingCents(trade.buy.triggerPrice)} · TP {settingCents(trade.buy.takeProfitPrice)} · stop {settingCents(trade.buy.stopLossPrice)} / {trade.buy.stopLossUsd === undefined ? "n/a" : plainMoney(trade.buy.stopLossUsd)}</small></div><strong className={trade.pnl >= 0 ? "profit" : "loss"}>{money(trade.pnl)} <small>{fmt(trade.percent, 1)}%</small></strong><span><span className={`exit-tag ${trade.sell.reason.toLowerCase()}`}>{trade.sell.reason.replaceAll("_", " ")}</span>{(trade.sell.reason === "STOP_LOSS" || trade.sell.reason === "REVERSAL") && <>{verdict(trade.sell.outcomeAfterExit)}</>}</span></div>) : state.account.ledger.slice().reverse().map((fill, index) => <div className="trade-item fill-item" key={`${fill.id ?? index}-fill`}><div className="trade-time">{formatClock(fill.timestamp ?? 0)}</div><div className={`side-chip ${fill.outcome.toLowerCase()}`}>{fill.outcome}</div><div><b>{fill.side} {cents(fill.price)}</b><small>{fmt(fill.shares, 3)} shares · {plainMoney(fill.usd)}</small></div><span className="muted">slip {cents(fill.slippage)} · fee {plainMoney(fill.fee)}</span><span className="muted">{fill.reason}</span></div>);
  return <section className="panel trades-panel"><div className="section-heading"><div><div className="section-kicker">EXECUTION HISTORY</div><h2>Trades & fills</h2></div><div className="tab-buttons"><button className={tab === "trades" ? "active" : ""} onClick={() => setTab("trades")}>Completed Trades</button><button className={tab === "fills" ? "active" : ""} onClick={() => setTab("fills")}>All Execution Fills</button></div></div><div className="trade-summary">{trips.length} trades · {trips.filter(trade => trade.pnl > 0).length} wins · {trips.filter(trade => trade.pnl < 0).length} losses · {money(trips.reduce((sum, trade) => sum + trade.pnl, 0))} total profit{stopped.length > 0 && <> · {wouldHaveWon} would have won · {rightToStop} right to stop · hypothetical {money(hypotheticalProfit)}</>}</div><div className="trade-list">{content.length ? content : <div className="empty-trades">No trades yet. The bot waits for a clean setup.</div>}</div></section>;
}

function StatusPanel({ state }: { state: State }) {
  return <details className="panel status-panel"><summary><span><span className="section-kicker">ENGINE LOG / STATUS</span><b>Latest server-authoritative state</b></span><span>⌄</span></summary><div className="status-lines"><div><span className="status-dot" />{state.snapshot.feedMessage}</div>{(["UP", "DOWN"] as Outcome[]).map(outcome => <div key={outcome}><span className="mono">{outcome}</span> {state.entryStatus[outcome]?.decision ?? "WAITING"} · {state.entryStatus[outcome] ? decisionCopy[state.entryStatus[outcome]?.decision ?? ""] ?? "" : "No entry status"}</div>)}</div></details>;
}

function App() {
  const [state, setState] = useState<State | null>(null);
  const [error, setError] = useState("");
  const [connected, setConnected] = useState(false);
  const [resetMessage, setResetMessage] = useState("");
  const [now, setNow] = useState(Date.now());
  const [history, setHistory] = useState<Record<Outcome, number[]>>({ UP: [], DOWN: [] });
  const lastEvent = useRef(0);
  const load = async () => { const response = await fetch("/api/state", { credentials: "same-origin" }); if (!response.ok) throw new Error(`Unable to load dashboard state (${response.status})`); setState(await response.json() as State); setError(""); };
  useEffect(() => { let active = true; void load().catch(reason => { if (active) setError(reason instanceof Error ? reason.message : String(reason)); }); const events = new EventSource("/events"); const apply = (event: MessageEvent<string>) => { if (!active) return; lastEvent.current = Date.now(); const payload = JSON.parse(event.data) as State & { up?: Quote; down?: Quote; feedHealth?: string; feedMessage?: string; metrics?: Metrics; entryStatus?: State["entryStatus"] }; setState(previous => { if (!previous || event.type === "momentum_account_update") return payload; return { ...previous, metrics: payload.metrics ?? previous.metrics, entryStatus: payload.entryStatus ?? previous.entryStatus, snapshot: { ...previous.snapshot, up: payload.up ?? previous.snapshot.up, down: payload.down ?? previous.snapshot.down, feedHealth: payload.feedHealth ?? previous.snapshot.feedHealth, feedMessage: payload.feedMessage ?? previous.snapshot.feedMessage } }; }); }; events.onopen = () => setConnected(true); events.onerror = () => setConnected(false); events.addEventListener("momentum_account_update", apply as EventListener); events.addEventListener("price_tick", apply as EventListener); const poll = window.setInterval(() => { if (Date.now() - lastEvent.current >= 3000) void load().catch(() => undefined); }, 1000); const clock = window.setInterval(() => setNow(Date.now()), 1000); return () => { active = false; events.close(); window.clearInterval(poll); window.clearInterval(clock); }; }, []);
  useEffect(() => { if (state) document.title = `UP ${cents(state.snapshot.up.ask)} | BTC 15M`; }, [state]);
  useEffect(() => { if (state) setHistory(previous => ({ UP: typeof state.snapshot.up.ask === "number" ? [...previous.UP, state.snapshot.up.ask].slice(-90) : previous.UP, DOWN: typeof state.snapshot.down.ask === "number" ? [...previous.DOWN, state.snapshot.down.ask].slice(-90) : previous.DOWN })); }, [state?.snapshot.up.ask, state?.snapshot.down.ask]);
  if (!state) return <main className="loading-screen"><section className="panel loading-card"><span className="eyebrow">BTC 15M / SECURE TERMINAL</span><div className="skeleton skeleton-title" /><div className="skeleton skeleton-line" /><b>Connecting...</b><p>{error || "Waiting for /api/state"}</p></section></main>;
  const remaining = Math.max(0, state.snapshot.windowEnd - now / 1000);
  const stale = state.snapshot.feedHealth !== "LIVE";
  return <div className={`app-shell ${stale ? "feed-stale" : ""}`}><header className="topbar"><div className="brand"><b>BTC 15M</b><span className={`connection ${connected ? "live" : "reconnecting"}`}><i />{connected ? "LIVE" : "RECONNECTING"}</span><span className="top-feed">FEED {state.snapshot.feedHealth}</span><span className={`engine ${state.circuitBreakerHalted ? "halted" : ""}`}>{state.circuitBreakerHalted ? "HALTED" : "ENGINE READY"}</span></div><div className="top-values"><span>Equity <b>{plainMoney(state.metrics.equity)}</b></span><span>Total PnL <b className={(state.metrics.realizedPnl ?? 0) >= 0 ? "profit" : "loss"}>{money(state.metrics.realizedPnl)}</b></span></div></header>{stale && <div className="feed-banner">● FEED DISCONNECTED <span>{state.snapshot.feedMessage}</span></div>}<main className="terminal-grid"><div className="primary-column" id="live"><section className="hero-keys"><CardBoundary name="UP price"><PriceHero outcome="UP" quote={state.snapshot.up} history={history.UP} maxEntry={state.config?.maxEntryPrice ?? 0.95} /></CardBoundary><CardBoundary name="DOWN price"><PriceHero outcome="DOWN" quote={state.snapshot.down} history={history.DOWN} maxEntry={state.config?.maxEntryPrice ?? 0.95} /></CardBoundary></section><CardBoundary name="Window"><WindowCard state={state} remaining={remaining} /></CardBoundary>{state.account.openPosition ? <CardBoundary name="Active position"><PositionCockpit state={state} remaining={remaining} /></CardBoundary> : <CardBoundary name="Market radar"><Radar state={state} /></CardBoundary>}<div id="trades"><CardBoundary name="Trade history"><TradeTabs state={state} /></CardBoundary></div><div id="status"><CardBoundary name="Engine status"><StatusPanel state={state} /></CardBoundary></div><div className="reset-footer"><span className={resetMessage.includes("successfully") ? "profit" : "loss"}>{resetMessage}</span><ResetControl onReset={setResetMessage} /><small>Rules: enter {cents(state.config?.entryTrigger ?? 0.91)}-{cents(state.config?.maxEntryPrice ?? 0.95)}, take profit {cents(state.config?.takeProfit ?? 0.99)}, stop-loss {plainMoney(state.config?.stopLossUsd ?? 1.5)}</small></div></div><aside className="secondary-column" id="stats"><CardBoundary name="Metrics"><Metrics state={state} /></CardBoundary><CardBoundary name="Equity curve"><EquityCurve state={state} /></CardBoundary></aside></main><nav className="bottom-nav"><a href="#live">◉<span>Live</span></a><a href="#stats">▦<span>Stats</span></a><a href="#trades">≡<span>Trades</span></a><a href="#status">◌<span>Status</span></a></nav></div>;
}

createRoot(document.getElementById("root")!).render(<React.StrictMode><ErrorBoundary><App /></ErrorBoundary></React.StrictMode>);
